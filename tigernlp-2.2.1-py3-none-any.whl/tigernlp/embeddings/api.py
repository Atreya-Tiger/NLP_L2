"""Utilities around ``Text Embeddings``.
This module contains multiple options to convert text documents to the embedding vectors.
"""
from .sentence import SentenceEmbedding
from .word import WordEmbedding
