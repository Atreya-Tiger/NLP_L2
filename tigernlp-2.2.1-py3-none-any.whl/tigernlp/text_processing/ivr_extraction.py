import pandas as pd
import re
import time
from collections import defaultdict
from typing import List, Tuple, Union

from tigernlp.core.api import MyLogger

# from tigernlp.text_processing.api import ConversationProcessor  # throwing circular import error during parallelization
from tigernlp.text_processing.conv_processing import ConversationProcessor

from ..core.custom_multiprocessing import parallelize_dict_counter, parallelize_groupby


def _make_rolling_phrases(sentence: str, phrase_length: int, phrase_to_exclude: list, ivr_logger: MyLogger):
    """A helper function to convert sentence/block of text to a list of rolling phrases of length = ``phrase_length``. This is used to get frequency of phrases and decide on potential machine/ IVR prompts, which can be treated
        Ex: "Hello welcome to ta_nlp library" will be broken into "Hello welcome to", "welcome to ta_nlp", "to ta_nlp library" if `phrase_length = 3`

    Parameters
    ----------
    sentence : str
        Input text that needs to be split into phrases

    phrase_length : int
        Length of each phrase

    phrase_to_exclude: list
        List of phrases like greetings that needs to be excluded. We need to exclude greeting messages that will be coming from the representative as they are expected to have high frequency without being IVR prompts

    ivr_logger: MyLogger
        Instance of MyLogger class for logging purposes.

    Returns
    -------
    list
        List of rolling phrases from the given sentence of length ``phrase_length``

    """
    if phrase_to_exclude is None:  # Default behavior
        phrase_to_exclude = []

    words = sentence.split()
    phrase_list = []

    for i in range(len(words) - phrase_length + 1):
        current_phrase = " ".join(words[i : i + phrase_length])
        ignoreflag = False
        for pat in phrase_to_exclude:
            # Compile and see if its valid regex pattern.
            # if yes, proceed for regex search,
            # else log the invalid pattern as warning and continue to next pattern.
            try:
                compiled_regex = re.compile(pat, flags=re.IGNORECASE)
                if compiled_regex.search(current_phrase):
                    ignoreflag = True
                    break
            except re.error:
                ivr_logger.warning(f"Given expression {pat} is not a valid regex")
                continue

        if ignoreflag:
            continue
        else:
            phrase_list.append(current_phrase)

    return phrase_list


def _extract_ivr_blocks_per_call_substr(
    call_transcript: pd.DataFrame,
    ivr_prompts: list,
    num_ivr_blocks_to_extract: int,
    col_in: dict,
) -> pd.DataFrame:
    """Helper method to tag ivr blocks identified by substring.

    Parameters
    ----------
    call_transcript : pd.DataFrame
        Entire corpus of calls for a source.

        Format of this dataframe should follow main dataframe of ``ConversationProcessor`` class.

    ivr_prompts : list
        List of IVR prompts which we can use to directly identify Conversation blocks containing IVR prompts. These are list of substrings.

    num_ivr_blocks_to_extract : int
        Number of Conversation blocks to consider as part of IVR prompt and it's reply.

    col_in : dict
        Input column names mappings which has the conversation block details that are needed for extracting IVR. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

        For example::

            {
                "id": "call_id",
                "conv_b_num": "conv_b_num",
                "speaker": "speaker",
                "text": "conv_blocks",
            }

    Returns
    -------
    pd.DataFrame
        Dataframe with column "is_ivr_selection?" set as per the rules.

    """
    for index, row in call_transcript.iterrows():
        for each_ivr_prompt in ivr_prompts:
            if each_ivr_prompt.lower() in row[col_in["text"]].lower():
                call_transcript.loc[index : index + num_ivr_blocks_to_extract - 1, "is_ivr_section?"] = True
                # Goto next row if block is already identified.
                break

    return call_transcript


def _extract_ivr_blocks_per_call_regex(
    call_transcript: pd.DataFrame,
    ivr_prompts: list,
    num_ivr_blocks_to_extract: int,
    col_in: dict,
    ivr_logger: MyLogger,
) -> pd.DataFrame:
    """Helper method to tag ivr blocks identified by regex patterns.

    Parameters
    ----------
    call_transcript : pd.DataFrame
        Entire corpus of calls for a source.

        Format of this dataframe should follow main dataframe of ``ConversationProcessor`` class.

    ivr_prompts : list
        List of IVR prompts which we can use to directly identify Conversation blocks containing IVR prompts. These are list of regex patterns.

    num_ivr_blocks_to_extract : int
        Number of Conversation blocks to consider as part of IVR prompt and it's reply.

    col_in : dict
        Input column names mappings which has the conversation block details that are needed for extracting IVR. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

        For example::

            {
                "id": "call_id",
                "conv_b_num": "conv_b_num",
                "speaker": "speaker",
                "text": "conv_blocks",
            }

    ivr_logger: MyLogger
        Instance of MyLogger class for logging purposes.

    Returns
    -------
    pd.DataFrame
        Dataframe with column "is_ivr_selection?" set as per the rules.

    """
    for index, row in call_transcript.iterrows():
        for each_pat in ivr_prompts:
            # Check for valid pattern
            try:
                compiled_pattern = re.compile(each_pat, flags=re.IGNORECASE)
            except re.error:
                ivr_logger.error(f"Invalid Regex pattern {each_pat} is provided.")
                raise ValueError("Invalid Regex pattern is provided.")

            # check for IVR with valid pattern
            if compiled_pattern.search(string=row[col_in["text"]]):
                call_transcript.loc[index : index + num_ivr_blocks_to_extract - 1, "is_ivr_section?"] = True
                # Goto next row if block is already identified.
                break

    return call_transcript


def _update_ivr_prompt_count(
    call_transcript_text: pd.Series,
    ivr_prompts: list,
    ivr_logger: MyLogger,
) -> dict:
    """Helper method to update count of ivr_prompt_count and return it.

    Parameters
    ----------
    call_transcript_text : pd.Series
        Text of entire corpus of calls for a source.

        It is the "text" column from main dataframe of ``ConversationProcessor`` class.

    ivr_prompts : list
        List of IVR prompts which we can use to directly identify Conversation blocks containing IVR prompts. These are list of regex patterns.

    ivr_logger: MyLogger
        Instance of MyLogger class for logging purposes.

    Returns
    -------
    dict
        IVR prompts and the count of its occurrence. It gets updated for every call.

    """
    ivr_prompt_count = defaultdict(int)
    for _, text in call_transcript_text.iteritems():
        for each_pat in ivr_prompts:
            # Check for valid pattern
            try:
                compiled_pattern = re.compile(each_pat, flags=re.IGNORECASE)
            except re.error:
                ivr_logger.error(f"Invalid Regex pattern {each_pat} is provided.")
                raise ValueError("Invalid Regex pattern is provided.")

            # check for IVR with valid pattern
            if compiled_pattern.search(string=text):
                ivr_prompt_count[each_pat] = ivr_prompt_count.get(each_pat, 0) + 1

    return ivr_prompt_count


def _extract_ivr_with_prompts(
    call_transcript_corpus: pd.DataFrame,
    ivr_prompts: list,
    num_ivr_blocks_to_extract: int,
    extract_ivr_blocks: bool,
    col_in: dict,
    ivr_logger: MyLogger,
    is_regex: bool = True,
    n_jobs: int = 1,
) -> Tuple[pd.DataFrame, dict, pd.Series]:
    """In the given call corpus, search for Conversation blocks with ``ivr_prompts``. Extract the identified IVR block along with next ``num_ivr_blocks_to_extract`` blocks into a new dataframe.

    Parameters
    ----------
    call_transcript_corpus : pd.DataFrame
        Entire corpus of calls for a source.

        Format of this dataframe should follow main dataframe of ``ConversationProcessor`` class.

    ivr_prompts : list
        List of IVR prompts which we can use to directly identify Conversation blocks containing IVR prompts.

    num_ivr_blocks_to_extract : int
        Number of Conversation blocks to consider as part of IVR prompt and it's reply.

    extract_ivr_blocks : bool
        If True, extracts the IVR blocks as defined by ``num_ivr_blocks_to_extract`` to a new dataframe.

    is_regex: bool, by default True
        This parameter differentiates how the string matching is done. i.e., either as a regex pattern or as a substring. If this parameter value is False, consider ``ivr_prompts`` as list of substring. Else, ``ivr_prompts`` is list of regex pattern.

    col_in : dict
        Input column names mappings which has the conversation block details that are needed for extracting IVR. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

        For example::

            {
                "id": "call_id",
                "conv_b_num": "conv_b_num",
                "speaker": "speaker",
                "text": "conv_blocks",
            }

    n_jobs : int
        Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

    ivr_logger: MyLogger
        Instance of MyLogger class for logging purposes.

    Returns
    -------
    Tuple[pd.DataFrame, dict, pd.Series]
        pd.DataFrame
            Dataframe that has "is_ivr_section?" updated. It has same format as main dataframe.

        pd.DataFrame
            Dataframe containing IVR prompt only conversation blocks and it's replies. It has same format as main dataframe.

            It will be an empty dataframe if ``extract_ivr_blocks`` = False.

        dict:
            IVR prompts and the count of its occurrence.

    """
    ivr_logger.info(f"Total number of prompts is {len(ivr_prompts)}")
    st = time.time()

    call_transcript_corpus["is_ivr_section?"] = False
    ivr_prompt_count = defaultdict(int)
    ivr_and_replies = pd.DataFrame(data=None)

    if len(ivr_prompts) == 0:
        return call_transcript_corpus, ivr_and_replies, ivr_prompt_count

    # Check as substrings
    if not is_regex:
        # Sequential
        # ivr_tagged_corpus = call_transcript_corpus.groupby(col_in["id"]).apply(
        #     _extract_ivr_blocks_per_call_substr,
        #     ivr_prompts=ivr_prompts,
        #     num_ivr_blocks_to_extract=num_ivr_blocks_to_extract,
        #     col_in=col_in,
        # )

        # Parallel
        substr_kwargs = {
            "ivr_prompts": ivr_prompts,
            "num_ivr_blocks_to_extract": num_ivr_blocks_to_extract,
            "col_in": col_in,
        }
        ivr_tagged_corpus = parallelize_groupby(
            df=call_transcript_corpus,
            groupby_cols=col_in["id"],
            func=_extract_ivr_blocks_per_call_substr,
            kwargs=substr_kwargs,
            n_jobs=n_jobs,
        )

    else:  # Do Regex
        # Sequential
        # ivr_tagged_corpus = call_transcript_corpus.groupby(col_in["id"]).apply(
        #     _extract_ivr_blocks_per_call_regex,
        #     ivr_prompts=ivr_prompts,
        #     num_ivr_blocks_to_extract=num_ivr_blocks_to_extract,
        #     ivr_prompt_count=ivr_prompt_count,
        #     col_in=col_in,
        # )

        # Parallel
        regex_kwargs = {
            "ivr_prompts": ivr_prompts,
            "num_ivr_blocks_to_extract": num_ivr_blocks_to_extract,
            "col_in": col_in,
            "ivr_logger": ivr_logger,
        }
        ivr_tagged_corpus = parallelize_groupby(
            df=call_transcript_corpus,
            groupby_cols=col_in["id"],
            func=_extract_ivr_blocks_per_call_regex,
            kwargs=regex_kwargs,
            n_jobs=n_jobs,
        )
        count_kwargs = {"ivr_prompts": ivr_prompts, "ivr_logger": ivr_logger}
        ivr_prompt_count = parallelize_dict_counter(
            series=call_transcript_corpus[col_in["text"]],
            func=_update_ivr_prompt_count,
            kwargs=count_kwargs,
            n_jobs=n_jobs,
        )

    if extract_ivr_blocks:
        ivr_and_replies = ivr_tagged_corpus.query("`is_ivr_section?` == True").copy(deep=True)

    ivr_logger.info(f"Extract ivr with prompts is done in {round(time.time() - st, 3)} seconds.")
    return ivr_tagged_corpus, ivr_and_replies, ivr_prompt_count


def _extract_ivr_phrases(
    call_transcript_corpus: pd.DataFrame,
    phrase_length: int,
    freq_of_phrase_occurrence: float,
    num_occurrence_in_uniq_calls: int,
    col_in: dict,
    ivr_logger: MyLogger,
) -> dict:
    """Helper method for extract_ivr_msgs which extracts ivr messages with custom logic to extract IVR.

    Parameters
    ----------
    call_transcript_corpus : pd.DataFrame
        Entire corpus of calls for a source. Format of this dataframe should follow main dataframe.

    phrase_length : int, optional
        Number of words to consider in each phrase (Potential minimum length of each IVR prompt), by default 12

    freq_of_phrase_occurrence : float, optional
        Threshold to consider a phrase an IVR. It lies in range (0, 1).

        If this value is given, ``num_occurrence_in_uniq_calls`` should not be given., by default None

    num_occurrence_in_uniq_calls : int, optional
        Number of unique calls a given phrase has to repeat in inorder to consider it as an IVR prompt. It lies in range (0, 1).

        If this value is given, ``freq_of_phrase_occurrence`` should not be given., by default None

    col_in : dict
        Input column names mappings which has the conversation block details that are needed for extracting IVR. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

        For example::

            {
                "id": "call_id",
                "conv_b_num": "conv_b_num",
                "speaker": "speaker",
                "text": "conv_blocks",
            }

    ivr_logger: MyLogger
        Instance of MyLogger class for logging purposes.

    Returns
    -------
    dict:
        phrase which passed the threshold and the count of its occurrence.
    """
    st = time.time()
    num_of_calls = call_transcript_corpus[col_in["id"]].nunique()

    if freq_of_phrase_occurrence is not None:
        # Convert to list of phrases.
        phrase_list = call_transcript_corpus[col_in["text"]].apply(
            _make_rolling_phrases,
            phrase_length=phrase_length,
            phrase_to_exclude=None,
            ivr_logger=ivr_logger,
        )
        # Count occurence of each phrase in the entire dataset
        phrase_freq_counts = (
            phrase_list.explode().value_counts().reset_index().rename(columns={"index": "phrases", col_in["text"]: "num_occurrences"})
        )
        # Calculate percentage represented as fraction
        phrase_freq_counts["freq_of_occurrence"] = phrase_freq_counts["num_occurrences"] / num_of_calls
        # IVR phrases that passed the threshold
        ivr_phrases_df = phrase_freq_counts.query("freq_of_occurrence > @freq_of_phrase_occurrence")

        # IVR Phrase counts
        ivr_phrase_counts = dict(zip(ivr_phrases_df["phrases"], ivr_phrases_df["num_occurrences"]))
    else:  # Num of uniq occurences.
        phrase_df = call_transcript_corpus.copy(deep=True)
        # Convert to list of phrases.
        phrase_df["phrase_list"] = phrase_df[col_in["text"]].apply(
            _make_rolling_phrases,
            phrase_length=phrase_length,
            phrase_to_exclude=None,
            ivr_logger=ivr_logger,
        )
        # Count occurrence of uniq phrase per call.
        call_grps = phrase_df.groupby(col_in["id"])["phrase_list"].sum().transform(lambda x: set(x))
        call_grps = (
            call_grps.explode()
            .value_counts()
            .reset_index()
            .rename(columns={"index": "phrases", "phrase_list": "num_occurrences_uniq_calls"})
        )
        # Convert to percentage represented as fraction
        call_grps["num_occurrences_uniq_calls_pct"] = call_grps["num_occurrences_uniq_calls"] / num_of_calls
        # IVR phrases that passed the threshold
        ivr_phrases_df = call_grps.query("num_occurrences_uniq_calls_pct > @num_occurrence_in_uniq_calls")

        # IVR Phrase counts
        ivr_phrase_counts = dict(zip(ivr_phrases_df["phrases"], ivr_phrases_df["num_occurrences_uniq_calls"]))

    ivr_logger.info(f"Automatic IVR Phrases extraction done in {round(time.time() - st, 3)} seconds.")
    return ivr_phrase_counts


def extract_ivr_msgs(
    ip_df: pd.DataFrame,
    col_in: dict,
    phrase_length: int = 12,
    freq_of_phrase_occurrence: float = None,
    num_occurrence_in_uniq_calls: int = None,
    greetings_blocks: pd.DataFrame = None,
    speaker: Union[int, str] = None,
    remove_ivr_in_data: bool = False,
    ivr_prompts: list = None,
    num_ivr_blocks_to_extract: int = 2,
    extract_ivr_blocks: bool = False,
    col_out_original: dict = None,
    col_out_ivr: dict = None,
    logging_level: str = "WARNING",
    log_file_path: str = None,
    verbose: bool = True,
    n_jobs: int = 1,
) -> Tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Split each conversation block to rolling phrases of ``phrase_length``. For the entire call, count how many times each phrase occurs as a percentage of total phrases. A phrase is considered as an IVR phrase if it either meets ``freq_of_phrase_occurrence`` threshold, or the number of occurence in unique calls (``num_occurrence_in_uniq_calls``) threshold.

    Parameter combinations (ivr_prompts, num_ivr_blocks_to_extract, extract_ivr_blocks) are mutually exclusive to parameter combination (``phrase_length``, ``freq_of_phrase_occurrence``, ``num_occurrence_in_uniq_calls``, ``greetings_blocks``, ``speaker``, ``remove_ivr_in_data``)

    There are two reasons why this function might be helpful in the downstream tasks:
        1. IVR question and their replies might contain some direct answers to the questions like intent (Ex: We expect some IVR prompts like "What is the reason for calling xyz?")
        2. Other IVR prompts may not add any value to downstream activities and may be better to remove them (Ex: "For English press 1, Espanol press 2" etc)

    If the list of IVR prompts are known, they can be passed as regex in ``ivr_prompts`` and they will be tagged. If the list is not known, then we identify IVR prompts based on how frequently some phrases are occuring in the call corpus (this logic works better if we have more calls) and tag them as IVR

    If ``extract_ivr_blocks`` = True, IVR section (``num_ivr_blocks_to_extract`` conversation blocks after each IVR conversation block) is extracted and saved in a seperate df. This df is expected to have IVR prompt and the customer's response


    Parameters
    ----------
    ip_df : pd.DataFrame
        Entire corpus of calls for a source. Format of this dataframe should follow main dataframe of ``ConversationProcessor`` class.

    phrase_length : int, optional
        Number of words to consider in each phrase (Potential minimum length of each IVR prompt), by default 12. In our experiece with one of the clients, we noticed ``phrase_length = 12`` is identifying better IVR prompts

    freq_of_phrase_occurrence : float, optional
        Threshold to consider a phrase an IVR. It lies in range (0, 1). In our experience with one of the clients, we noticed that `freq_of_phrase_occurrence = 0.001` is identifying better IVR prompts

        If this value is given, num_occurrence_in_uniq_calls should not be given., by default None

    num_occurrence_in_uniq_calls : int, optional
        Number of unique calls a given phrase has to repeat in inorder to consider it as an IVR prompt. It lies in range (0, 1).

        If this value is given, freq_of_phrase_occurrence should not be given., by default None

    greetings_blocks : pd.DataFrame, optional
        Dataframe containing greetings blocks for each call from overall corpus.

        If None, greetings messages from call_transcript_corpus will not be removed and so greetings can be falsely represented as ivr., by default None

    speaker : Union[int, str], optional
        If you want to extract IVR messages for a particular speaker in the entire call corpus, enter the speaker id here., by default None

    remove_ivr_in_data : bool, optional
        If true, removes IVR phrases in conversation block., by default False

    ivr_prompts : list, optional
        List of valid IVR regex patterns which we can use to directly identify Conversation blocks containing IVR prompts., by default None

    num_ivr_blocks_to_extract : int, optional
        Number of Conversation blocks to consider as part of IVR prompt and it's reply., by default 2

    extract_ivr_blocks : bool, optional
        If True, extracts the IVR blocks as defined by `num_ivr_blocks_to_extract` to a new dataframe., by default False

    col_in : dict
        Input column names mappings which has the conversation block details that are needed for extracting IVR. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

        For example::

            {
                "id": "call_id",
                "conv_b_num": "conv_b_num",
                "speaker": "speaker",
                "text": "conv_blocks",
            }

    col_out_original : dict, optional
        Output column name mappings which has the original dataframe that maybe modified depending on input parameter. Mapping should be given as key-value pair. Keys should be those columns which you want to rename. Corresponding values should be the column names you want in the main dataframe. If you do not wish to rename, don't pass any value to this parameter.

        For example (If you want to rename "text" alone to "text_without_ivr")::

            {
                "text": "text_without_ivr",
            }

    col_out_ivr : dict, optional
        Output column name mappings for IVR only dataframe. Mapping should be given as key-value pair. Keys should be those columns which you want to rename. Corresponding values should be the column names you want in the main dataframe. If you do not wish to rename, don't pass any value to this parameter.

        For example (If you want to rename "text" alone to "ivr_blocks")::

            {
                "text": "ivr_blocks",
            }

    logging_level : str, optional
        Enter the level of logging. by default, its "WARNING"

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    n_jobs : int
        Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

    Returns
    -------
    Tuple[pd.DataFrame, pd.DataFrame, dict]

        pd.DataFrame
            Original Dataframe which may or may not be modified as per the option remove_ivr_in_data. Same format as main dataframe.

        pd.DataFrame
            Dataframe containing IVR prompt only conversation blocks. Same format as main dataframe.

        dict
            phrase which passed the threshold and the count of its occurrence.

            For example::

                {
                    "press 2 to go back": 10,
                    "enter your phone number": 20
                }

    Raises
    ------
    ValueError
        if any of the parameter is invalid type or incorrect parameter combination specified by the error message.

    Examples
    --------
    >>> my_prompt = [r".*?enter.+?number.+?to transfer the call.*?"]
    >>> ip_cols = {
        "id": "call_id",
        "speaker": "speaker",
        "conv_b_num": "conv_b_num",
        "text": "text"
        }
    >>> original_df, ivr_df, ivr_phrase_counts = ivr_extraction.extract_ivr_msgs(
            ip_df=cleaned_df,
            col_in=ip_cols,
            phrase_length=None,
            freq_of_phrase_occurrence=None,
            num_occurrence_in_uniq_calls=None,
            greetings_blocks=greetings,
            speaker=None,
            remove_ivr_in_data=False,
            ivr_prompts=my_prompt,
            num_ivr_blocks_to_extract=2,
            extract_ivr_blocks=False,
        )

    """
    # Set logging
    ivr_logger = MyLogger(level=logging_level, log_file_path=log_file_path, verbose=verbose).logger

    # Parameter type and Value checks
    if col_in is None:
        raise ValueError("col_in is mandatory argument.")
    elif any(x not in col_in.keys() for x in ["id", "speaker", "conv_b_num", "text"]):
        raise ValueError("col_in is missing information/keys.")
    elif ip_df is None or not isinstance(ip_df, pd.DataFrame):
        raise ValueError("Call Transcript corpus should be a pandas dataframe.")
    elif phrase_length is not None and not isinstance(phrase_length, int):
        raise ValueError("Phrase Length must be of integer type.")
    elif (
        freq_of_phrase_occurrence is not None and not isinstance(freq_of_phrase_occurrence, float) and 0.0 < freq_of_phrase_occurrence < 1.0
    ):
        raise ValueError("freq_of_phrase_occurrence must be a float and lies in range(0, 1)")
    elif (
        num_occurrence_in_uniq_calls is not None
        and not isinstance(num_occurrence_in_uniq_calls, float)
        and 0.0 < num_occurrence_in_uniq_calls < 1.0
    ):
        raise ValueError("num_occurrence_in_uniq_calls must be a float and lies in range(0, 1)")
    elif greetings_blocks is not None and not isinstance(greetings_blocks, pd.DataFrame):
        raise ValueError("Greetings blocks must be either None or pandas dataframe.")
    elif not isinstance(remove_ivr_in_data, bool):
        raise ValueError("remove_ivr_in_data must be boolean.")
    elif ivr_prompts is not None and not isinstance(ivr_prompts, list):
        raise ValueError("ivr_prompts must be either None or a list.")
    elif not isinstance(num_ivr_blocks_to_extract, int):
        raise ValueError("num_ivr_blocks_to_extract must be of integer type.")
    elif not isinstance(extract_ivr_blocks, bool):
        raise ValueError("extract_ivr_blocks must be boolean.")
    elif speaker is not None and not isinstance(speaker, int) and not isinstance(speaker, str):
        raise ValueError("speaker must be either int or str.")

    # Parameter combinations
    if freq_of_phrase_occurrence is not None and num_occurrence_in_uniq_calls is not None:
        raise ValueError("Either freq_of_phrase_occurrence or num_occurrence_in_uniq_calls should be given but not both.")
    elif ivr_prompts is not None and (freq_of_phrase_occurrence is not None or num_occurrence_in_uniq_calls is not None):
        raise ValueError(
            "Either ivr_prompts or any one of (freq_of_phrase_occurrence, num_occurrence_in_uniq_calls) should be given but not both."
        )
    elif ivr_prompts is None and freq_of_phrase_occurrence is None and num_occurrence_in_uniq_calls is None:
        raise ValueError(
            "All of the inputs are None. Atleast one of (ivr_prompts, freq_of_phrase_occurrence, num_occurrence_in_uniq_calls) should be given."
        )

    # original df
    call_transcript_corpus = ip_df.reset_index(drop=True)
    original_df = call_transcript_corpus.copy(deep=True)

    # If speaker option is given. select only that data.
    if speaker is not None:
        call_transcript_corpus = ConversationProcessor.create_full_conv_for_speaker(
            speaker=speaker, conv_df=call_transcript_corpus, col_in=col_in
        )

    # print("Greetings = ", greetings_blocks.shape)
    # Check if greetings block is given
    if greetings_blocks is None:
        ivr_logger.info("Greetings Blocks is not valued. Hence IVR message extract may yield greetings messages.")
    else:
        greetings_blocks = greetings_blocks[[col_in["id"], col_in["conv_b_num"], col_in["speaker"], col_in["text"]]]

        # Merge and Filter out greetings data.
        call_transcript_corpus = pd.merge(
            left=call_transcript_corpus,
            right=greetings_blocks,
            how="left",
            on=[col_in["id"], col_in["conv_b_num"], col_in["speaker"]],
            validate="1:1",
        )
        # if text from greetings is null, it means corresponding call transcript doesn't have
        # greeting text. Hence, we should pick it up.
        # print(call_transcript_corpus.shape)
        call_transcript_corpus = call_transcript_corpus.query("`{0}`.isnull()".format(col_in["text"] + "_y"), engine="python").copy(
            deep=True
        )
        # print(call_transcript_corpus.shape)
        call_transcript_corpus = call_transcript_corpus.drop(columns=[col_in["text"] + "_y"])
        call_transcript_corpus = call_transcript_corpus.rename(columns={col_in["text"] + "_x": col_in["text"]})

    # Split the Funciton into two based on ivr_prompts
    # This is because if ivr prompts is given, we can directly fetch IVR Blocks
    # and extract its reply and get the intent of the call from it if needed.
    if ivr_prompts is not None:
        st = time.time()
        # ivr_prompts will be a list of regex pattern, hence we set is_regex=True.
        original_df, ivr_and_replies_df, ivr_phrase_counts = _extract_ivr_with_prompts(
            call_transcript_corpus=call_transcript_corpus,
            ivr_prompts=ivr_prompts,
            num_ivr_blocks_to_extract=num_ivr_blocks_to_extract,
            extract_ivr_blocks=extract_ivr_blocks,
            is_regex=True,
            col_in=col_in,
            n_jobs=n_jobs,
            ivr_logger=ivr_logger,
        )

        # If we don't want IVR Prompts in our dataframe.
        if remove_ivr_in_data:
            # No need to check again if its valid regex as its already checked previously.
            original_df[col_in["text"]] = original_df[col_in["text"]].str.replace(
                pat="|".join(ivr_prompts), repl="", regex=True, flags=re.IGNORECASE
            )

        ivr_logger.info(f"Pattern based detection is done in {round(time.time() - st, 3)} seconds.")
    else:
        st = time.time()
        # Else, we have to calculate phrase_occurrence and phrase_occurrence_per_call
        # to find out IVR phrases. Then use that to extract IVR blocks (if needed)
        # as per user input.
        ivr_phrases_with_counts = _extract_ivr_phrases(
            call_transcript_corpus=call_transcript_corpus,
            phrase_length=phrase_length,
            freq_of_phrase_occurrence=freq_of_phrase_occurrence,
            num_occurrence_in_uniq_calls=num_occurrence_in_uniq_calls,
            col_in=col_in,
            ivr_logger=ivr_logger,
        )

        custom_ivr_prompts = list(ivr_phrases_with_counts.keys())
        # custom_ivr_prompts will be a list of substring/phrases extracted by our custom rules, hence we set is_regex=False.
        original_df, ivr_and_replies_df, ivr_phrase_counts = _extract_ivr_with_prompts(
            call_transcript_corpus=call_transcript_corpus,
            ivr_prompts=custom_ivr_prompts,
            num_ivr_blocks_to_extract=num_ivr_blocks_to_extract,
            extract_ivr_blocks=extract_ivr_blocks,
            is_regex=False,
            col_in=col_in,
            n_jobs=n_jobs,
            ivr_logger=ivr_logger,
        )

        # ivr_phrase_counts is empty dict for this flow. We can use ivr_phrases_with_counts that has already counted the occurrence.
        ivr_phrase_counts = ivr_phrases_with_counts

        if remove_ivr_in_data:
            for each_ivr_phrase in custom_ivr_prompts:
                # No need to check again if its valid regex as its already checked previously.
                original_df[col_in["text"]] = original_df[col_in["text"]].str.replace(pat=each_ivr_phrase, repl="", regex=False, case=False)

        ivr_logger.info(f"Logic based detection is done in {round(time.time() - st, 3)} seconds.")

    # Add is_ivr_Section column
    st = time.time()

    # Remove last column name for renaming.
    # original_df.columns = original_df.columns.to_list()[:-1] + ["is_ivr_section?"]

    # Remove blank sentences which can happen if IVR phrase is there and selected to remove.
    null_blocks_idx = ConversationProcessor.get_blank_sentences(df=original_df, text_col=col_in["text"])
    original_df = original_df.drop(index=null_blocks_idx)
    ivr_logger.info(f"Preparing original dataframe is done in {round(time.time() - st, 3)} seconds.")

    # Rename columns if given
    if col_out_original:
        column_rename_mapping = {col_in[k]: v for k, v in col_out_original.items()}
        original_df = original_df.rename(columns=column_rename_mapping)

    if col_out_ivr and not ivr_and_replies_df.empty:
        column_rename_mapping = {col_in[k]: v for k, v in col_out_ivr.items()}
        ivr_and_replies_df = ivr_and_replies_df.rename(columns=column_rename_mapping)

    # Reset index for original df
    original_df = original_df.reset_index(drop=True)

    # if ivr df is empty, then we did not find any conv blocks with ivr
    # Thus return origin df as is, with empty df as 2nd op, empty dict as 3rd op
    if ivr_and_replies_df.empty:
        return original_df, ivr_and_replies_df, ivr_phrase_counts
    else:
        # Else depending on whether to remove_ivr_in_data, output will change.
        return original_df, ivr_and_replies_df, ivr_phrase_counts
