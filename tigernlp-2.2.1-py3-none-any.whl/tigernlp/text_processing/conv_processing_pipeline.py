import pandas as pd
from typing import List

from ..core.pipeline import Pipeline
from ..core.utils import MyLogger
from .conv_processing import ConversationProcessor
from .ivr_extraction import extract_ivr_msgs


class ConversationProcessor(ConversationProcessor):
    """
    ConversationProcessor patch which incorporates "extract_ivr_msgs" into ConversationProcessor class.
    This is so that pipeline call can contain "extract_ivr_msgs" along with methods from ConversationProcessor.

    Parameters
    ----------
    logging_level : str, optional
        Level or severity of the events needed to be tracked, by default "WARNING"
    log_file_path : str, optional
        File path to save the logs, by default None
    verbose : bool, optional
        If True logs will be printed to console, by default True
    """

    def __init__(
        self,
        logging_level: str = "WARNING",
        log_file_path: str = None,
        verbose: bool = True,
    ):
        """
        Parameters
        ----------
        logging_level : str, optional
            Level or severity of the events needed to be tracked, by default "WARNING"
        log_file_path : str, optional
            File path to save the logs, by default None
        verbose : bool, optional
            If True logs will be printed to console, by default True
        """
        super().__init__(
            logging_level=logging_level,
            log_file_path=log_file_path,
            verbose=verbose,
        )
        self.extract_ivr_msgs = extract_ivr_msgs


class ConvProcPipeline:
    """
    Pipeline class for Conversation Processing which takes in data and list of method names as string and runs them in order.

    Parameters
    ----------
    verbose : bool, optional
        If True logs will be printed to console, by default True
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None

    Examples
    --------
    >>> from tigernlp.text_processing.api import ConvProcPipeline
    >>> import pandas as pd

    >>> # Load the data
    >>> data = pd.read_csv('data.csv')

    >>> convProcPipeline = ConvProcPipeline()
    >>> processed_data = convProcPipeline.convprocessor_pipeline(
            data = data,
            methods=["remove_null_sentences", "identify_greetings", "extract_ivr_msgs"],
            skip_errors=False,
            text_col="processed_text",
            greetings_options={
                "regex_pattern": [
                    ".*?Hello, how are.*?",
                    ".*?Hello, how is.*?",
                    ".*?Hi, how.*?",
                ]
            },
            col_in={
                "id": "id",
                "conv_b_num": "conv_b_num",
                "speaker": "speaker",
                "text": "processed_text",
                "start_time": "start_time",
                "end_time": "end_time",
            },
            freq_of_phrase_occurrence=0.05,
            remove_ivr_in_data=True,
            n_jobs=1
        )

    """

    def __init__(
        self,
        verbose: bool = True,
        log_level: str = "INFO",
        log_file_path: str = None,
    ):
        """
        Parameters
        ----------
        verbose : bool, optional
            If True logs will be printed to console, by default True
        log_level : str, optional
            Level or severity of the events needed to be tracked, by default "INFO"
        log_file_path: str, optional
            File path to save the logs, by default None
        """
        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose)
        self.core_pipeline = Pipeline(log_level=log_level, log_file_path=log_file_path, verbose=verbose).pipeline
        self._conversationProcessor = ConversationProcessor(
            logging_level=log_level,
            log_file_path=log_file_path,
            verbose=verbose,
        )

    def pipeline(self, data: pd.DataFrame, methods: List[str], skip_errors: bool = False, **kwargs):
        """
        This wrapper function incorporates the usage of pipeline for conversation processing enabling running methods
        by providing it as a list of strings.

        Any function parameters required by methods can be passed directly as kwargs.

        For more information on list of available methods to run, refer to ConversationProcessor documentation.

        For all methods passed to this pipeline, the first index of result is automatically saved to data.
        Only exception is "identify_greetings" method, whose result is by default saved to a different variable.
        Refer to `03_conversational_preprocess.ipynb`, "10. Pipeline" section for more information with examples.

        Along with all the methods available in ConversationProcessor class, "extract_ivr_msgs" method is also accessible
        with this pipeline function. By default pipeline will enforce `remove_ivr_in_data=True`.
        If this default behaviour is not desired, run extract_ivr_msgs function outside this wrapper

        For "identify_greetings" method, the result will by default be saved to different variable and automatically
        passed to "extract_ivr_msgs" method as "greetings_block" parameter.

        Parameters
        ----------
        data : pd.DataFrame
            Dataframe for conversation processing
        methods : List[str]
            Method names as a list of strings, these methods will be run in the order specified
        skip_errors : bool, optional
            If a certain method name doesn't exist, raise an error or remove it from list, by default False

        Examples
        --------
        >>> convProcPipeline = ConvProcPipeline()
        >>> processed_data = convProcPipeline.convprocessor_pipeline(
                data = data,
                methods=["remove_null_sentences", "identify_greetings", "extract_ivr_msgs"],
                skip_errors=False,
                text_col="processed_text",
                greetings_options={
                    "regex_pattern": [
                        ".*?Hello, how are.*?",
                        ".*?Hello, how is.*?",
                        ".*?Hi, how.*?",
                    ]
                },
                col_in={
                    "id": "id",
                    "conv_b_num": "conv_b_num",
                    "speaker": "speaker",
                    "text": "processed_text",
                    "start_time": "start_time",
                    "end_time": "end_time",
                },
                freq_of_phrase_occurrence=0.05,
                remove_ivr_in_data=True,
                n_jobs=1
            )
        """
        # TODO: Add ability to have multiple returns for different methods
        # TODO: Add ability to provide data parameters to save results to different variables

        # If data parameters are present in kwargs, delete it
        if "data_parameters" in kwargs:
            del kwargs["data_parameters"]

        data_parameters = [("ip_df", data)]
        # By default save all results into ip_df
        kwargs["_return_index"] = 0

        for idx, method in enumerate(methods):
            # If "identify_greetings" in methods, then add data parameter and update the return_index parameter
            if "identify_greetings" in [method if isinstance(method, str) else method[0]]:
                data_parameters.append(("greetings_blocks", None))
                # If method is a string
                if isinstance(methods[idx], str):
                    # Give a tuple with return index
                    methods[idx] = (method, {"_return_index": 1})
                # If method is a tuple
                else:
                    # Replace or add _return_index with value 1
                    methods[idx][1]["_return_index"] = 1

            if "extract_ivr_msgs" in [method if isinstance(method, str) else method[0]]:
                if "remove_ivr_in_data" in kwargs:
                    if not kwargs["remove_ivr_in_data"]:
                        self.logger.warning(
                            '"remove_ivr_in_data" parameter will be set to True by default.'
                            'If this behaviour is not expected, call "extract_ivr_msgs" outside "ConvProcPipeline.pipeline".'
                        )
                elif not isinstance(method, str) and "remove_ivr_in_data" in method[1]:
                    if not method[1]["remove_ivr_in_data"]:
                        self.logger.warning(
                            '"remove_ivr_in_data" parameter will be set to True by default.'
                            'If this behaviour is not expected, call "extract_ivr_msgs" outside "ConvProcPipeline.pipeline".'
                        )

                        methods[idx][1]["remove_ivr_in_data"] = True

        # By default, if extract_ivr_msgs function is run, remove ivr from data
        # If this default behaviour is not desired, run extract_ivr_msgs function outside this wrapper
        kwargs["remove_ivr_in_data"] = True

        # Run pipeline
        result = self.core_pipeline(
            class_module=self._conversationProcessor,
            methods=methods,
            data_parameters=data_parameters,
            skip_errors=skip_errors,
            **kwargs,
        )
        # Return dataframe
        return result[0][1]
