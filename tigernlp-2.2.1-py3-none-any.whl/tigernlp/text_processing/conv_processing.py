"""This module is for data pre-processing of call and chat transcripts
from various sources.
"""

import numpy as np
import pandas as pd
import re
import warnings
from typing import Optional, Tuple, Union

from tigernlp.core.api import MyLogger, parallelize_groupby


class ConversationProcessor:
    """Utility class for pre-processing of call and chat transcripts. It is called after DataParser. Data that is passed to this class will be henceforth referred to as main dataframe.

    Standard format of the main dataframe is expected as below::

        id | conv_b_num | speaker | speaker_source | text | start_time | end_time | confidence_score

    Parameters
    ----------
    logging_level: str
        Level or severity of the events they are used to track. Acceptable values are ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True



    Examples
    --------
    >>> from tigernlp.text_processing.api import DataParser, ConversationProcessor
    >>> ip_file = "data/chat_transcripts/twiiter/sample_dataset.csv"
    >>> chat_data = DataParser(source="twitter", ip_file=ip_file)
    >>> chat_data.parse_raw_data()
    >>> conv_df = ConversationProcessor()

    """

    def __init__(
        self,
        logging_level: str = "WARNING",
        log_file_path=None,
        verbose=True,
    ) -> None:
        # Create logger object
        self.logger = MyLogger(
            level=logging_level, log_file_path=log_file_path, verbose=verbose
        ).logger

    @staticmethod
    def get_blank_sentences(df: pd.DataFrame, text_col: str) -> pd.Index:
        """For a given dataframe, this helper function returns index of the rows where text_col is blank. Sentences that has only spaces, blank, 'nan', 'null' are considered blank sentences.

        Parameters
        ----------
        df : pd.DataFrame
            Input Dataframe

        text_col : str
            Column name against which we are checking for blank sentences.

        Returns
        -------
        pd.Index
            Index of the dataframe that contains the blank sentence criteria.

        """
        # Note how many nans, blanks and "null" sentences.
        blank_sentences = df[
            (df[text_col].isnull())
            | (df[text_col].str.strip() == "")
            | (df[text_col].str.strip().str.lower() == "null")
            | (df[text_col].str.strip().str.lower() == "nan")
        ]

        return blank_sentences.index

    def remove_null_sentences(self, ip_df: pd.DataFrame, text_col: str) -> pd.DataFrame:
        """Drop all sentences/rows which doesn't have any text in them or populated with a string "null". Sentences that has only spaces, blank, 'nan', 'null' are considered blank sentences. It returns a modified copy of the input dataframe.

        Parameters
        ----------
        ip_df: pd.DataFrame
            It is recommended to have input dataframe in standard format. Otherwise, should atleast contain ``text_col`` column in the dataframe.

        text_col : str
            Column which contains the text

        Returns
        -------
        pd.Dataframe
            Modified Dataframe which removes conversation that has blank sentences.

        Raises
        ------
        ValueError
            If any of the arguments is missing or invalid

        Examples
        --------
        >>> from tigernlp.text_processing.api import ConversationProcessor
        >>> conv_df = ConversationProcessor()
        >>> cleaned_df = conv_df.remove_null_sentences(ip_df=chat_data.data ,text_col="text")
        """
        if text_col is None:
            self.logger.error(f"Bad input passed to text_col {text_col}")
            raise ValueError("Bad ip text_col")
        elif ip_df is None or not isinstance(ip_df, pd.DataFrame):
            self.logger.error(
                f"Input dataframe is of incorrect type {type(ip_df)}. Cannot proceed further"
                "Requires an input dataframe"
            )
            raise ValueError("Input dataframe is not set or incorrect type in this method")
        elif text_col not in ip_df.columns.tolist():
            self.logger.error(
                f"Given text_column is not a valid column in the input dataframe - {text_col}"
            )
            raise ValueError(
                "Bad ip. Given text_column is not a valid column in the input dataframe."
            )

        # Note how many nans, blanks and "null" sentences.
        null_txt_idx = ConversationProcessor.get_blank_sentences(df=ip_df, text_col=text_col)

        self.logger.debug(
            f"Out of {ip_df.shape[0]} rows, there are about {null_txt_idx.shape[0]} rows with invalid (null/ NA/ empty) texts",
        )

        # Remove invalid text
        cleaned_df = ip_df.drop(index=null_txt_idx)
        self.logger.debug("Removing null sentences completed")

        return cleaned_df

    def remove_blocks_starting_with(
        self, ip_df: pd.DataFrame, text_col: str, starting_with: str
    ) -> pd.DataFrame:
        """Remove conversation blocks that begin with certain pattern. Can be used for removing conversation blocks that begin with certain machine prompt indicators. Depending on the source and whether if it is speech to text data or chat data, bot prompts may not be present. This is done as they may not be useful for NLP downstream tasks.

        Parameters
        ----------
        ip_df: pd.DataFrame
            It is recommended to have input dataframe in standard format. Otherwise, should atleast contain ``text_col`` column in the dataframe.

        text_col : str
            Column which contains the text

        starting_with : str
            Text value to search the beginning of the conversation blocks and remove.

            For example: "intentArray:"

        Returns
        -------
        pd.Dataframe
            Modified Dataframe which removes conversation that has blank sentences.

        Raises
        ------
        ValueError
            if any of the arguments is missing or invalid.

        Examples
        --------
        >>> from tigernlp.text_processing.api import ConversationProcessor
        >>> conv_df = ConversationProcessor()
        >>> cleaned_df = conv_df.remove_blocks_starting_with(text_col="text", starting_with="intentArray:")
        """
        if text_col is None:
            self.logger.error(f"Bad input passed to text_col - {text_col}")
            raise ValueError("Bad ip text_col.")
        if ip_df is None or not isinstance(ip_df, pd.DataFrame):
            self.logger.error(
                f"Input dataframe is of incorrect type - {type(ip_df)}. Cannot proceed further"
                "Requires an input dataframe"
            )
            raise ValueError("Input dataframe is not set or incorrect type in this method")
        if text_col not in ip_df.columns.tolist():
            self.logger.error(
                f"Given text_column is not a valid column in the input dataframe. - {text_col}"
            )
            raise ValueError(
                "Bad ip. Given text_column is not a valid column in the input dataframe."
            )

        conv_blocks_affected = ip_df[ip_df[text_col].str.startswith(starting_with, na=False)]
        self.logger.debug(
            f"Total number of conversation blocks affected = {conv_blocks_affected.shape[0]}"
        )

        cleaned_df = ip_df.drop(index=conv_blocks_affected.index)
        self.logger.debug("Removing null sentences completed.")

        return cleaned_df

    @staticmethod
    def create_full_conv_for_speaker(
        conv_df: pd.DataFrame, speaker: Union[int, str], speaker_col: str
    ) -> pd.DataFrame:
        """Filter all conversation of a given speaker from a dataframe and return it as a dataframe

        Parameters
        ----------
        conv_df: pd.Dataframe
            Input dataframe containing text at conversation block.

        speaker: Union[int,str]
            Whether to form chunks for customer conversation or agent conversation by using this value.

        speaker_col: str
            Column name in the main dataframe that contains the speaker ids.

        Returns
        -------
        pd.Dataframe
            Full conversation of given ``speaker``

        Examples
        --------
        >>> speaker_only_blocks = create_full_conv_for_speaker(speaker="1", conv_df=conversation_block_df)

        """
        # .query() doesn't seem to work when column name is a variable. it's throwing Keyerror : False error.
        # Hence, using .loc
        return conv_df.loc[conv_df[speaker_col] == speaker].copy(deep=True)

    def _create_rolling_chunks_parallelization(
        self, call_conv: pd.DataFrame, num_conv_blocks: int, col_in: dict
    ) -> pd.DataFrame:
        """Helper method to parallelize rolling chunks. This func gets called for each call.

        Parameters
        ----------
        num_conv_blocks : int
            Number of conversation blocks to merge to create a chunk

        ip_conv : pd.Dataframe
            Input dataframe at conversation block level

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging into chunks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speakerid",
                    "conv_b_num": "conv_b_num",
                    "text": "text"
                }


        Returns
        -------
        pd.Dataframe
            Rolling conversation chunks
        """
        id_data = []
        chunk_text = []
        chunk_ids = []
        merged_conv_blocks = []
        id = call_conv[col_in["id"]].unique()[0]

        i = 0
        j = num_conv_blocks

        if (
            num_conv_blocks > call_conv.shape[0]
        ):  # There has to be atleast blocks of chunksize else append
            id_data.append(id)
            chunk_text.append("|".join(call_conv[col_in["text"]]))
            chunk_ids.append(1)
            merged_conv_blocks.append(",".join(call_conv[col_in["conv_b_num"]]))

        for chunk_id in range(
            1, call_conv.shape[0] - num_conv_blocks + 2
        ):  # Repeat till we reach last text for each Id.
            id_data.append(id)
            chunk_text.append("|".join(call_conv[col_in["text"]].iloc[i:j].to_list()))
            chunk_ids.append(chunk_id)
            merged_conv_blocks.append(
                ",".join(call_conv[col_in["conv_b_num"]].iloc[i:j].to_list())
            )
            i += 1
            j += 1

        chunks = pd.DataFrame(
            data={
                col_in["id"]: id_data,
                "chunk_id": chunk_ids,
                col_in["text"]: chunk_text,
                "merged_conv_blocks": merged_conv_blocks,
            }
        )

        return chunks

    def _create_rolling_chunks(
        self, num_conv_blocks: int, ip_conv: pd.DataFrame, col_in: dict, n_jobs: int
    ) -> pd.DataFrame:
        """Create rolling conversation chunks from given ``ip_conv`` df. Number of conversation blocks to merge is given by ``num_conv_blocks`` parameter. Different conversation blocks in a conversation chunk will be separated by '|'

            Ex: If ``num_conv_blocks`` = 3, then conversation blocks will be formed by joining following conversation blocks
                (1, 2, 3), (2, 3, 4), (3, 4, 5), (4, 5, 6)...

        Parameters
        ----------
        num_conv_blocks : int
            Number of conversation blocks to merge to create a chunk

        ip_conv : pd.Dataframe
            Input dataframe at conversation block level

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging into chunks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speakerid",
                    "conv_b_num": "conv_b_num",
                    "text": "text"
                }

        n_jobs : int
            Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

        Returns
        -------
        pd.Dataframe
            Rolling conversation chunks
        """
        rolling_kwargs = {"num_conv_blocks": num_conv_blocks, "col_in": col_in}
        rolling_chunks = parallelize_groupby(
            df=ip_conv,
            groupby_cols=col_in["id"],
            func=self._create_rolling_chunks_parallelization,
            kwargs=rolling_kwargs,
            n_jobs=n_jobs,
        )

        rolling_chunks = rolling_chunks.reset_index(drop=True)

        return rolling_chunks

    def _create_non_rolling_chunks(
        self, num_conv_blocks: int, ip_conv: pd.DataFrame, col_in: dict
    ) -> pd.DataFrame:
        """Create non-rolling conversation chunks from given ``ip_conv`` df. Number of conversation blocks to merge is given by ``num_conv_blocks`` parameter. Different conversation blocks in a conversation chunk will be separated by '|'

            Ex: If ``num_conv_blocks`` = 3, then conversation blocks will be formed by joining following conversation blocks
                (1, 2, 3), (4, 5, 6), (7 ,8, 9), (10, 11, 12)...

        Parameters
        ----------
        num_conv_blocks : int
            Number of conversation blocks to merge to create a chunk

        ip_conv : pd.Dataframe
            Input dataframe at conversation block level.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging into chunks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speakerid",
                    "conv_b_num": "conv_b_num",
                    "text": "text"
                }


        Returns
        -------
        pd.Dataframe
            Non-rolling conversation chunks
        """
        ip_conv["counter"] = ip_conv.groupby(col_in["id"]).cumcount() + 1
        ip_conv["counter"] = ip_conv["counter"].mod(num_conv_blocks)
        # After taking modulus, we will get 0 everytime we reach multiple of chunk size.
        # Thus, when we encounter 0, we will reach next chunk
        ip_conv["chunk_id"] = (ip_conv["counter"] == 0).cumsum() + 1

        # Rename columns to output
        ip_conv = (
            ip_conv.groupby([col_in["id"], "chunk_id"])
            .agg({col_in["text"]: "|".join, "merged_conv_blocks": ",".join})
            .reset_index()
        )

        return ip_conv

    def _create_chunks_without_word_limit(
        self,
        num_conv_blocks: int,
        rolling_chunks: bool,
        conv_df: pd.DataFrame,
        col_in: dict,
        n_jobs: int = 1,
        speaker: Union[int, str] = None,
    ) -> pd.DataFrame:
        """Create conversation chunks considering ``num_conv_blocks`` at a time without any word limit. Whether to create chunks using rolling conversation blocks is a user parameter

            Ex:
            If ``num_conv_blocks`` = 3 and ``rolling_chunks`` = True, then conversation blocks will be formed by joining following conversation blocks
                (1, 2, 3), (2, 3, 4), (3, 4, 5), (4, 5, 6)...

            If ``num_conv_blocks`` = 3 and ``rolling_chunks`` = False, then conversation blocks will be formed by joining following conversation blocks
                (1, 2, 3), (4, 5, 6), (7 ,8, 9), (10, 11, 12)...

        Parameters
        ----------
        num_conv_blocks : int
            Size of each chunks

        rolling_chunks : bool
            Whether to have a rolling chunk or not

        speaker : Union[int, str]
            Whether to form chunks for customer conversation or agent conversation, optional, defaulted to None

        conv_df : pd.Dataframe
            Input dataframe

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging into chunks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speakerid",
                    "conv_b_num": "conv_b_num",
                    "text": "text"
                }

        n_jobs : int
            Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

        Returns
        -------
        pd.Dataframe
            Conversation chunks
        """
        if speaker is not None:
            conv_df = ConversationProcessor.create_full_conv_for_speaker(
                speaker=speaker, conv_df=conv_df, speaker_col=col_in["speaker"]
            )

        if rolling_chunks:
            chunks = self._create_rolling_chunks(
                num_conv_blocks=num_conv_blocks,
                ip_conv=conv_df,
                col_in=col_in,
                n_jobs=n_jobs,
            )
        else:
            chunks = self._create_non_rolling_chunks(
                num_conv_blocks=num_conv_blocks, ip_conv=conv_df, col_in=col_in
            )

        return chunks

    def _create_rolling_chunks_with_word_limit_parallel(
        self,
        conv_df: pd.DataFrame,
        num_words: int,
        col_in: dict,
    ) -> pd.DataFrame:
        """Helper method to parallelize generation of conversation chunks with word limit. This is for each call.

        Parameters
        ----------
        num_words : int
            Minimum number of words required to be considered as a conversation chunk.

        conv_df : pd.DataFrame
            Input dataframe

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging into chunks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speakerid",
                    "conv_b_num": "conv_b_num",
                    "text": "text"
                }

        Returns
        -------
        pd.DataFrame
            Dataframe containing the conversation chunk
        """
        current_call_id = conv_df[col_in["id"]].unique()[0]
        rolling_chunks_text = []
        chunk_id = 1
        for parent_row_idx in range(conv_df.shape[0]):
            prev_word_count = 0
            chunk_txt = ""
            conv_block_num = ""

            for child_row_idx in range(parent_row_idx, conv_df.shape[0]):
                current_child_row = conv_df.iloc[child_row_idx]

                # Start of rolling chunk
                if parent_row_idx == child_row_idx:
                    prev_word_count = current_child_row["total_words"]
                    chunk_txt = current_child_row[col_in["text"]]
                    conv_block_num = current_child_row[col_in["conv_b_num"]]

                    # Starting row itself satisfied num_words criteria.
                    if prev_word_count >= num_words:
                        rolling_chunks_text.append(
                            (current_call_id, chunk_id, chunk_txt, conv_block_num)
                        )
                        chunk_id += 1
                        break
                else:  # Subsequent rows from the starting point.
                    prev_word_count += current_child_row["total_words"]
                    chunk_txt = chunk_txt + "|" + current_child_row[col_in["text"]]
                    conv_block_num = conv_block_num + "," + current_child_row[col_in["conv_b_num"]]

                    if prev_word_count >= num_words:
                        rolling_chunks_text.append(
                            (current_call_id, chunk_id, chunk_txt, conv_block_num)
                        )
                        chunk_id += 1
                        break

            # Add whatever its left for child iteration if it fails to meet num_words criteria.
            if prev_word_count < num_words:
                rolling_chunks_text.append((current_call_id, chunk_id, chunk_txt, conv_block_num))
                chunk_id += 1

        chunk = pd.DataFrame(
            data=rolling_chunks_text,
            columns=[col_in["id"], "chunk_id", col_in["text"], "merged_conv_blocks"],
        )

        return chunk

    def _create_rolling_chunks_with_word_limit(
        self,
        num_words: int,
        conv_df: pd.DataFrame,
        col_in: dict,
        n_jobs: int,
        speaker: Union[int, str] = None,
    ) -> pd.DataFrame:
        """Create rolling conversation chunks of dynamic window size based on ``num_words``. It will dynamically add more conversation blocks to the chunk until ``num_words`` limit is reached and then creates the chunk. This is slower as it's time complexity is O(n^2) where n is number of rows

            Ex: Conversation blocks (1, 2, 3, 4, 5, 6), (2, 3, 4, 5, 6, 7), (3, 4, 5, 6, 7), (4, 5, 6, 7, 8), (5, 6, 7, 8), (6, 7, 8) ... can be conversation chunks, given that sum of words in (1, 2, 3, 4, 5) < ``num_words`` < sum of words in (1, 2, 3, 4, 5, 6)

        Parameters
        ----------
        speaker : Union[int, str]
            Whether to form chunks for customer conversation or agent conversation, optional, defaulted to None

        num_words : int
            Minimum number of words required to be considered as a conversation chunk.

        conv_df : pd.DataFrame
            Input dataframe

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging into chunks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speakerid",
                    "conv_b_num": "conv_b_num",
                    "text": "text"
                }

        n_jobs : int
            Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

        Returns
        -------
        pd.DataFrame
            Dataframe containing the conversation chunks
        """
        if speaker is not None:
            conv_df = ConversationProcessor.create_full_conv_for_speaker(
                speaker=speaker, conv_df=conv_df, speaker_col=col_in["speaker"]
            )

        conv_df["total_words"] = conv_df[col_in["text"]].str.split().str.len()

        chunk_kwargs = {"num_words": num_words, "col_in": col_in}
        chunks = parallelize_groupby(
            df=conv_df,
            groupby_cols=col_in["id"],
            func=self._create_rolling_chunks_with_word_limit_parallel,
            kwargs=chunk_kwargs,
            n_jobs=n_jobs,
        )

        chunks = chunks.reset_index(drop=True)

        return chunks

    def _create_nonrolling_chunks_with_word_limit_parallel(
        self,
        conv_df: pd.DataFrame,
        num_words: int,
        col_in: dict,
    ) -> pd.DataFrame:
        """Helper method to parallelize creation of non rolling chunks with word limit. This is at call level.

        Parameters
        ----------
        num_words : int
            Minimum number of words required to be considered as a conversation chunk

        conv_df : pd.DataFrame
            Input dataframe

        rolling_chunks: bool
            Whether chunks will be formed by combining conversation blocks in rolling manner

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging into chunks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speakerid",
                    "conv_b_num": "conv_b_num",
                    "text": "text"
                }

        Returns
        -------
        pd.DataFrame
            Conversation chunk
        """
        current_call_id = conv_df[col_in["id"]].unique()[0]

        prev = 0
        rolling_chunks_text = []
        prev_chunk = 1
        for _, row in conv_df.iterrows():
            if prev == 0:
                chunk_text = row[col_in["text"]]
                conv_block_num = row[col_in["conv_b_num"]]
            else:
                chunk_text = chunk_text + "|" + row[col_in["text"]]
                conv_block_num = conv_block_num + "," + row[col_in["conv_b_num"]]

            if row["total_words"] + prev >= num_words:
                prev = 0
                rolling_chunks_text.append(
                    (current_call_id, prev_chunk, chunk_text, conv_block_num)
                )
                prev_chunk += 1
            else:
                prev += row["total_words"]

        # Add whatever thats left over after exhausting all blocks in a call.
        if prev < num_words:
            rolling_chunks_text.append((current_call_id, prev_chunk, chunk_text, conv_block_num))

        chunk = pd.DataFrame(
            data=rolling_chunks_text,
            columns=[col_in["id"], "chunk_id", col_in["text"], "merged_conv_blocks"],
        )

        return chunk

    def _create_chunks_with_word_limit(
        self,
        num_words: int,
        rolling_chunks: bool,
        conv_df: pd.DataFrame,
        col_in: dict,
        n_jobs: int,
        speaker: Union[int, str] = None,
    ) -> pd.DataFrame:
        """Create Conversation chunks based on word limit (``num_words``), rolling, and speaker.

        Parameters
        ----------
        speaker : Union[int,str]
            Whether to form chunks for customer conversation or agent conversation, optional, defaulted to None

        num_words : int
            Minimum number of words required to be considered as a conversation chunk

        conv_df : pd.DataFrame
            Input dataframe

        rolling_chunks: bool
            Whether chunks will be formed by combining conversation blocks in rolling manner

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging into chunks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speakerid",
                    "conv_b_num": "conv_b_num",
                    "text": "text"
                }

        n_jobs : int
            Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

        Returns
        -------
        pd.DataFrame
            Conversation chunk
        """
        # TODO - Think about adding a rolling window feature
        # TODO [to review]: Need to see if adding striding feature can be done.
        # TODO S - I meant rolling window size feature
        if speaker is not None:
            conv_df = ConversationProcessor.create_full_conv_for_speaker(
                speaker=speaker, conv_df=conv_df, speaker_col=col_in["speaker"]
            )

        conv_df["total_words"] = conv_df[col_in["text"]].str.split().str.len()
        if rolling_chunks:
            return self._create_rolling_chunks_with_word_limit(
                speaker=speaker, num_words=num_words, conv_df=conv_df, col_in=col_in, n_jobs=n_jobs
            )
        else:
            nonrolling_kwargs = {
                "num_words": num_words,
                "col_in": col_in,
            }
            chunks = parallelize_groupby(
                df=conv_df,
                groupby_cols=col_in["id"],
                func=self._create_nonrolling_chunks_with_word_limit_parallel,
                kwargs=nonrolling_kwargs,
                n_jobs=n_jobs,
            )

            chunks = chunks.reset_index(drop=True)

            return chunks

    def conv_block_to_conv_chunks(
        self,
        ip_df: pd.DataFrame,
        col_in: dict,
        col_out: dict,
        num_conv_blocks: int = None,
        num_words: int = None,
        speaker: Union[int, str] = None,
        rolling_chunks: bool = False,
        n_jobs: int = 1,
    ) -> pd.DataFrame:
        """Merge Conversation blocks to create Conversation chunks of provided size (``num_conv_blocks``), number of words (``num_words``), Chunk will be pipe separated conversations. By definition a conversation chunk is a group of conversation blocks appended together that can be used for downstream activities like text matching as this will retain more context. Different conversation blocks within a conversation chunk are seperated by '|'.

        We can either create chunks based on ``num_words`` or ``num_conv_blocks``. ``speaker`` is optional argument. We can not have both ``num_conv_blocks`` and ``num_words`` as we keep adding or subtracting conv block to meet the minimumn ``num_words`` criteria
        If both options are given, ValueError will be raised indicating that only one of them need to be passed.

        Ex: Conversation blocks (1, 2, 3, 4, 5, 6), (2, 3, 4, 5, 6, 7), (3, 4, 5, 6, 7), (4, 5, 6, 7, 8), (5, 6, 7, 8), (6, 7, 8) ... can be conversation chunks, given that sum of words in (1, 2, 3, 4, 5) < ``num_words`` < sum of words in (1, 2, 3, 4, 5, 6) and ``rolling_chunks`` = True

        Parameters
        ----------
        ip_df: pd.DataFrame
            It is recommended to have input dataframe in standard format. Otherwise, should atleast contain mandatory columns mentioned in ``col_in`` parameter.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging into chunks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speakerid",
                    "conv_b_num": "conv_b_num",
                    "text": "text"
                }

        col_out : dict
            Output column names mappings which has the resulting conversation chunks dataframe. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names you wish to see in the output dataframe.

            For example::

                {
                    "id": "call_id",
                    "chunk_id": "chunk_num",
                    "text": "conv_chunks"
                }

        num_conv_blocks : int
            Number of conversation that needs to put together as a chunk. defaulted to None.

        rolling_chunks: bool
            Whether to have a chunk like (1,2,3), (2,3,4),. or (1,2,3), (4,5,6). defaulted to False.

        num_words: int
            Minimum number of words needed to consider a group of text as a chunk, optional, defaulted to None

        speaker:  Union[int,str]
            Whether to form chunks for customer conversation or agent conversation, optional, defaulted to None

        n_jobs : int
            Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

        Returns
        -------
        pd.DataFrame
            Resulting Dataframe will be in standard format but columns such as speaker, confidence score, start_time and end_time will be set to nan.

        Raises
        ------
        ValueError
            If both num_words and (num_conv_blocks, rolling) options are entered, error will be raised.

        Examples
        --------
        >>> ip_cols = {
            "id": "call_id",
            "speaker": "speaker",
            "conv_b_num": "conv_b_num",
            "text": "text"
            }
        >>> op_cols = {
            "id": "call_id",
            "chunk_id": "chunk#",
            "text": "chunks"
            }
        >>> conv_chunks = conv_df.conv_block_to_conv_chunks(ip_df=chat_data.data, col_in=ip_cols, col_out=op_cols, num_conv_blocks=5, rolling_chunks=True)

        """
        # Input Parameters combination
        if ip_df is None or not isinstance(ip_df, pd.DataFrame):
            raise ValueError("ip_df must be valued.")
        elif col_in is None or col_out is None:
            raise ValueError("col_in and col_out are mandatory arguments.")
        elif any(x not in col_in.keys() for x in ["id", "speaker", "conv_b_num", "text"]) or any(
            x not in col_out.keys() for x in ["id", "chunk_id", "text"]
        ):
            raise ValueError("col_in/col_out have missing information/keys.")
        elif num_words is not None and num_conv_blocks is not None:
            raise ValueError(
                "Choose Conversation Chunk grouping either by num_words or by num_conv_blocks"
            )

        conv_df = ip_df.sort_values(by=[col_in["id"], col_in["conv_b_num"]]).copy(deep=True)
        # Cast to str so that it can be concatenated to form merged_conv_blocks column.
        conv_df[col_in["conv_b_num"]] = conv_df[col_in["conv_b_num"]].astype("str")

        # If num_words is not given, we can simply append by other options without checking on
        # word limit
        if num_words is None:
            conv_chunks = self._create_chunks_without_word_limit(
                num_conv_blocks=num_conv_blocks,
                rolling_chunks=rolling_chunks,
                speaker=speaker,
                conv_df=conv_df,
                col_in=col_in,
                n_jobs=n_jobs,
            )
        else:
            conv_chunks = self._create_chunks_with_word_limit(
                speaker=speaker,
                num_words=num_words,
                conv_df=conv_df,
                rolling_chunks=rolling_chunks,
                col_in=col_in,
                n_jobs=n_jobs,
            )

        column_rename_mapping = {
            col_in["id"]: col_out["id"],
            col_in["text"]: col_out["text"],
            "chunk_id": col_out["chunk_id"],
        }
        conv_chunks = conv_chunks.rename(columns=column_rename_mapping)

        # Create nan columns so thats in standard format
        self.logger.info(
            "Creating empty columns so that resulting dataframe is in standard format."
        )
        conv_chunks["speaker"] = np.nan
        conv_chunks["speaker_source"] = np.nan
        conv_chunks["start_time"] = np.nan
        conv_chunks["end_time"] = np.nan
        conv_chunks["confidence_score"] = np.nan

        return conv_chunks

    def _filter_call_by_percent(
        self, ip_df: pd.DataFrame, col_in: dict, call_pct: float, direction: str
    ) -> Tuple[pd.DataFrame, pd.Series]:
        """Helper function to select call by percentage.

        Parameters
        ----------
        ip_df: pd.DataFrame
            It is recommended to have input dataframe in standard format. Otherwise, should atleast contain mandatory columns mentioned in ``col_in`` parameter.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for filtering percentage of conversation in a call. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "conv_b_num": "conv_b_num",
                }

        call_pct : float
            Enter number between 0 to 100. ``call_pct`` of total conversation blocks per call will be selected.

        direction: str
            Acceptable values are 'first' and 'last'. If 'first', selection will start from first row. If 'last', selection will start from last row. by default, it's 'first'.

        Returns
        -------
        Tuple[pd.DataFrame, pd.Series]

            pd.DataFrame
                For each call, it contains call_pct of overall conversation.

            pd.Series
                It contains selected mask of boolean indexes for the original dataframe. It is used for reporting.
        """
        # Form group of each call.
        conv_grp = ip_df.groupby(col_in["id"])

        # In each group, number each row in order and check if its less than calculated "n" based on %
        if direction == "first":
            selected_mask = (conv_grp.cumcount() + 1) <= (
                conv_grp[col_in["id"]].transform("size") * (call_pct / 100)
            )
        else:
            # Flip the percentage so we select last call_pct rows
            call_pct = 100 - call_pct
            selected_mask = (conv_grp.cumcount() + 1) > (
                conv_grp[col_in["id"]].transform("size") * (call_pct / 100)
            )

        selected_call_pct = ip_df.loc[selected_mask].reset_index(drop=True)

        return selected_call_pct, selected_mask

    def _filter_call_by_blockcount(
        self, ip_df: pd.DataFrame, col_in: dict, num_blocks_to_remove: int, direction: str
    ) -> Tuple[pd.DataFrame, pd.Series]:
        """Helper function to select call by absolute number of blocks.

        Parameters
        ----------
        ip_df: pd.DataFrame
            It is recommended to have input dataframe in standard format. Otherwise, should atleast contain mandatory columns mentioned in ``col_in`` parameter.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for filtering percentage of conversation in a call. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "conv_b_num": "conv_b_num",
                }

        num_blocks_to_remove: int
            Number of conversation blocks to remove. If a number is entered which is more than the number of conversation blocks in a call, all blocks will be selected.

        direction: str
            Acceptable values are 'first' and 'last'. If 'first', selection will start from first row. If 'last', selection will start from last row. by default, it's 'first'.

        Returns
        -------
        Tuple[pd.DataFrame, pd.Series]

            pd.DataFrame
                For each call, it contains call_pct of overall conversation.

            pd.Series
                It contains selected mask of boolean indexes for the original dataframe. It is used for reporting.
        """
        # Form group of each call.
        conv_grp = ip_df.groupby(col_in["id"])

        if direction == "first":
            selected_mask = (conv_grp.cumcount() + 1) <= num_blocks_to_remove
        else:
            grp_block_value = conv_grp[col_in["id"]].transform("size") - num_blocks_to_remove
            grp_block_value[grp_block_value < 1] = 0
            selected_mask = (conv_grp.cumcount() + 1) > grp_block_value

        selected_call_pct = ip_df.loc[selected_mask].reset_index(drop=True)

        return selected_call_pct, selected_mask

    def _filter_call_by_duration(
        self,
        ip_df: pd.DataFrame,
        col_in: dict,
        call_duration: float,
        direction: str,
        start_time_null_flag: bool,
        end_time_null_flag: bool,
    ) -> Tuple[pd.DataFrame, pd.Series]:
        """Helper function to select calls by duration.

        Parameters
        ----------
        ip_df: pd.DataFrame
            It is recommended to have input dataframe in standard format. Otherwise, should atleast contain mandatory columns mentioned in ``col_in`` parameter.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for filtering percentage of conversation in a call. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "conv_b_num": "conv_b_num",
                    "start_time": "start_time",
                    "end_time": "end_time"
                }

        call_duration: float
            Duration of the call in seconds that will be selected in each call.

        direction: str
            Acceptable values are 'first' and 'last'. If 'first', selection will start from first row. If 'last', selection will start from last row. by default, it's 'first'.

        start_time_null_flag : bool
            Indicates whether start time column has null/NaN values thereby making it ineligible for duration calculation.

        end_time_null_flag : bool
            Indicates whether end time column has null/NaN values thereby making it ineligible for duration calculation.

        Returns
        -------
        Tuple[pd.DataFrame, pd.Series]

            pd.DataFrame
                For each call, it contains call_pct of overall conversation.

            pd.Series
                It contains selected mask of boolean indexes for the original dataframe. It is used for reporting.

        Raises
        ------
        ValueError
            if timestamp columns such as start_time and end_time is neither float/int nor datetime format.
        """
        # Create temp columns for easier calculation
        try:
            # Most of the call transcripts after parsing are in seconds.
            if not start_time_null_flag:
                ip_df["st"] = pd.to_timedelta(ip_df[col_in["start_time"]], unit="S")

            if not end_time_null_flag:
                ip_df["end"] = pd.to_timedelta(ip_df[col_in["end_time"]], unit="S")
        except ValueError:
            # Some chat transcript can be in datetime format.
            try:
                if not start_time_null_flag:
                    ip_df["st"] = pd.to_datetime(ip_df[col_in["start_time"]], error="raise")

                if not end_time_null_flag:
                    ip_df["st"] = pd.to_datetime(ip_df[col_in["end_time"]], error="raise")
            except:
                # if its neither in seconds nor in datetime, we cannot proceed further so raise error
                self.logger.error(
                    "timestamp columns are neither in seconds format i.e., float or int nor in datetime format."
                )
                raise ValueError("Timestamp columns are not in correct format.")

        # Form group of each call.
        conv_grp = ip_df.groupby(col_in["id"])

        if not start_time_null_flag and not end_time_null_flag:
            # Both start and end time are populated. hence call duration is end time of each block - start time of each call
            if direction == "first":
                ip_df["duration"] = (
                    ip_df["end"] - conv_grp["st"].transform("first")
                ).dt.total_seconds()
            else:
                ip_df["duration"] = (
                    conv_grp["end"].transform("last") - ip_df["st"]
                ).dt.total_seconds()

        elif not start_time_null_flag and end_time_null_flag:
            # Start time is not populated but not end time.
            if direction == "first":
                ip_df["duration"] = (
                    ip_df["st"] - conv_grp["st"].transform("first")
                ).dt.total_seconds()
            else:
                ip_df["duration"] = (
                    conv_grp["st"].transform("last") - ip_df["st"]
                ).dt.total_seconds()

        else:
            # End time is populated but not start time.
            if direction == "first":
                ip_df["duration"] = (
                    ip_df["end"] - conv_grp["end"].transform("first")
                ).dt.total_seconds()
            else:
                ip_df["duration"] = (
                    conv_grp["end"].transform("last") - ip_df["end"]
                ).dt.total_seconds()

        selected_mask = ip_df["duration"] <= call_duration

        ip_df = ip_df.drop(columns=["duration", "st", "end"])

        selected_call_pct = ip_df.loc[selected_mask].reset_index(drop=True)

        return selected_call_pct, selected_mask

    def filter_conversations(
        self,
        ip_df: pd.DataFrame,
        col_in: dict,
        call_pct: float = None,
        num_blocks_to_remove: int = None,
        call_duration: float = None,
        direction: str = "first",
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Select and filter the top percentage of call out of overall call based on conversation block count

        Parameters
        ----------
        ip_df: pd.DataFrame
            It is recommended to have input dataframe in standard format. Otherwise, should atleast contain mandatory columns mentioned in ``col_in`` parameter.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for filtering percentage of conversation in a call. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "conv_b_num": "conv_b_num",
                    "start_time": "start_time",
                    "end_time": "end_time"
                }

        call_pct : float
            Enter number between 0 to 100. ``call_pct`` of total conversation blocks per call will be selected.

        num_blocks_to_remove: int
            Number of conversation blocks to remove. If a number is entered which is more than the number of conversation blocks in a call, all blocks will be selected.

        call_duration: float
            Duration of the call in seconds that will be selected in each call.

        direction: str
            Acceptable values are 'first' and 'last'. If 'first', selection will start from first row. If 'last', selection will start from last row. by default, it's 'first'.

        Returns
        -------
        Tuple[pd.DataFrame, pd.DataFrame]

            pd.DataFrame
                For each call, it contains call_pct of overall conversation.

            pd.DataFrame
                Logs in the form of dataframe with following columns.

                id | num_blocks_original | num_blocks_filtered | entire_call_dropped

        Raises
        ------
        ValueError
            If any of the arguments is missing or invalid.

        Examples
        --------
        >>> ip_cols = {
                "id": "call_id",
                "conv_b_num": "conv_b_num"
            }
        >>> selected_conv_for_each_call, call_pct_logs = conv_df.filter_conversations(ip_df=chat_data.data, col_in=ip_cols, call_pct=70)

        """
        if ip_df is None or not isinstance(ip_df, pd.DataFrame):
            raise ValueError("ip_df must be valued.")
        elif col_in is None:
            raise ValueError("col_in is mandatory argument.")
        elif any(x not in col_in.keys() for x in ["id", "conv_b_num"]):
            raise ValueError("col_in is missing information/keys.")
        elif num_blocks_to_remove is not None and not isinstance(num_blocks_to_remove, int):
            raise ValueError("num_blocks_to_remove must be an integer.")
        elif (
            call_duration is not None
            and not isinstance(call_duration, float)
            and not isinstance(call_duration, int)
        ):
            raise ValueError("call_duration must be either float or integer.")
        elif call_duration is not None and any(
            x not in col_in.keys() for x in ["id", "conv_b_num", "start_time", "end_time"]
        ):
            raise ValueError("col_in is missing information/keys.")
        elif direction not in ["first", "last"]:
            raise ValueError("Acceptable values in direction are 'first' and 'last'")

        # Sort each call by the conversation number.
        ip_df = ip_df.sort_values(by=[col_in["id"], col_in["conv_b_num"]])
        conv_grp = ip_df.groupby(col_in["id"])

        # Decide which type of filtering will be performed based on parameters.
        # filter conversation based on percentage.
        if call_pct is not None:
            filtered_df, selected_mask = self._filter_call_by_percent(
                ip_df=ip_df, col_in=col_in, call_pct=call_pct, direction=direction
            )
        # Filter based on absolute number of conversation blocks
        elif num_blocks_to_remove is not None:
            filtered_df, selected_mask = self._filter_call_by_blockcount(
                ip_df=ip_df,
                col_in=col_in,
                num_blocks_to_remove=num_blocks_to_remove,
                direction=direction,
            )
        # Filter based on call duration.
        elif call_duration is not None:
            start_time_null_flag = False
            end_time_null_flag = False
            # Atleast one time column should be not null
            if any(ip_df[col_in["start_time"]].isnull()):
                start_time_null_flag = True

            if any(ip_df[col_in["end_time"]].isnull()):
                end_time_null_flag = True

            if start_time_null_flag and end_time_null_flag:
                raise ValueError(
                    "filtering by call duration is not possible when timestamp columns have null values in them."
                )

            filtered_df, selected_mask = self._filter_call_by_duration(
                ip_df=ip_df,
                col_in=col_in,
                call_duration=call_duration,
                direction=direction,
                start_time_null_flag=start_time_null_flag,
                end_time_null_flag=end_time_null_flag,
            )
        else:
            self.logger.error("None of the filtering options are entered.")
            raise ValueError("None of the filtering options are entered.")

        filtered = ip_df.loc[~selected_mask].reset_index().copy(deep=True)
        full = conv_grp[col_in["id"]].agg(num_blocks_original="size").reset_index()
        filtered_metadata = (
            filtered.groupby(col_in["id"])[col_in["id"]]
            .agg(num_blocks_filtered="size")
            .reset_index()
        )
        call_pct_rpt = pd.merge(
            left=full,
            right=filtered_metadata,
            how="left",
            on=col_in["id"],
        )
        call_pct_rpt["num_blocks_filtered"] = call_pct_rpt["num_blocks_filtered"].fillna(0)
        call_pct_rpt["entire_call_dropped"] = (
            call_pct_rpt["num_blocks_original"] == call_pct_rpt["num_blocks_filtered"]
        )

        return filtered_df, call_pct_rpt

    def call_funnel(
        self, ip_df: pd.DataFrame, funnel_options: dict, col_in: dict
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """Create flags for considering and filtering (funneling) calls that satisfy certain filter criteria. Filtered df will be returned as an output

        Parameters
        ----------
        ip_df: pd.DataFrame
            It is recommended to have input dataframe in standard format. Otherwise, should atleast contain mandatory columns mentioned in ``col_in`` parameter.

        funnel_options : dict
            Key-value pairs indicating the different options for funneling. Only keys-value pairs that are passed will be used for funneling. Not all entires are mandatory and some of them can be skipped keep_flag is mandatory if atleast one other key (filter condition) is given

            For example::

                {
                    "id_present?": True,  # Must have call/chat ID
                    "min_speakers_present?": 2,  # must contain atleast given number of unique speakers
                    "min_time_limit?": 20,  # must be atleast given number of seconds for a transcript
                    "min_word_count?": 20,  # must contain atleast given num of words for a transcript
                    "min_conv_blocks?": 10, # Each transcript must contain atleast given num of convo blocks in a call
                    "min_confidence?": 0.8 # Average confidence score of all the words in the call to be atleast given number
                    "keep_flag": 0 # 0 drops the row[s] (calls) that don't pass all the funnel conditions. 1 retains the rows (calls) that pass all the filter conditions
                }

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for filtering percentage of conversation in a call. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory as long as it's correspondent funnel options are given i.e., if there is no "min_confidence?" option, then there is no need to enter "confidence_score" key-value pair. Corresponding values should be the column names in the main dataframe.

            For example (if all funnel options are given)::

                {
                    "id": "call_id",
                    "conv_b_num": "conv_b_num",
                    "speaker": "speaker",
                    "text": "conv_blocks",
                    "start_time": "st_time",
                    "end_time": "end_time",
                    "confidence_score": "confidence"
                }

        Returns
        -------
        Tuple[pd.DataFrame, pd.DataFrame]

            pd.DataFrame
                Dataframe which may be modified as per the options passed to this function.

            pd.DataFrame
                Logs will be returned as dataframe. Columns:- id,test1,test2,..,passed_all_filter_conditions.

                In the below example, True means that particular call transcript passed funnel test.

                False means that particular call transcript failed funnel test.

                fail in passed_all_filter_conditions indicates that particular call transcript is candidate for removal.

                Funneling of the calls depends on options passed in funnel_options.

                For example::

                    id,min_time_limit?,min_word_count?,passed_all_filter_conditions

                    1.0,True,True,pass

                    2.0,False,True,fail

            pd.DataFrame
                Statistics about the call in the below format::

                    id | num_unique_speakers | total_words | num_conversation_blocks | avg_confidence_score

        Examples
        --------
        >>> funnel_options = {
                "id_present?": True,
                "min_conv_blocks?": 20,
                "keep_flag": 1
            }
        >>> ip_cols = {
            "id": "call_id",
            "conv_b_num": "conv_b_num",
            "speaker": "speaker",
            "text": "text",
            "start_time": "start_time",
            "end_time": "end_time",
            "confidence_score": "confidence_score"
        }
        >>> filtered_df, funnel_logs_df, summary = conv_df.call_funnel(ip_df=chat_data.data, col_in=ip_cols, funnel_options=funnel_options)

        """
        if ip_df is None or not isinstance(ip_df, pd.DataFrame):
            raise ValueError("ip_df must be valued.")
        elif col_in is None:
            raise ValueError("col_in is mandatory argument.")
        elif "id" not in col_in.keys():
            raise ValueError("col_in is missing id.")
        elif "keep_flag" not in funnel_options.keys() and len(funnel_options.keys()) >= 1:
            raise ValueError(
                "keep_flag is mandatory key for options if atleast one funnel test is present."
            )
        elif funnel_options is None or len(funnel_options.keys()) == 0:
            raise ValueError("No funnel options given.")
        elif funnel_options["keep_flag"] not in [0, 1]:
            raise ValueError("Invalid Funnel options for keep_flag. Only 0 or 1 is accepted.")
        else:  # Check for valid funnel options
            for option in funnel_options.keys():
                if option not in [
                    "id_present?",
                    "min_speakers_present?",
                    "min_time_limit?",
                    "min_word_count?",
                    "min_conv_blocks?",
                    "min_confidence?",
                    "keep_flag",
                ]:
                    raise ValueError("Invalid funnel options entered.")

        self.logger.debug(f"Funnel options are: {funnel_options}")

        funnel_info = ip_df.copy(deep=True)
        funnel_info["keep_flag"] = 1
        # ID check
        if "id_present?" in funnel_options.keys():
            funnel_info["id_present?"] = funnel_info[col_in["id"]].notnull()
            funnel_info["keep_flag"] = np.where(
                ~funnel_info["id_present?"], 0, funnel_info["keep_flag"]
            )

        # Num Speaker labels.
        # Summary
        speaker_grps = (
            funnel_info.groupby(col_in["id"])[col_in["speaker"]]
            .agg(unique_speakers=pd.Series.nunique)
            .reset_index()
        )
        summary = speaker_grps

        # Funneling
        if "min_speakers_present?" in funnel_options.keys():
            speaker_grps["min_speakers_present?"] = (
                speaker_grps["unique_speakers"] >= funnel_options["min_speakers_present?"]
            )
            funnel_info = pd.merge(
                left=funnel_info, right=speaker_grps, how="inner", on=col_in["id"], validate="m:1"
            )
            funnel_info["keep_flag"] = np.where(
                ~funnel_info["min_speakers_present?"], 0, funnel_info["keep_flag"]
            )

        # Time limit in seconds
        # Summary
        call_grp = (
            funnel_info.groupby(col_in["id"])
            .agg(st=(col_in["start_time"], "first"), end=(col_in["end_time"], "last"))
            .reset_index()
        )
        call_grp["call_length"] = call_grp["end"] - call_grp["st"]
        summary = pd.merge(left=summary, right=call_grp, how="inner", on=col_in["id"])
        summary = summary[[col_in["id"], "unique_speakers", "call_length"]]

        # Funneling
        if "min_time_limit?" in funnel_options.keys():
            call_grp["min_time_limit?"] = (
                call_grp["call_length"] >= funnel_options["min_time_limit?"]
            )
            funnel_info = pd.merge(
                left=funnel_info, right=call_grp, how="inner", on=col_in["id"], validate="m:1"
            )
            funnel_info["keep_flag"] = np.where(
                ~funnel_info["min_time_limit?"], 0, funnel_info["keep_flag"]
            )

        # word count cutoff
        # Summary
        word_grps = funnel_info.copy(deep=True)
        word_grps["total_words"] = word_grps[col_in["text"]].str.split().str.len()
        word_grps = (
            word_grps.groupby(col_in["id"])["total_words"].agg(total_words="sum").reset_index()
        )
        summary = pd.merge(left=summary, right=word_grps, how="inner", on=col_in["id"])
        summary = summary[[col_in["id"], "unique_speakers", "total_words"]]

        # Funneling
        if "min_word_count?" in funnel_options.keys():

            word_grps["min_word_count?"] = (
                word_grps["total_words"] >= funnel_options["min_word_count?"]
            )
            funnel_info = pd.merge(
                left=funnel_info, right=word_grps, how="inner", on=col_in["id"], validate="m:1"
            )
            funnel_info["keep_flag"] = np.where(
                ~funnel_info["min_word_count?"], 0, funnel_info["keep_flag"]
            )

        # Number of conversation Blocks
        # Summary
        block_grps = (
            funnel_info.groupby(col_in["id"])[col_in["id"]].agg(block_size="size").reset_index()
        )
        summary = pd.merge(left=summary, right=block_grps, how="inner", on=col_in["id"])
        summary = summary[[col_in["id"], "unique_speakers", "total_words", "block_size"]]

        # Funneling
        if "min_conv_blocks?" in funnel_options.keys():
            block_grps["min_conv_blocks?"] = (
                block_grps["block_size"] >= funnel_options["min_conv_blocks?"]
            )
            funnel_info = pd.merge(
                left=funnel_info, right=block_grps, how="inner", on=col_in["id"], validate="m:1"
            )
            funnel_info["keep_flag"] = np.where(
                ~funnel_info["min_conv_blocks?"], 0, funnel_info["keep_flag"]
            )

        # Confidence
        # Summary
        confidence_grps = (
            funnel_info.groupby(col_in["id"])[col_in["confidence_score"]]
            .agg(call_confidence="mean")
            .reset_index()
        )
        summary = pd.merge(left=summary, right=confidence_grps, how="inner", on=col_in["id"])
        summary = summary[
            [col_in["id"], "unique_speakers", "total_words", "block_size", "call_confidence"]
        ]
        summary["call_confidence"] = summary["call_confidence"].round(3)

        # Funneling
        if "min_confidence?" in funnel_options.keys():

            confidence_grps["min_confidence?"] = (
                confidence_grps["call_confidence"] >= funnel_options["min_confidence?"]
            )
            funnel_info = pd.merge(
                left=funnel_info,
                right=confidence_grps,
                how="inner",
                on=col_in["id"],
                validate="m:1",
            )
            funnel_info["keep_flag"] = np.where(
                ~funnel_info["min_confidence?"], 0, funnel_info["keep_flag"]
            )

        # Final output
        funnel_cols = (
            [col_in["id"]] + [c for c in funnel_options.keys() if c != "keep_flag"] + ["keep_flag"]
        )
        if funnel_options["keep_flag"] == 0:
            # Drop rows that failed call funnel tests.
            funnel_info = funnel_info.loc[
                funnel_info["keep_flag"] == 1, funnel_cols
            ].drop_duplicates()
        else:
            funnel_info = funnel_info[funnel_cols].drop_duplicates()
        # Update main dataframe.
        filtered_df = ip_df.loc[ip_df[col_in["id"]].isin(funnel_info[col_in["id"]])].copy(
            deep=True
        )

        # Logs
        funnel_info["keep_flag"] = np.where(funnel_info["keep_flag"] == 1, "pass", "fail")
        funnel_info.rename(columns={"keep_flag": "passed_all_filter_conditions"}, inplace=True)
        new_cols = [col for col in funnel_cols if col != "keep_flag"] + [
            "passed_all_filter_conditions"
        ]
        funnel_info = funnel_info[new_cols].drop_duplicates()

        # Rename column in summary
        summary = summary.rename(
            columns={
                "unique_speakers": "num_unique_speakers",
                "block_size": "num_conversation_blocks",
                "call_confidence": "avg_confidence_score",
            }
        )

        return filtered_df, funnel_info, summary

    def _identify_speaker_from_regex(
        self,
        call_transcript: pd.DataFrame,
        pattern: list,
        return_first_greeting: bool,
        col_in: dict,
    ) -> Union[int, str]:
        """Identify speaker of a conversation block in a call based on regex pattern. Used in identifying the speaker of the greeting message

        It is inside `ConversationProcessor` class because `call_transcript` follows same format as standard format.

        Parameters
        ----------
        call_transcript : pd.DataFrame
            Call block. Same format as _df_text

        pattern : list
            Regex patterns

        return_first_greeting: bool
            Return the first occurrence of greeting or all occurrence of greetings in a call.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for identifying greetings block. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speaker",
                    "text": "conv_blocks",
                }

        Returns
        -------
        Union[int, str]
            speaker id of the agent/representative
        """
        call_transcript["is_greeting"] = False
        for current_pattern in pattern:
            try:
                _ = re.compile(current_pattern)
            except re.error:
                self.logger.warning(f"Given regex pattern {current_pattern} is invalid.")
                continue

            # This is boolean values. T if matches the entire pattern from the start, returns T else F.
            call_transcript["is_greeting"] = call_transcript["is_greeting"] | call_transcript[
                col_in["text"]
            ].str.match(pat=current_pattern, flags=re.IGNORECASE)

        if any(call_transcript["is_greeting"]):  # If greeting found for a pattern
            if return_first_greeting:
                # We use head because, in case if we find multiple greetings, we get first one.
                return (
                    call_transcript.loc[call_transcript["is_greeting"], col_in["speaker"]]
                    .head(1)
                    .index.values
                )
            else:
                return call_transcript.loc[
                    call_transcript["is_greeting"], col_in["speaker"]
                ].index.values

        return np.nan

    def _identify_speaker_from_strings(
        self,
        call_transcript: pd.DataFrame,
        contain_strings: list,
        return_first_greeting: bool,
        col_in: dict,
    ) -> Union[int, str]:
        """Identify speaker of a conversation block in a call based on string matching. Used in identifying the speaker of the greeting message

        It is inside this class because `call_transcript` follows same format as standard format.

        Parameters
        ----------
        call_transcript : pd.DataFrame
            Call Block. Same format as _df_text.

        contain_strings : list
            list of strings.

        return_first_greeting: bool
            Return the first occurrence of greeting or all occurrence of greetings in a call.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for identifying greetings block. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speaker",
                    "text": "conv_blocks",
                }

        Returns
        -------
        Union[int, str]
            speaker id of the agent/representative
        """
        call_transcript["is_greeting"] = False
        for string in contain_strings:
            call_transcript["is_greeting"] = call_transcript["is_greeting"] | call_transcript[
                col_in["text"]
            ].str.contains(string, case=False, regex=False)

        if any(call_transcript["is_greeting"]):  # If greeting found for string
            # We use head because, in case if we find multiple greetings, we get first one.
            if return_first_greeting:
                return (
                    call_transcript.loc[call_transcript["is_greeting"], col_in["speaker"]]
                    .head(1)
                    .index.values
                )
            else:
                return call_transcript.loc[
                    call_transcript["is_greeting"], col_in["speaker"]
                ].index.values

        return np.nan

    def identify_greetings(
        self,
        ip_df: pd.DataFrame,
        col_in: dict,
        greetings_options: dict = None,
        return_first_greeting: bool = True,
        n_jobs: int = 1,
    ) -> pd.DataFrame:
        """Identifies greeting messages from a call based on regex pattern or exact text matching. In case of multiple greeting messages are identified in a call, the first one is returned if ``return_first_greeting`` = True.

        Parameters
        ----------
        ip_df: pd.DataFrame
            It is recommended to have input dataframe in standard format. Otherwise, should atleast contain mandatory columns mentioned in ``col_in`` parameter.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for identifying greetings block. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speaker",
                    "text": "conv_blocks",
                }

        greetings_options : dict
            Different options that identifies greetings.

            For example::

                {
                    "regex_pattern": ["thanks for reaching out\w+"],
                    "contains_strings": ["thanks for reaching out"],
                    "first_n_blocks": 5  # First n number of convo blocks to search the greetings. default: 5
                }

        return_first_greeting : bool
            Indicate whether to return first greeting or all greetings.

        n_jobs : int
            Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

        Returns
        -------
        pd.DataFrame
            Row of text containing the first/all greeting message. Contains same format of the main dataframe as we are returning only slices of main dataframe.

        Examples
        --------
        >>> ip_cols = {
            "id": "call_id",
            "speaker": "speaker",
            "text": "text"
        }
        >>> greetings = conv_df.identify_greetings(ip_df=chat_data.data, col_in=ip_cols)

        """
        if ip_df is None or not isinstance(ip_df, pd.DataFrame):
            raise ValueError("ip_df must be valued.")
        elif col_in is None:
            raise ValueError("col_in is mandatory argument.")
        elif any(x not in col_in.keys() for x in ["id", "speaker", "text"]):
            raise ValueError("col_in is missing information/keys.")

        if greetings_options is None:
            # Default greeting, TODO Update here once we get more patterns.
            greetings_options = {
                "regex_pattern": [
                    r".*?(thank(s| you) for reaching).*?",
                    r".*?(thank(s| you) for calling).*?",
                    r".*?(how can i help).*?",
                    r".*?(thank(s| you) for choosing).*?",
                    r".*?(welcome to).*?",
                    r".*?(Good (morning|evening|afternoon|noon|night)).*?",
                ]
            }
        if "first_n_blocks" not in greetings_options.keys():
            greetings_options["first_n_blocks"] = 5

        for option in greetings_options.keys():
            if option not in ["regex_pattern", "contains_strings", "first_n_blocks"]:
                raise ValueError("Invalid greetings options entered")

        # Get top n records to search for greetings
        greetings_finder = ip_df.groupby(col_in["id"]).head(greetings_options["first_n_blocks"])

        # Reg ex pattern
        if "regex_pattern" in greetings_options.keys():
            greetings_kwargs = {
                "pattern": greetings_options["regex_pattern"],
                "return_first_greeting": return_first_greeting,
                "col_in": col_in,
            }
            greetings_finder_regex = parallelize_groupby(
                df=greetings_finder,
                groupby_cols=col_in["id"],
                func=self._identify_speaker_from_regex,
                kwargs=greetings_kwargs,
                n_jobs=n_jobs,
            )
            greetings_finder_regex = greetings_finder_regex.reset_index(name="greet_index")

        # Substring
        if "contains_strings" in greetings_options.keys():
            greetings_kwargs = {
                "contain_strings": greetings_options["contains_strings"],
                "return_first_greeting": return_first_greeting,
                "col_in": col_in,
            }
            greetings_finder_string = parallelize_groupby(
                df=greetings_finder,
                groupby_cols=col_in["id"],
                func=self._identify_speaker_from_strings,
                kwargs=greetings_kwargs,
                n_jobs=n_jobs,
            )
            greetings_finder_string = greetings_finder_string.reset_index(name="greet_index")

        # Output construction
        # Return the row given by index of greeting message.
        if (
            "regex_pattern" in greetings_options.keys()
            and "contains_strings" in greetings_options.keys()
        ):
            greetings_finder_regex = greetings_finder_regex.dropna(
                axis=0, how="all", subset=["greet_index"]
            )
            greetings_finder_string = greetings_finder_string.dropna(
                axis=0, how="all", subset=["greet_index"]
            )
            greetings_regex_indexes = greetings_finder_regex["greet_index"].explode(
                ignore_index=True
            )
            greetings_string_indexes = greetings_finder_string["greet_index"].explode(
                ignore_index=True
            )
            greet_indexes = pd.concat(
                [greetings_regex_indexes, greetings_string_indexes]
            ).drop_duplicates()
            detected_greeting = ip_df.loc[greet_indexes].copy(deep=True)

        elif "regex_pattern" in greetings_options.keys():
            greetings_finder_regex = greetings_finder_regex.dropna(
                axis=0, how="all", subset=["greet_index"]
            )
            greetings_regex_indexes = greetings_finder_regex["greet_index"].explode(
                ignore_index=True
            )
            detected_greeting = ip_df.loc[greetings_regex_indexes].copy(deep=True)
        else:
            greetings_finder_string = greetings_finder_string.dropna(
                axis=0, how="all", subset=["greet_index"]
            )
            greetings_string_indexes = greetings_finder_string["greet_index"].explode(
                ignore_index=True
            )
            detected_greeting = ip_df.loc[greetings_string_indexes].copy(deep=True)

        return detected_greeting

    def _remap_speaker_using_greeting(
        self,
        greetings_only_blocks: pd.DataFrame,
        df_txt: pd.DataFrame,
        agent_speakerid: Union[int, str],
        customer_speakerid: Union[int, str],
        col_in: dict,
    ) -> pd.DataFrame:
        """Using Greeting messages, remaps speaker id to ``agent_speakerid`` for representative/agent, ``customer_speakerid`` for customer. If a greeting message is not identified for a call, we don't make any changes.

        Parameters
        ----------
        greetings_only_blocks : pd.DataFrame
            For each call, it contains conversation block identified as a greeting message

        df_txt : pd.DataFrame
            Call data

        agent_speakerid: Union[int, str]
            speakerid of agent given by the user.

        customer_speakerid: Union[int, str]
            speakerid of customer given by the user.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for speaker remap. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speaker",
                }

        Returns
        -------
        pd.DataFrame
            Call data with speaker remapped according to the greeting message (i.e., the greeting message will be used as a pivot (the greeting message should be tagged to the representative) to remap (if required) the entire call)
        """
        if len(greetings_only_blocks) > 1:
            current_call_id = df_txt[col_in["id"]].unique()[0]
            self.logger.info(
                f"For this call {current_call_id}, we are taking the first greeting block and use it's speaker tag as the agent's speaker tag."
            )
        # Select the first greetings alone.
        greetings_only_blocks = greetings_only_blocks.head(1)

        # Rename column name for merging.
        call_speaker_map = greetings_only_blocks.copy(deep=True).rename(
            columns={col_in["speaker"]: "agent_speakerid_from_greetings"}
        )

        df_txt = pd.merge(
            left=df_txt, right=call_speaker_map, how="inner", on=col_in["id"], validate="m:1"
        )

        df_txt[col_in["speaker"]] = np.where(
            df_txt["agent_speakerid_from_greetings"].isnull(),
            df_txt[col_in["speaker"]],
            np.where(
                df_txt[col_in["speaker"]] == df_txt["agent_speakerid_from_greetings"],
                agent_speakerid,  # if speaker id is matching, then its agent id. put 1
                customer_speakerid,  # else put 0
            ),
        )
        # Remove the temp column
        df_txt = df_txt.drop(columns=["agent_speakerid_from_greetings"])

        return df_txt

    def _speaker_remap_skip_logs(
        self,
        call_transcript: pd.DataFrame,
        greetings_only_blocks: pd.DataFrame,
        speaker_options: dict,
        col_in: dict,
    ) -> pd.DataFrame:
        """Helper method that returns the call id of calls that skipped speaker remapping.

        Parameters
        ----------
        call_transcript: pd.Dataframe
            call transcript data.

        greetings_only_blocks : pd.DataFrame,
            call_id | agent's speaker id identified from greetings messages.

        speaker_options : dict
            User given speaker options.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for speaker remap. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speaker",
                }

        Returns
        -------
        pd.DataFrame
            Dataframe which returns the call id and reason for skipping speaker remap. Format::

            id | reason

        """
        # Construct an empty df for logs.
        df_skipped_logs = pd.DataFrame(data=None, columns=[col_in["id"], "reason"])

        # Construct expected speakers and actual speakers
        expected_speakers = [speaker_options["agent"], speaker_options["customer"]]
        uniq_speakers = call_transcript[col_in["speaker"]].unique()

        current_call_id = call_transcript[col_in["id"]].unique()[0]
        current_call_greetings = greetings_only_blocks.query(
            "`{0}` == @current_call_id".format(col_in["id"])
        ).copy()

        # This returns Series object.
        agent_speaker_id = current_call_greetings[col_in["speaker"]]

        if (
            (len(set(uniq_speakers).intersection(set(expected_speakers))) == 0)
            and (len(uniq_speakers) == len(expected_speakers) == 2)
            and agent_speaker_id.empty
        ):
            # If agent is empty i.e. no greeting, we can't remap speaker as we can't identify agent tag.
            reason = "Speaker remapping is skipped even though speaker tags are completely out of expected tags as greeting blocks are not identified for this call"
            current_skipped_log = pd.DataFrame(
                data={col_in["id"]: [current_call_id], "reason": [reason]}
            )
            df_skipped_logs = pd.concat([df_skipped_logs, current_skipped_log], ignore_index=True)

        return df_skipped_logs

    def _speaker_remap_per_call(
        self,
        call_transcript: pd.DataFrame,
        greetings_only_blocks: pd.DataFrame,
        speaker_options: dict,
        col_in: dict,
    ) -> pd.DataFrame:
        """Helper method that is utilized by speaker remap to update at call transcript level.

        Parameters
        ----------
        call_transcript: pd.Dataframe
            call transcript data.

        greetings_only_blocks : pd.DataFrame,
            call_id | agent's speaker id identified from greetings messages.

        speaker_options : dict
            User given speaker options.

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for speaker remap. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speaker",
                }

        Returns
        -------
        pd.DataFrame
            Updated dataframe with new speaker ids as per the speaker remapping logic.


        """
        # Construct expected speakers
        expected_speakers = sorted([speaker_options["agent"], speaker_options["customer"]])

        current_call_id = call_transcript[col_in["id"]].unique()[0]
        current_call_greetings = greetings_only_blocks.query(
            "`{0}` == @current_call_id".format(col_in["id"])
        ).copy()

        # This returns Series object.
        agent_speaker_id = current_call_greetings[col_in["speaker"]]
        if agent_speaker_id.empty:
            current_call_greetings = pd.DataFrame(
                {col_in["id"]: [current_call_id], col_in["speaker"]: [np.nan]}
            )

        uniq_speakers = call_transcript[col_in["speaker"]].unique()
        # Check whether list of speakers are same.
        if sorted(uniq_speakers) == expected_speakers and (
            len(uniq_speakers) == len(expected_speakers) == 2
        ):
            # If true,
            #   and If remap is set to true:
            #       check for greetings and use it to remap.
            #       and Print out a stricter logging warning msg.
            #   and if remap is not true:
            #       Utilize the speaker options if its valued.
            #       If it's not valued, keep data as is.
            if speaker_options["use_greeting_to_map_agent?"]:
                warning_message = "You have selected to use greeting messages to remap speaker ids (use_greeting_to_map_agent). This can be destructive as it may override the speaker diarization from the source. It is possible that the diarization is erroneous only for the greeting message of the call, and this will flip speaker tags for the entire call based on the greeting message"
                self.logger.warning(f"For the call id {str(current_call_id)}, {warning_message}")
                call_transcript = self._remap_speaker_using_greeting(
                    greetings_only_blocks=current_call_greetings,
                    df_txt=call_transcript,
                    agent_speakerid=speaker_options["agent"],
                    customer_speakerid=speaker_options["customer"],
                    col_in=col_in,
                )
            else:
                self.logger.debug(
                    f"For the call id {str(current_call_id)}"
                    ", use_greeting_to_map_agent is set to False, Hence, no speaker remapping will be done."
                )
        else:
            # Check if atleast one speaker is same but not all
            # If yes, no change.
            if (
                1
                <= len(set(uniq_speakers).intersection(set(expected_speakers)))
                < max(len(uniq_speakers), len(expected_speakers))
            ):
                # No change as we can't determine which speaker maps to what id.
                self.logger.info(
                    f"For the call id {str(current_call_id)}"
                    ", There is atleast one common speaker id between user given input and the call transcript, but they are not exactly matching, we will not be remapping speaker IDs as we can't identify which of the mismatching speaker maps to agent/customer."
                )
            else:
                # Else, use greetings to remap.
                # Print out a logging warning msg.
                if (
                    (len(set(uniq_speakers).intersection(set(expected_speakers))) == 0)
                    and (len(uniq_speakers) == len(expected_speakers) == 2)
                    and not agent_speaker_id.empty
                ):
                    warning_msg = "Greeting messages is automatically selected to remap speaker ids because none of the speaker ids provided matched the speaker ids from the call transcript, but the length matched and equal to 2."
                    self.logger.warning(f"For the call id {str(current_call_id)}, {warning_msg}")
                    call_transcript = self._remap_speaker_using_greeting(
                        greetings_only_blocks=current_call_greetings,
                        df_txt=call_transcript,
                        agent_speakerid=speaker_options["agent"],
                        customer_speakerid=speaker_options["customer"],
                        col_in=col_in,
                    )

        return call_transcript

    def speaker_remap(
        self,
        ip_df: pd.DataFrame,
        greetings_blocks: pd.DataFrame,
        speaker_options: dict,
        col_in: dict,
        n_jobs: int = 1,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Identifies the greeting message from the call and the speaker. If the unique list of speakers present in the call are entirely outside the expected speakers, then automatically retags the speakers to expected speakers based on the greeting message (speaker tagged to the greeting message will get the expected representative speaker tag). Incase, the call has expected speakers, then it takes whether or not to remap the entire call diarization based on the greeting message as a user input (use_greeting_to_map_agent)(Ex: If the greeting message is tagged to the customer, then the speaker tags for the entire call will be flipped)

        There is an exception to this when the source is watson-chat as it's possible to have multiple agents(human and AI). In that scenario, we will use speaker_source to differentiate between the agents

        Parameters
        ----------
        ip_df: pd.DataFrame
            It is recommended to have input dataframe in standard format. Otherwise, should atleast contain mandatory columns mentioned in ``col_in`` parameter.

        greetings_blocks : pd.DataFrame
            For each call, contains row[s] of greeting message. If more than one row is present per call, first row will be selected automatically.

        speaker_options : dict
            User given input on which speaker is agent and which speaker is customer

            For example::

                {
                "agent": 0, # Expected speaker tag of the representative in the raw data (can be int/ str)
                "customer": 1, # Expected speaker tag of the customer/ visitor in the raw data (can be int/ str)
                "use_greeting_to_map_agent?": True  # Whether to use greeting messages to identify agent
                }

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for speaker remap. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "speaker": "speaker",
                }

        n_jobs : int
            Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

        Returns
        -------
        Tuple[pd.DataFrame, pd.DataFrame]

            pd.DataFrame
                Modified dataframe whose speaker column is remapped as per the options given.

            pd.DataFrame
                Dataframe which contains the call id and reason for skipping speaker remap. It will be empty dataframe if no call ids are skipped. Format::

                    id | reason

        Raises
        ------
        ValueError
            if any of the argument is missing or invalid

        Examples
        --------
        >>> ip_cols = {
            "id": "call_id",
            "speaker": "speaker",
            "text": "text"
        }
        >>> greetings = conv_df.identify_greetings(col_in=ip_cols)
        >>> opt1_speaker_remap = {"agent": "AGNT",
                  "customer": "CUST",
                  "use_greeting_to_map_agent?": False}
        >>> ip_cols_remap = {
            "id": "call_id",
            "speaker": "speaker",
        }
        >>> remapped_df, remapped_logs = conv_df.speaker_remap(ip_df=chat_data.data,
            greetings_blocks=greetings,
            speaker_options=opt1_speaker_remap,
            col_in=ip_cols_remap)

        """
        if ip_df is None or not isinstance(ip_df, pd.DataFrame):
            raise ValueError("ip_df must be valued.")
        elif col_in is None:
            raise ValueError("col_in is mandatory argument.")
        elif any(x not in col_in.keys() for x in ["id", "speaker"]):
            raise ValueError("col_in is missing information/keys.")
        elif len(list(speaker_options.keys())) > 4 and speaker_options is not None:
            raise ValueError(
                "Enter correct speaker options. Agent and customer key value pair is required."
            )
        elif speaker_options is None and greetings_blocks is None:
            raise ValueError("Enter either speaker options or agent call speaker mapping.")
        elif greetings_blocks is not None and not isinstance(greetings_blocks, pd.DataFrame):
            raise ValueError("agent call speaker mapping must be a Dataframe")
        elif speaker_options is not None and not isinstance(speaker_options, dict):
            raise ValueError("Speaker options must be either None or dict")
        elif not all(options in speaker_options.keys() for options in ["agent", "customer"]):
            raise ValueError("Speaker options agent, customer are mandatory.")
        else:
            for option in speaker_options:
                if option not in [
                    "agent",
                    "customer",
                    "use_greeting_to_map_agent?",
                ]:
                    raise ValueError("Invalid speaker options entered")

        # Default values
        if "use_greeting_to_map_agent?" not in speaker_options.keys():
            self.logger.debug("Default value of use_greeting_to_map_agent?=False is used")
            speaker_options["use_greeting_to_map_agent?"] = False

        call_data = ip_df.copy(deep=True)  # Work on copy.
        greetings_only_blocks = greetings_blocks[
            [col_in["id"], col_in["speaker"]]
        ]  # Only need these two columns.

        # TODO: To be revisited later for optimization.

        # Parallel
        speaker_kwargs = {
            "speaker_options": speaker_options,
            "greetings_only_blocks": greetings_only_blocks,
            "col_in": col_in,
        }
        skipped_logs_df = parallelize_groupby(
            df=call_data,
            groupby_cols=col_in["id"],
            func=self._speaker_remap_skip_logs,
            kwargs=speaker_kwargs,
            n_jobs=n_jobs,
        )
        skipped_logs_df = skipped_logs_df.reset_index(drop=True)

        call_data = parallelize_groupby(
            df=call_data,
            groupby_cols=col_in["id"],
            func=self._speaker_remap_per_call,
            kwargs=speaker_kwargs,
            n_jobs=n_jobs,
        )
        remapped_df = call_data.reset_index(drop=True)

        return remapped_df, skipped_logs_df

    def _create_or_update_merge_frame(
        self, call_data: pd.DataFrame, time_threshold: float, col_in: dict
    ) -> pd.DataFrame:
        """For given call transcript, calculates next conversation block's end time for each conversation block and tags whether a given conversation block is eligible for merging based on `next block by the same speaker start time - current block end time < ``time_threshold``

        When it's called for first time, it will create the two columns (``end_time_previous`` and ``can_merge``). Otherwise, it will overwrite the already created columns.

        Parameters
        ----------
        call_data : pd.DataFrame
            Transcript data in standard format as the main dataframe.

        time_threshold : float
            Threshold for deciding to merge consecutive conversation blocks for a speaker

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging and reordering conversation blocks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "conv_b_num": "conv_b_num",
                    "speaker": "speaker",
                    "text": "conv_blocks",
                    "start_time": "st_time",
                    "end_time": "end_time",
                }

        Returns
        -------
        pd.DataFrame
            Modified Dataframe with two extra columns - end_time_previous, can_merge
        """
        call_data["end_time_previous"] = call_data.groupby(col_in["speaker"])[
            col_in["end_time"]
        ].transform(lambda x: x.shift(1))
        call_data["can_merge"] = np.where(
            abs(call_data[col_in["start_time"]] - call_data["end_time_previous"]) < time_threshold,
            1,
            0,
        )
        return call_data

    def _merge_for_call(
        self, block_level_text: pd.DataFrame, time_threshold: float, col_in: dict
    ) -> pd.DataFrame:
        """Merges consecutive conversation blocks spoken by the same speaker if the time gap between them is less than the parameter ``time_threshold`` seconds (time gap = start time of the current conversation block - end time of previous conversation block).        This function will be passed in groupby.apply so that merge conversation blocks happens for each call

        Parameters
        ----------
        block_level_text : pd.DataFrame
            Call transcript in the standard format

        time_threshold : float
            Time threshold (in s) for deciding to merge consecutive conversation blocks by the same speaker. In our previous experience with a client, 0.01 seconds threshold worked well

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging and reordering conversation blocks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "conv_b_num": "conv_b_num",
                    "speaker": "speaker",
                    "text": "conv_blocks",
                    "start_time": "st_time",
                    "end_time": "end_time",
                }

        Returns
        -------
        pd.DataFrame
            Modified Dataframe with merged blocks for a call
        """
        total_words_before_merge = sum(block_level_text[col_in["text"]].str.split().str.len())
        block_level_text = self._create_or_update_merge_frame(
            block_level_text, time_threshold, col_in=col_in
        )
        block_level_text["merged?"] = 0  # Initialize
        block_level_text["combined_conv_b_num"] = block_level_text[col_in["conv_b_num"]].astype(
            "str"
        )
        total_blocks_to_merge = block_level_text["can_merge"].sum()

        # Iteratively merge blocks.
        while total_blocks_to_merge != 0:
            for index in block_level_text.loc[block_level_text["can_merge"] == 1].index.tolist():
                current_speaker = block_level_text.loc[index, col_in["speaker"]]
                # Find prev index of convo block.
                current_speaker_all_idx = block_level_text.loc[
                    (block_level_text[col_in["speaker"]] == current_speaker)
                    & (block_level_text["can_merge"] != 1)
                ].index.tolist()
                current_speaker_prev_idx = max(
                    [idx for idx in current_speaker_all_idx if (idx < index)]
                )
                # Merge Text of current index with prev index
                block_level_text.loc[current_speaker_prev_idx, col_in["text"]] = (
                    block_level_text.loc[current_speaker_prev_idx, col_in["text"]]
                    + " "
                    + block_level_text.loc[index, col_in["text"]]
                )
                # Update End time of Merged Block.
                block_level_text.loc[
                    current_speaker_prev_idx, col_in["end_time"]
                ] = block_level_text.loc[index, col_in["end_time"]]
                # Update Conversation Block num that was merged.
                block_level_text.loc[current_speaker_prev_idx, "combined_conv_b_num"] = (
                    block_level_text.loc[current_speaker_prev_idx, "combined_conv_b_num"]
                    + ", "
                    + block_level_text.loc[index, col_in["conv_b_num"]].astype("str")
                )
                # Update merged blocks.
                block_level_text.loc[current_speaker_prev_idx, "merged?"] = 1

                # Drop the rows at the current index so that it will not be used again for merging.
                block_level_text.drop(index=index, inplace=True)

                # Recalculate 'can merge' for next iteration
                block_level_text = self._create_or_update_merge_frame(
                    block_level_text, time_threshold, col_in=col_in
                )

            total_blocks_to_merge = block_level_text["can_merge"].sum()

        # Merging conversation blocks shouldn't affect total number of words in a call
        total_words_after_merge = sum(block_level_text[col_in["text"]].str.split().str.len())
        assert total_words_before_merge == total_words_after_merge

        return block_level_text

    def merge_and_reorder_conv_blocks(
        self,
        ip_df: pd.DataFrame,
        col_in: dict,
        col_out: Optional[dict] = None,
        time_diff_threshold: float = 0.01,
        n_jobs: int = 1,
    ) -> pd.DataFrame:
        """Merge conversation blocks that have their end time and start time very close
        to each other. i.e., if difference between current conv block and next convo block
        for a same speaker is less than `time_diff_threshold`, it's a candidate for merging.
        After merge, reorder conv block num as per their start time for each call id.

        Parameters
        ----------
        ip_df: pd.DataFrame
            It is recommended to have input dataframe in standard format. Otherwise, should atleast contain mandatory columns mentioned in ``col_in`` parameter.

        time_diff_threshold : float
            Threshold (in seconds/minutes depending on what time scale is captured in start_time and end_time columns) for deciding to merge consecutive conversation blocks for a speaker. In our previous experience with a client, 0.01 seconds threshold worked well

        col_in : dict
            Input column names mappings which has the conversation block details that are needed for merging and reordering conversation blocks. Mapping should be given as key-value pair. Keys mentioned in the below example are mandatory. Corresponding values should be the column names in the main dataframe.

            For example::

                {
                    "id": "call_id",
                    "conv_b_num": "conv_b_num",
                    "speaker": "speaker",
                    "text": "conv_blocks",
                    "start_time": "st_time",
                    "end_time": "end_time",
                }

        col_out : dict, optional
            Output column name mappings which has the merged and reordered conversation blocks. Mapping should be given as key-value pair. Keys should be those columns which you want to rename. Corresponding values should be the column names you want in the main dataframe. If you do not wish to rename, don't pass any value to this parameter.

            For example (If you want to rename "text" to "merged_reordered_text")::

                {
                    "text": "merged_reordered_text",
                }

        n_jobs : int
            Number of jobs/workers for parallel computation. by default, its 1 meaning it's sequential

        Returns
        -------
        pd.DataFrame
            Modified dataframe with extra column "combined_conv_b_num" to indicate which
            blocks in the original dataframe were merged.

        Examples
        --------
        >>> ip_cols = {
            "id": "call_id",
            "conv_b_num": "conv_b_num",
            "speaker": "speaker",
            "text": "text",
            "start_time": "start_time",
            "end_time": "end_time",
        }
        >>> op_cols = {
            "text": "merged_reordered_text",
            "end_time": "new_end_time"
        }
        >>> merged_reordered_df = conv_df.merge_and_reorder_conv_blocks(ip_df=chat_data.data, time_diff_threshold=2, col_in=ip_cols, col_out=op_cols)

        """
        if time_diff_threshold > 3:
            warnings.warn("time_diff_threshold cannot be greater than 3.")
            return None
        elif col_in is None:
            raise ValueError("col_in is mandatory argument.")
        elif any(
            x not in col_in.keys()
            for x in ["id", "speaker", "conv_b_num", "text", "start_time", "end_time"]
        ):
            raise ValueError("col_in is missing information/keys.")
        elif (
            not isinstance(time_diff_threshold, float) and not isinstance(time_diff_threshold, int)
        ) or time_diff_threshold is None:
            raise ValueError("Enter Time difference threshold to be considered for merging.")

        if isinstance(time_diff_threshold, int):
            time_diff_threshold = float(time_diff_threshold)

        # PArallel
        merge_kwargs = {"time_threshold": time_diff_threshold, "col_in": col_in}
        merged_blocks = parallelize_groupby(
            df=ip_df,
            groupby_cols=col_in["id"],
            func=self._merge_for_call,
            kwargs=merge_kwargs,
            n_jobs=n_jobs,
        )
        merged_blocks = merged_blocks.reset_index(drop=True)

        # When we merge conversation blocks, we get full nan rows for blocks that
        # was merged. So, need to drop them
        merged_blocks = merged_blocks.dropna(axis=0, how="all")
        # Remove temp columns
        merged_blocks = merged_blocks.drop(columns=["end_time_previous", "can_merge"])

        # Reorder conversation blocks for each call.
        merged_and_reordered_blocks = merged_blocks.sort_values(
            by=[col_in["id"], col_in["start_time"]]
        ).reset_index(drop=True)
        merged_and_reordered_blocks[col_in["conv_b_num"]] = (
            merged_and_reordered_blocks.groupby(col_in["id"]).cumcount() + 1
        )

        # Rename columns if user defined it.
        if col_out:
            column_rename_mapping = {col_in[k]: v for k, v in col_out.items()}
            merged_and_reordered_blocks = merged_and_reordered_blocks.rename(
                columns=column_rename_mapping
            )

        return merged_and_reordered_blocks


if __name__ == "__main__":
    pass  # use notebooks to test functionality.
