import fitz  # install using: pip install PyMuPDF
import io
import json
import numpy as np
import os
from PIL import Image

from tigernlp.core.utils import MyLogger


class PyMuPdf_Image:
    """PyMuPdf_Image class to images from given douments.

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "WARNING"

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    Example
    -------
    >>> from tigernlp.doc_parsing.api import PyMuPdf_Image
    >>> DM = PyMuPdf_Image()
    >>> data = DM.extract(input_file_path = "path\\to\\file")
    >>> data
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """PyMuPdf_Image class initialization"""

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def extract(self, input_file_path: str = None, output_format: str = "pil"):
        """
        extract function to extract image from given douments.

        Parameters
        ----------
        folder_path : str
            path to the folder where all the files exist. default None
        file_path : str
            path of the file. default None
        as_json : bool
            True if we want output to be of json format. default False

        Returns
        -------
        data: json/dict
            dict of keys as document name and values as dict containg image, or as json object.

        """
        try:
            if input_file_path is None:
                raise ValueError("file_path were passed None. Please provide the path.")

            if not os.path.exists(input_file_path):
                raise ValueError(f"Given {input_file_path} is not available.")

            if output_format == "json":
                self.return_format = "json"
            else:
                self.return_format = "pil"

            data = self.__get_image(input_file_path=input_file_path)

            return data
        except Exception as e:
            self.logger.error(f"The following error occurred while extracting images from PyMuPdf_Image class {e}")

    def __get_image(self, input_file_path) -> dict:
        """Extracts text of a give file in the path variable.

        Parameters
        ----------
        file_path: str
            path of a file

        Returns
        -------
        total_text: str
            all the text in the file."""

        pdf_file = fitz.open(input_file_path)
        data_image_json = {}
        data_image_pil = {}
        data_image_bytes = {}
        for page_index in range(len(pdf_file)):
            page = pdf_file[page_index]
            image_list = page.get_images()
            for image_index, img in enumerate(image_list, start=1):
                xref = img[0]
                base_image = pdf_file.extract_image(xref)
                image_bytes = base_image["image"]
                image_ext = base_image["ext"]
                image = Image.open(io.BytesIO(image_bytes))
                image_json = json.dumps(np.array(image).tolist())
                image_pil = Image.fromarray(np.array(json.loads(image_json), dtype="uint8"))

                data_image_bytes[f"page_{page_index+1}_image_{image_index}.{image_ext}"] = image_bytes
                data_image_json[f"page_{page_index+1}_image_{image_index}.{image_ext}"] = image_json
                data_image_pil[f"page_{page_index+1}_image_{image_index}.{image_ext}"] = image_pil

        if self.return_format == "bytes":
            return data_image_bytes
        if self.return_format == "json":
            return data_image_json
        if self.return_format == "pil":
            return data_image_pil
