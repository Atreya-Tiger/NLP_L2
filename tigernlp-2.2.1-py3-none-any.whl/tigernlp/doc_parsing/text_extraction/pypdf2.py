import json
import os
from PyPDF2 import PdfReader

from tigernlp.core.utils import MyLogger


class PyPdf2:
    """PyPdf2 class to extract text from given documents.

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "WARNING"

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    Example
    -------
    >>> from tigernlp.doc_parsing.api import PyPdf2
    >>> DM = PyPdf2()
    >>> data = DM.extract(input_file_path = "path\\to\\file")
    >>> data
    """

    def __init__(self, log_level: str = "INFO", log_file_path: str = None, verbose: bool = True):
        """PyPdf2 class initialization"""

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def extract(self, input_file_path: str = None, output_format: str = "dict"):
        """
        Extract function to extract text from a pdf file.

        Parameters
        ----------
        input_file_path : str
            Relative or Absolute path of the file. Default is "None"

        output_format : str, optional
            Format of the output. Accepted values are "dict", "json" or "text file"

        Returns
        -------
        data: Union[dict,json,text file]
            Extracted text in "output_format"
            The extracted data can be obtained in three formats:
            1. python dictionary : The pages would be the keys and the extracted text would be the value for each key
            2. json : the extracted text would be displayed as json object
            3. text file : the extracted text would be returned in the text file format

        """
        try:
            if input_file_path is None:
                self.logger.error("file_path were passed None. Please provide the path.")
                raise ValueError("file_path were passed None. Please provide the path.")

            if not os.path.exists(input_file_path):
                raise ValueError(f"Given {input_file_path} is not available.")
            elif output_format not in ["dict", "json", "text file"]:
                raise ValueError("supported output formats are 'df' or 'json' or 'text file'")

            if output_format == "dict":
                data = self.__get_text(input_file_path)
            elif output_format == "json":
                data = self.__get_text(input_file_path)
                data = json.dumps(data, indent=4)
            elif output_format == "text file":
                data = self.__get_text(input_file_path)

                data = "\n\n".join(list(data.values()))

            return data
        except Exception as e:
            self.logger.error(f"Error occurred while extracting text from PDFs {e}")
            raise ValueError(f"Error occurred while extracting text from PDFs {e}")

    def __get_text(self, input_file_path) -> dict:
        """Extracts text of a give file in the path variable.

        Parameters
        ----------
        input_file_path: str
            path of a file

        Returns
        -------
        text_dict: dict
            Extracted text for each page individually."""

        text_dict = dict()
        pdf = PdfReader(input_file_path)

        for i in range(len(pdf.pages)):
            page = pdf.pages[i]
            text_all = page.extract_text()

            text_dict[str(i)] = text_all

        return text_dict
