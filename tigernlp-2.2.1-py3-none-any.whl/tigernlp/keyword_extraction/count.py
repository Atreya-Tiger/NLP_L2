import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from typing import Union

from tigernlp.core.utils import MyLogger, k_func, rank_func


class CountScorer:
    """Keyword extraction utility using the count of keywords.

    Generates and ranks n-gram keywords present in the document using count score.
    Feature `n_gram_range` can be used to get unigram, bigram, or trigram keywords.

    For example, a ngram_range of (1, 1) means only unigrams, (1, 2) means unigrams and bigrams, and (2, 2) means only bigrams.

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True
    Examples
    --------
    >>> from tigernlp.keyword_extraction.api import CountScorer
    >>> text_for_keyword_extraction = ["Four Lessons From Running A Business During The Pandemic", "My latest for @Forbes: The pandemic has transformed my company"]
    >>> score_class_object = CountScorer()
    >>> df_ke = score_class_object.score(input_text=text_for_keyword_extraction, max_features=5000, n_gram_range=(1,3))
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """CountScorer class initialization"""

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def _run_vectorizer(self):
        r"""Extract unigram/polygram keywords from document using CountVectorizer

        Returns
        -------
        pd.DataFrame
            Dataframe with keyword phrases and respective count scores as columns
        """
        processed_tweets = self.input_text

        vectorizer = CountVectorizer(max_features=self.max_features, ngram_range=self.n_gram_range, min_df=1, stop_words=self.language)

        top_count = vectorizer.fit_transform(processed_tweets).toarray().sum(axis=0)
        feature_names = vectorizer.get_feature_names()
        top_count_vect = [top_count]
        count_df = pd.DataFrame(top_count_vect, columns=feature_names)
        count_df = count_df.transpose()
        count_df["keywords"] = count_df.index
        count_df.columns = ["score", "keyword"]
        count_df = count_df[["keyword", "score"]]
        count_df = count_df.sort_values(by="score", ascending=False)
        self.logger.info("Count vectorizer keywords extraction completed")
        return count_df.reset_index(drop=True)

    def score(self, input_text: Union[str, list] = list(), max_features=10000, n_gram_range=(1, 3), language="english"):
        r"""Orchestrates end-to-end keyword extraction pipeline using count vectorizer.

        Parameters
        ----------
        input_text : Union[str, list]
            string or list of documents to be used for keyword extraction
        max_features : int, optional
            maximum number of word phrases (n-grams) to be used when computing frequency, by default 10000
            The value should be greater than 0
        n_gram_range : tuple(int,int), optional
            the lower and upper boundary of the range of n-values for different word n-grams or char n-grams to be extracted, by default (1,3)
            All values of n such that min_n <= n <= max_n will be used.

            For example, a ngram_range of (1, 1) means only unigrams, (1, 2) means unigrams and bigrams, and (2, 2) means only bigrams.
        language : str, optional
            language of stopwords or manual list of stopwords to be removed, by default 'english'
            Example - ['collected', 'cat']

        Returns
        -------
        pd.DataFrame
            Dataframe containing keyword phrases, count score, keyword rank and concatenated keyword score value as columns

            columns - "keyword", "score", "rank", "k_s"

            Example: keyword - "phone number", score - 0.57, rank - 5, k_s - (phone number, 0.57)
        """
        try:
            self.logger.info("Keyword Extraction using count started")

            self.max_features = max_features
            self.n_gram_range = n_gram_range
            self.language = language

            if isinstance(input_text, str):
                self.input_text = [input_text]
            elif isinstance(input_text, list):
                self.input_text = input_text
            else:
                raise ValueError(f"Incorrect input text type - {type(input_text)}")

            main_count_df = pd.DataFrame()
            main_count_df = self._run_vectorizer()

            main_count_df.reset_index(drop=True, inplace=True)
            main_count_df["score"] = main_count_df["score"].astype("float")
            main_count_df["score"] = np.round(main_count_df["score"], 5)
            main_count_df["k_s"] = main_count_df.apply(lambda a: k_func(a), axis=1)
            main_count_df = rank_func(main_count_df)
            main_count_df["keyword_joined"] = main_count_df["keyword"].apply(lambda x: "_".join(x.split()))

            self.logger.info("Count vectorizer rank and score added")
            self.logger.info("Keyword extraction using count completed")

            main_count_df.reset_index(inplace=True, drop=True)
            return main_count_df

        except Exception as e:
            self.logger.error(f"Error occurred while using count {e}")
