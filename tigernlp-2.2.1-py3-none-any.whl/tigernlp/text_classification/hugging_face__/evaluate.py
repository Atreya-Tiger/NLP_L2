"""
This module is used to generate the value evaluation metrics
and prediction outcomes of huggingface based NLP models
"""
import os
import pandas as pd
import torch
from sklearn.metrics import classification_report, confusion_matrix, multilabel_confusion_matrix
from tqdm import tqdm
from transformers import AutoModelForSequenceClassification

from tigernlp.core.utils import MyLogger
from tigernlp.text_classification.hugging_face__ import utils


class Evaluation:

    """
    Class to generate the various evaluation metrics and
    prediction outcomes of huggingface based text models

    Parameters
    -----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Example
    -------
    >>> from tigernlp.text_classification.api import Evaluation
    >>> df = pd.read_csv (
            'sentiment_analysis_sample_data_binary_class.csv'
    >>>   )
    >>> eval = Evaluation()
    >>> result = eval.generate_eval_output(
    >>>        test_data = df, text="text",
    >>>        model_to_load = "cardiffnlp/twitter-roberta-base-sentiment",
    >>>        model_class_path = None, prob_threshold = 0.5,
    >>>        problem_type = "single_label_classification", batch_size = 32
    >>>    )
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """
        Classification model evaluation class initialisation
        """
        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def generate_eval_output(
        self,
        test_data,
        label,
        text,
        model_to_load="bert-base-uncased",
        model_class_path=None,
        prob_threshold=0.5,
        batch_size=32,
        problem_type="single_label_classification",
    ):

        """
        This function is used to generate the various evaluation metrics and prediction outcomes of huggingface based text models

        Parameters
        -----------
        test_data: DataFrame
            Test Data in data frame format. The labelled dataset need to be in dataframe format with text and label columns
        label: str
            Column name containing labels. Labels should be sequential integers starting with 0 for binary class or multi class.
            In the case of multi-label, the labels column should have a list of labels tagged to each row. Eg: [0,4,7]
        text: str
            column name containing text in the string format
        model_to_load: str, optional
            pretrained model from huggingface, default: 'bert-base-uncased'. This argument should be None in the case of sourcing the model locally from custom trained models
        model_class_path: str, optional
            Local path from which custom trained model objects need to be loaded, default=None, in this case, model if available will be loaded from huggingface
        prob_threshold: float, optional
            User defined probability threshold for binary classification, default=0.5. Will not be considered for multiclass classification
        problem_type: str, optional
            The type of classification we are dealing with, default = "single_label_classification". "multi_label_classification" if it is multi-label.
        batch_size: int, optional
            The number of test data samples utilized in one iteration through the model. default=32

        Returns
        ----------
        Dictionary
            Evaluation metrics: accuracy, rocauc, precision, recall , f1 score
        Dataframe
            Dataframe containing probabilities for each class and predicted class

        Example
        -------
        >>> from tigernlp.text_classification.api import Evaluation
        >>> df = pd.read_csv ('sentiment_analysis_sample_data_binary_class.csv')
        >>> eval = Evaluation()
        >>> result = eval.generate_eval_output(
        >>>        test_data = df, text="text",
        >>>        model_to_load = "cardiffnlp/twitter-roberta-base-sentiment",
        >>>        model_class_path = None, prob_threshold = 0.5,
        >>>        problem_type = "single_label_classification", batch_size = 32
        >>>    )
        """
        # Check if path and model files exist
        if (model_class_path is not None) and (type(model_class_path) == str):
            if (os.path.exists(model_class_path)) is False:
                raise Exception("File or Directory does not exist. Use '/' delimter in the path")

        # Check probability threshold value limit
        if (prob_threshold < 0) or (prob_threshold > 1):
            raise ValueError("Probability should be in range [0,1]")

        # Problem type check
        if problem_type not in [
            "single_label_classification",
            "multi_label_classification",
        ]:
            raise Exception("problem_type input value should be one of ['single_label_classification', 'multi_label_classification']")

        # Check batch_size type
        if (isinstance(batch_size, int)) is False:
            raise TypeError("batch_size should be integer type")

        # Initializing multi_class to 0, to default to binary classification
        multi_class = 0

        # Extracting text and label columns from the dataset
        y_test, x_test = utils.label_text_definition(test_data, text, label, problem_type=problem_type)

        # Counting number of classes and determining if multi_class
        if problem_type == "single_label_classification":
            if len(set(y_test)) > 2:
                multi_class = 1
                self.logger.info("User-defined probability threshold will not be considered as it is a multi-class classification")

        # Defining tokenizer object
        if model_class_path is None:
            tokenizer = utils.create_tokenizer_object(model_to_load)
        else:
            tokenizer = utils.create_tokenizer_object(model_class_path)

        # Creating encodings for x_test, y_test
        encodings = utils.create_tokens(x_test, tokenizer)

        # Creating dataset from encodings
        test_dataset = utils.create_dataset(encodings, list(y_test), problem_type=problem_type)

        # Defining dataloader, batch size for each iteration
        test_dataloader = torch.utils.data.DataLoader(test_dataset, batch_size=batch_size)

        # Defining model object, model_class_path is none for huggingface pretrained models
        if model_class_path is None:
            model = AutoModelForSequenceClassification.from_pretrained(model_to_load)

        else:
            model = AutoModelForSequenceClassification.from_pretrained(model_class_path)
            if model_to_load is not None:
                self.logger.info("Model from the path is taken and model_to_load is ignored")

        # use_cuda = torch.cuda.is_available()
        # device = torch.device("cuda" if use_cuda else "cpu")
        # if use_cuda:

        #     model = model.cuda()

        y_test_format_preserved = y_test
        out = pd.DataFrame()
        # Running the model for each batch
        with torch.no_grad():
            # Initializing y_pred for storing model predictions,
            # y_test for actuals, y_prob, y_prob_df for storing probabilities
            # y_pred, y_test, y_prob, y_prob_df = [], [], [], []
            y_pred, y_pred_binary_format, y_prob_df = [], [], []

            for test_input in tqdm(test_dataloader):

                output = model(**test_input)

                # Calculating probabilities and predicted labels
                #  for multi class classification
                if problem_type == "single_label_classification" and multi_class == 1:
                    probabilities = torch.nn.functional.softmax(output.logits, dim=1)
                    y_prob_df = y_prob_df + probabilities.tolist()
                    y_pred = y_pred + output.logits.argmax(dim=1).tolist()

                # Calculating probabilities and predicted labels for
                # binary class classification
                if problem_type == "single_label_classification" and multi_class == 0:
                    probabilities = torch.nn.functional.softmax(output.logits, dim=1)
                    y_prob_df = y_prob_df + probabilities.tolist()
                    y_pred = y_pred + [1 if i > prob_threshold else 0 for i in probabilities[:, 1].tolist()]

                # Calculating probabilities and predicted labels for
                # multi label classification
                if problem_type == "multi_label_classification":
                    probabilities = torch.sigmoid(output.logits)
                    y_prob_df = y_prob_df + probabilities.tolist()

                    for lst in probabilities.tolist():
                        y_label = []
                        lst = [1 if i > prob_threshold else 0 for i in lst]
                        y_pred_binary_format.append(lst)

                        for count, value in enumerate(lst):
                            if value == 1:
                                y_label.append(count)
                        y_pred.append(y_label)

        labels_cr = range(0, len(y_prob_df[0]))
        string_labels = [str(int) for int in labels_cr]
        out = pd.DataFrame(y_prob_df, columns=string_labels)
        out["predicted_label"] = y_pred
        out[text] = test_data[text].tolist()

        # Creating confusion matrix and classification report
        if problem_type == "single_label_classification" and multi_class == 1:
            conf_mat = confusion_matrix(y_test_format_preserved, y_pred)
            clf_rpt = classification_report(
                y_test_format_preserved,
                y_pred,
                output_dict=True,
                target_names=string_labels,
            )
            eval_metrics = utils.eval_metrics(
                y_pred=y_pred,
                y_test=y_test_format_preserved,
                y_prob=y_prob_df,
                problem_type=problem_type,
                multi_class=multi_class,
            )

        if problem_type == "single_label_classification" and multi_class == 0:
            conf_mat = confusion_matrix(y_test_format_preserved, y_pred)
            clf_rpt = classification_report(
                y_test_format_preserved,
                y_pred,
                output_dict=True,
                target_names=string_labels,
            )
            eval_metrics = utils.eval_metrics(
                y_pred=y_pred,
                y_test=y_test_format_preserved,
                y_prob=out["1"],
                problem_type=problem_type,
                multi_class=multi_class,
            )

        if problem_type == "multi_label_classification":
            conf_mat = multilabel_confusion_matrix(y_test_format_preserved, y_pred_binary_format)
            clf_rpt = classification_report(
                y_test_format_preserved,
                y_pred_binary_format,
                output_dict=True,
                target_names=string_labels,
            )
            eval_metrics = utils.eval_metrics(
                y_pred=y_pred_binary_format,
                y_test=y_test_format_preserved,
                y_prob=y_prob_df,
                problem_type=problem_type,
                multi_class=multi_class,
            )

        # Rounding off classification report results to 2 digits
        for k, v in clf_rpt.items():
            if type(clf_rpt[k]) is dict:
                for m, n in v.items():
                    clf_rpt[k][m] = round(v[m], 2)
            if isinstance(clf_rpt[k], str):
                clf_rpt[k] = v
            if isinstance(clf_rpt[k], float):
                clf_rpt[k] = round(v, 2)

        self.logger.info("Currrent probability threshold: %.2g", prob_threshold)
        self.logger.info("Evaluation Metrics: %s", eval_metrics)
        self.logger.info("Confusion Matrix: %s", conf_mat)
        self.logger.info("Confusion Matrix: %s", clf_rpt)

        result = {
            "eval_metrics": eval_metrics,
            "conf_mat": conf_mat,
            "clf_rpt": clf_rpt,
        }
        return result, out
