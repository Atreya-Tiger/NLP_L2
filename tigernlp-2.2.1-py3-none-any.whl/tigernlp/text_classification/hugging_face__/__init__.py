"""This module contains text classification inference and evaluation modules for transfomer based classification models.
This can be used to infer and evaluate from a pretrained transformer model.
"""
