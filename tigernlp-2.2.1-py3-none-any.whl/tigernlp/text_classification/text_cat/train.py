from tigernlp.core.utils import MyLogger
from tigernlp.custom_spacy.api import SpacyTrainer

from .data_prepare import TextCatSpacyDataPrep


class TextCatTrainer(SpacyTrainer, TextCatSpacyDataPrep):
    """TextCatTrainer class is utility class that provides functionalities for generating config and training text categorization.

    Parameters
    ----------
    log_file_path : str
        Full path of the log file to save training logs at
    log_level : str, optional
        Logging level to write logs, by default "INFO"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Example
    -------
    >>> from tigernlp.text_classification.text_cat.api import TextCatTrainer
    >>> textcat_triner = TextCatTrainer()
    >>> df = pd.DataFrame({
    >>>                    'text': ['I like banana',
    >>>                            'This is a sentence about apples.',
    >>>                            'This is a sentence about cellphone.'],
    >>>                    'label': ['FRUIT',
    >>>                            'FRUIT',
    >>>                            'DEVICE'],
    >>>                    })
    >>> df = textcat_triner.get_encoding(df,'label')
    >>> df['text']
    >>> ['I like banana','This is a sentence about apples.','This is a sentence about cellphone.']
    >>> df['label']
    >>> ['FRUIT', 'FRUIT', 'DEVICE']
    >>> df['label_enc']
    >>> [0,0,1]
    >>> textcat_triner.generate_corpous(texts = df['text'], labels = df['label_enc'], basename = 'train', corpus_path= 'project_folder/data')
    >>> textcat_triner.generate_config(config_save_path = 'project_folder/config/config.cfg')
    >>> textcat_triner.train(train_path= "project_folder/data/train.spacy",
    >>>                        validation_path= "project_folder/data/val.spacy",
    >>>                        config_path = "project_folder/config/config.cfg",
    >>>                        model_save_path= "project_folder/output/model/",
    >>>                        )
    """

    def __init__(self, log_file_path: str = None, log_level: str = "INFO", verbose: bool = True):
        """TextCatTrainer class initialization

        Parameters
        ----------
        log_file_path : str
            Full path of the log file to save training logs at
        log_level : str, optional
            Logging level to write logs, by default "INFO"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True
        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def generate_config(
        self,
        config_save_path: str,
        optimize: str = "efficiency",
        gpu: bool = False,
        pretrained_model_config_path: str = None,
    ):
        """Generate configuration for spacy textcat training.

        Different text cat tok2vec architectures can be found here https://spacy.io/api/architectures#tok2vec-arch

        Different text cat model architectures can be found here https://spacy.io/api/architectures#textcat

        Parameters
        ----------
        config_save_path : str
            Full path to save config file Example - "project_folder/config/config.cfg"
        optimize : str, optional
            Optimize for "efficiency" or "accuracy", by default "efficiency"
        gpu : bool, optional
            Flag to indicate whether to use GPU for training, defaults to False
        pretrained_model_config_path : str, optional
            The config path for the pretrained_model. Should be provided for retraining model. When provided, it will read the config file and fill/update the given parameter and save it in config_save_path. Example - "project_folder/config/config_version_old.cfg". Default None.

        Raises
        ------
        ValueError
            config_save_path parameter is not a string
        ValueError
            optimize parameter is not a string
        ValueError
            optimize parameter is not "efficiency" or "accuracy"
        ValueError
            config_save_path is a file path and not a directory
        subprocess.CalledProcessError
            Any error during config generation cli

        Example
        -------
        >>> from tigernlp.text_classification.text_cat.api import TextCatTrainer
        >>> textcat_triner = TextCatTrainer()
        >>> textcat_triner.generate_config(config_save_path = "project_folder/config/config.cfg")


        """
        return super().generate_config(config_save_path, "textcat", optimize, gpu, pretrained_model_config_path)
