import pandas as pd
import re
import torch
import warnings
from tqdm import tqdm
from transformers import BertTokenizer
from typing import Dict, List, Tuple, Union

from tigernlp.core.utils import MyLogger

warnings.filterwarnings("ignore")

tqdm.pandas()


class Tokenizer:

    def __init__(self, model_name : str = "bert-base-uncased"):
        # BertTokenizer
        self.tokenizer = BertTokenizer.from_pretrained(model_name, do_lower_case=True)
        self.device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")

    def tokenize_text(self, text: str, cls_sep=True) -> List[int]:
        """
        Given text, convert it to list of token ids

        Parameters
        ----------
        text : str
            Text to get token ids for
        cls_sep : bool, optional
            If CLS and SEP tags are to be added, by default True

        Returns
        -------
        List[int]
            List of token ids
        """

        if cls_sep:
            text = f"[CLS] {text} [SEP]"
        tokenized_text = self.tokenizer.tokenize(text)
        return self.tokenizer.convert_tokens_to_ids(tokenized_text)


class DataProcessor(Tokenizer):
    """
    This class contains the methods to process the raw data and convert it to the format reqiured for classification/label prediction using Laban label detection.
    The Laban requires input data as a list of tuples containing the first element as the list of tokens and the second element as the index of the label/label.

    Example: ``[([120, 122, 63, 987], 0), ([682, 541, 241, 160, 78], 1)]``,
    for multilabel - ``[([2052, 2066, 2000, 2113, 1996, 6412, 1997, 1037, 2482, 20544, 2189], [58, 24])]``.

    Label/label dictionary example - {'label 1':(0, [122, 152]), 'label 2':(1, [51, 522])}

    Example
    -------
    >>> from tigernlp.text_classification.api import LABANDataProcessor
    >>> DataProcessor = LABANDataProcessor()
    """

    def __init__(self):
        """
        Example
        -------
        >>> from tigernlp.text_classification.api import LABANDataProcessor
        >>> DataProcessor = LABANDataProcessor()
        """
        # Inherit Tokenizer
        super().__init__()
        # Text cleaning defaults
        self.REPLACE_BY_SPACE_RE = re.compile(r"[/(){}\[\]\|@,;]")
        self.BAD_SYMBOLS_RE = re.compile(r"[^0-9a-z #+_]")

    def _clean_text(self, text: str) -> str:
        """Performs basic text cleaning

        Parameters
        ----------
        text : str
            Text to be cleaned

        Returns
        -------
        str
            Cleaned text
        """
        text = text.lower()  # lowercase text
        text = re.sub(
            self.REPLACE_BY_SPACE_RE, " ", text
        )  # replace REPLACE_BY_SPACE_RE symbols by space in text
        text = re.sub(
            self.BAD_SYMBOLS_RE, "", text
        )  # delete symbols which are in BAD_SYMBOLS_RE from text
        text = re.sub(r"[ ]+", " ", text)
        text = re.sub(r"\!+", "!", text)
        text = re.sub(r"\,+", ",", text)
        text = re.sub(r"\?+", "?", text)
        text = text.replace("#", "")
        return text

    def process_data_classification(
        self,
        data: pd.DataFrame,
        text_column: str,
        label_column: str,
        multilabel: bool = False,
        basic_text_cleaning: str = True,
        return_df: bool = False,
    ) -> Union[
        List[tuple],
        Dict[str, Tuple[int, tuple]],
        pd.DataFrame,
    ]:
        """
        Process raw data to convert it to format required for classification.
        This function can individually convert raw data to processed format and can also optionally perform train test split.
        If train test split is to be performed, then data is stratified by default.
        Given a pandas dataframe containing text column and label column, BertTokenizer is used to convert text to ids for both text and labels.
        This is in-turn returned as a tuple.
        Basic text cleaning is also performed which removes extra symbols but label column is expected to be processed and cleaned before running this function.

        Parameters
        ----------
        data : pd.DataFrame
            Pandas dataframe containing text and cleaned label data
        text_column : str
            Column name containing text
        label_column : str
            Column name containing label
        multilabel: bool, optional
            Set as ``True`` if a sentence in the data contains more than one label/label, by default ``False``.
        basic_text_cleaning: bool, optional
            If basic text cleaning like removing symbols is to be done, by default ``True``.
            Basic text cleaning involves removing punctuation and special characters, converting text to lowercase.
        return_df : bool, optional
            If respective dataframe should be returned along with processed data, by default False

        Returns
        -------
        Union[
            List[tuple],
            Dict[str, Tuple[int, tuple]],
            pd.DataFrame,
        ]
            Data and Data label dictionary are returned by default.
            Data example - [([120, 122, 63, 987], 0), ([682, 541, 241, 160, 78], 1)]
            for multilabel - ([2052, 2066, 2000, 2113, 1996, 6412, 1997, 1037, 2482, 20544, 2189], [58, 24])
            Data label dictionary example - {'label 1':(0, [122, 152]), 'label 2':(1, [51, 522])}

            In data example the first item in tuple is list of tokens for text and second item is label index/list of label index.
            This label index can be tracked back by lookup data label dictionary, first item in value tuple

            If return_df is True, a dataframe corresponding to data will be returned
        """
        logger = MyLogger().logger

        if not isinstance(data, pd.DataFrame):
            logger.error(
                "Incorrect type for 'data', provided: {}, expected: 'DataFrame'.".format(
                    type(data)
                )
            )
            raise ValueError("Incorrect type for 'data', provide a valid DataFrame.")

        if not isinstance(text_column, str):
            logger.error(
                "Incorrect type for 'text_column', provided: {}, expected: 'str'.".format(
                    type(text_column)
                )
            )
            raise ValueError("Incorrect type for 'text_column', provide a valid str.")

        if not isinstance(label_column, str):
            logger.error(
                "Incorrect type for 'label_column', provided: {}, expected: 'str'.".format(
                    type(label_column)
                )
            )
            raise ValueError("Incorrect type for 'label_column', provide a valid str.")

        # Works only for single label
        if not multilabel:
            # Clean data
            if basic_text_cleaning:
                data[text_column] = data[text_column].progress_apply(self._clean_text)
                data[label_column] = data[label_column].progress_apply(self._clean_text)
            # Tokenize data
            data[f"{text_column}_tokenized"] = data[text_column].progress_apply(
                self.tokenize_text, cls_sep=False
            )

            all_labels = data[label_column].value_counts().to_dict().keys()
            all_label_token_ids = [
                self.tokenize_text(label, cls_sep=False) for label in all_labels
            ]

            all_label_index_mapping = {label: idx for idx, label in enumerate(all_labels)}

            data[f"_{label_column}_indices"] = data[label_column].apply(
                lambda x: all_label_index_mapping[x]
            )

            raw_data = list(
                zip(
                    data[f"{text_column}_tokenized"],
                    data[f"_{label_column}_indices"],
                )
            )

            data_label_dict = {
                label: (idx, tokens)
                for idx, (label, tokens) in enumerate(zip(all_labels, all_label_token_ids))
            }
            if return_df:
                return raw_data, data_label_dict, data
            else:
                return raw_data, data_label_dict

        if multilabel:
            # Clean data
            if basic_text_cleaning:
                data[text_column] = data[text_column].progress_apply(self._clean_text)
                data[label_column] = data[label_column].str.replace("[_.]", " ", regex=True)
            # Tokenize data
            data[f"{text_column}_tokenized"] = data[text_column].progress_apply(
                self.tokenize_text, cls_sep=False
            )

            all_labels = data[label_column].to_list()
            all_labels = [x.split(",") for x in all_labels]
            all_labels = [j for sub_labels in all_labels for j in sub_labels]
            all_labels = set(all_labels)

            all_label_token_ids = [
                self.tokenize_text(label, cls_sep=False) for label in all_labels
            ]

            all_label_index_mapping = {label: idx for idx, label in enumerate(all_labels)}

            data[f"_{label_column}_indices"] = data[label_column].apply(
                lambda x: [all_label_index_mapping[i] for i in x.split(",")]
            )

            raw_data = list(
                zip(
                    data[f"{text_column}_tokenized"],
                    data[f"_{label_column}_indices"],
                )
            )

            data_label_dict = {
                label: (idx, tokens)
                for idx, (label, tokens) in enumerate(zip(all_labels, all_label_token_ids))
            }
            if return_df:
                return raw_data, data_label_dict, data
            else:
                return raw_data, data_label_dict
