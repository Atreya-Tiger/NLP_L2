"""
For model training and inference (zero-shot learning and classification)
"""

import os
import torch
from tensorflow.keras.preprocessing.sequence import pad_sequences
from torch.optim import AdamW
from torch.optim.lr_scheduler import ReduceLROnPlateau
from tqdm import tqdm
from transformers import BertConfig
from typing import Dict, List, Tuple

from tigernlp.core.eval_metrics_ import classification_model_report, partial_match_metrics
from tigernlp.core.utils import MyLogger

from .data_loader import get_dataloader
from .data_prepare import DataProcessor
from .model import BertZSL


def pad_data(X: list, maxlen: int) -> Tuple[List[List[int]], List[List[int]]]:
    """
    Perform data padding

    Parameters
    ----------
    X : list
        Data to pad
    maxlen : int
        Max length to pad sequences

    Returns
    -------
    List[List[int]]
        List of tokens ids
    List[List[int]]
        List of Masks
    """
    input_ids = pad_sequences(X, maxlen=maxlen, dtype="long", truncating="post", padding="post")

    attention_masks = []
    for seq in input_ids:
        seq_mask = [float(i > 0) for i in seq]
        attention_masks.append(seq_mask)
    return (input_ids, attention_masks)


def run_train(
    train_data: list,
    val_data: list,
    classes: list,
    train_tokens: Dict[str, Tuple[int, tuple]],
    config: object = None,
    model_save_path: str = None,
    log_level: str = "INFO",
    log_file_path: str = None,
    verbose: bool = True,
):
    """
    Training pipeline which takes in data, performs train test split according to the parameters specified, loads and trains the model and saves the best model to path specified.

    Parameters
    ----------
    train_data : list
        Data to train on.
        It accepts list of tuples containing [(X1, y1), (X2, y2)].
    val_data : list
        Data to validate on.
        It accepts list of tuples containing [(X3, y3), (X4, y4)].
    train_tokens : Dict[str, Tuple[int, tuple]]
        Train label dictionary containing label as key, and a tuple of its index and tokenized form as value.
        Example {label1 : (0, [100, 121, 150])}
    config: object, optional
        If object is provided, training starts with the object attributes.
        If set as ``None``, training starts with the default training parameters as mentioned below.
        Make sure the object should contain the following attributes:

        optimizer : str, optional
            Optimizer to use, expected options are "adamw", by default "adamw"
        criterion : str, optional
            Loss function to use, expected options are "crossentropyloss", "bcewithlogitsloss", by default "crossentropyloss"
        multilabel : bool, optional
            Set as ``True`` if a sentence in the data contains more than one labels/labels or multiple labels/labels need to be identified, by default ``False``.
        model_name : str, optional
            Which model architecture to be used by LABAN to train utterances and labels.
            Expected options are "bert", "todbert", "albert", by default "bert"
        model_path_name : str, optional
            Which vocab file to use by the model, by default "bert-base-uncased"
        surface_encoder_method : str, optional
            Surface encoder method to use.
            Expected options are "normal", "max-pooling", "h-max-pooling", "self-attentive", "self-attentive-mean", "bissect", by default "normal"
        label_aware_layer_method : str, optional
            Label aware layer method to use.
            Expected options are "zero-shot", "normal", "student", "dnn", "dot", "gram", by default "zero-shot"
        batch_size : int, optional
            Data batch size to train, by default 32
        utterance_pad_length : int, optional
            Text or utterance pad length, by default 50
        label_pad_length : int, optional
            label pad length, by default 10
        bert_vocab_size : int, optional
            Bert config vocab size, by default 32000
        bert_hidden_size : int, optional
            Bert config hidden size, by default 768
        bert_num_hidden_layers : int, optional
            Bert config hidden layers, by default 12
        bert_num_attention_heads : int, optional
            Bert config num attention heads, by default 12
        bert_intermediate_size : int, optional
            Bert config intermediate size, by default 3072
        resume_training_weights_path : str, optional
            If training is to be resumed, path to the model, by default None
        learning_rate : float, optional
            Learning rate of the model, by default 2e-5
        lr_scheduler_mode : str, optional
            Learning rate scheduler mode, by default "max"
        lr_scheduler_factor : float, optional
            Learning rate scheduler factor, by default 0.1
        lr_scheduler_patience : int, optional
            Learning rate scheduler patience, by default 4
        es_patience : int, optional
            Early stopping patience, if None early stopping will be disabled, by default None
        epochs : int, optional
            Number of epochs to run training, by default 30
        model_save_path : str, optional
            Path to save the best model, if None by default it will be saved to "_checkpoints/best_model.pth", by default None
    model_save_path : str, optional
        path to save the best model, set to ``None`` if config is provided.
    log_level : str, optional
        Level or severity of the events they are used to track, by default "INFO"
    log_file_path : str, optional
        File path to save the logs, by default None
    verbose : bool, optional
        If `True` logs will be printed to console, by default False
    random_seed : int, optional
        Random seed for reproducibility, by default 49

    Raises
    ------
    NotImplementedError
        If provided optimizer is not implemented
    NotImplementedError
        If provided loss function is not implemented
    ValueError
        If any of the provided parameters is invalid or of incorrect type
    """
    # TODO: Allow passing callable optimizer and criterion
    logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    if config:
        # get parameters from config
        config_dict = {
            param: getattr(config, param) for param in dir(config) if not param.startswith("__")
        }
        # check for all config parameters
        if "OPTIMIZER" not in config_dict.keys():
            logger.error("'OPTIMIZER' is not defined in config.")
            raise ValueError("'OPTIMIZER' is not defined in config.")

        if "CRITERION" not in config_dict.keys():
            logger.error("'CRITERION' is not defined in config.")
            raise ValueError("'CRITERION' is not defined in config.")

        if "MODEL_NAME" not in config_dict.keys():
            logger.error("'MODEL_NAME' is not defined in config.")
            raise ValueError("'MODEL_NAME' is not defined in config.")

        if "MODEL_PATH_NAME" not in config_dict.keys():
            logger.error("'MODEL_PATH_NAME' is not defined in config.")
            raise ValueError("'MODEL_PATH_NAME' is not defined in config.")

        if "MULTILABEL" not in config_dict.keys():
            logger.error("'MULTILABEL' is not defined in config.")
            raise ValueError("'MULTILABEL' is not defined in config.")

        if "SURFACE_ENCODER_METHOD" not in config_dict.keys():
            logger.error("'SURFACE_ENCODER_METHOD' is not defined in config.")
            raise ValueError("'SURFACE_ENCODER_METHOD' is not defined in config.")

        if "LABEL_AWARE_LAYER_METHOD" not in config_dict.keys():
            logger.error("'LABEL_AWARE_LAYER_METHOD' is not defined in config.")
            raise ValueError("'LABEL_AWARE_LAYER_METHOD' is not defined in config.")

        if "BATCH_SIZE" not in config_dict.keys():
            logger.error("'BATCH_SIZE' is not defined in config.")
            raise ValueError("'BATCH_SIZE' is not defined in config.")

        if "UTTERANCE_PAD_LENGTH" not in config_dict.keys():
            logger.error("'UTTERANCE_PAD_LENGTH' is not defined in config.")
            raise ValueError("'UTTERANCE_PAD_LENGTH' is not defined in config.")

        if "LABEL_PAD_LENGTH" not in config_dict.keys():
            logger.error("'LABEL_PAD_LENGTH' is not defined in config.")
            raise ValueError("'LABEL_PAD_LENGTH' is not defined in config.")

        if "BERT_VOCAB_SIZE" not in config_dict.keys():
            logger.error("'BERT_VOCAB_SIZE' is not defined in config.")
            raise ValueError("'BERT_VOCAB_SIZE' is not defined in config.")

        if "BERT_HIDDEN_SIZE" not in config_dict.keys():
            logger.error("'BERT_HIDDEN_SIZE' is not defined in config.")
            raise ValueError("'BERT_HIDDEN_SIZE' is not defined in config.")

        if "BERT_NUM_HIDDEN_LAYERS" not in config_dict.keys():
            logger.error("'BERT_NUM_HIDDEN_LAYERS' is not defined in config.")
            raise ValueError("'BERT_NUM_HIDDEN_LAYERS' is not defined in config.")

        if "BERT_NUM_ATTENTION_HEADS" not in config_dict.keys():
            logger.error("'BERT_NUM_ATTENTION_HEADS' is not defined in config.")
            raise ValueError("'BERT_NUM_ATTENTION_HEADS' is not defined in config.")

        if "BERT_INTERMEDIATE_SIZE" not in config_dict.keys():
            logger.error("'BERT_INTERMEDIATE_SIZE' is not defined in config.")
            raise ValueError("'BERT_INTERMEDIATE_SIZE' is not defined in config.")

        if "PRETRAINED_WEIGHTS_PATH" not in config_dict.keys():
            logger.error("'PRETRAINED_WEIGHTS_PATH' is not defined in config.")
            raise ValueError("'PRETRAINED_WEIGHTS_PATH' is not defined in config.")

        if "LEARNING_RATE" not in config_dict.keys():
            logger.error("'LEARNING_RATE' is not defined in config.")
            raise ValueError("'LEARNING_RATE' is not defined in config.")

        if "LR_SCHEDULER_MODE" not in config_dict.keys():
            logger.error("'LR_SCHEDULER_MODE' is not defined in config.")
            raise ValueError("'LR_SCHEDULER_MODE' is not defined in config.")

        if "LR_SCHEDULER_FACTOR" not in config_dict.keys():
            logger.error("'LR_SCHEDULER_FACTOR' is not defined in config.")
            raise ValueError("'LR_SCHEDULER_FACTOR' is not defined in config.")

        if "LR_SCHEDULER_PATIENCE" not in config_dict.keys():
            logger.error("'LR_SCHEDULER_PATIENCE' is not defined in config.")
            raise ValueError("'LR_SCHEDULER_PATIENCE' is not defined in config.")

        if "EPOCHS" not in config_dict.keys():
            logger.error("'EPOCHS' is not defined in config.")
            raise ValueError("'EPOCHS' is not defined in config.")

        if "MODEL_SAVE_PATH" not in config_dict.keys():
            logger.error("'MODEL_SAVE_PATH' is not defined in config.")
            raise ValueError("'MODEL_SAVE_PATH' is not defined in config.")

        if "MODEL_SAVE_NAME" not in config_dict.keys():
            logger.error("'MODEL_SAVE_NAME' is not defined in config.")
            raise ValueError("'MODEL_SAVE_NAME' is not defined in config.")

        if "ES_PATIENCE" not in config_dict.keys():
            logger.error("'ES_PATIENCE' is not defined in config.")
            raise ValueError("'ES_PATIENCE' is not defined in config.")

        # set parameters from config object
        optimizer = config_dict["OPTIMIZER"]
        criterion = config_dict["CRITERION"]
        model_name = config_dict["MODEL_NAME"]
        model_path_name = config_dict["MODEL_PATH_NAME"]
        multilabel = config_dict["MULTILABEL"]
        surface_encoder_method = config_dict["SURFACE_ENCODER_METHOD"]
        label_aware_layer_method = config_dict["LABEL_AWARE_LAYER_METHOD"]
        batch_size = config_dict["BATCH_SIZE"]
        utterance_pad_length = config_dict["UTTERANCE_PAD_LENGTH"]
        label_pad_length = config_dict["LABEL_PAD_LENGTH"]
        bert_vocab_size = config_dict["BERT_VOCAB_SIZE"]
        bert_hidden_size = config_dict["BERT_HIDDEN_SIZE"]
        bert_num_hidden_layers = config_dict["BERT_NUM_HIDDEN_LAYERS"]
        bert_num_attention_heads = config_dict["BERT_NUM_ATTENTION_HEADS"]
        bert_intermediate_size = config_dict["BERT_INTERMEDIATE_SIZE"]
        resume_training_weights_path = config_dict["PRETRAINED_WEIGHTS_PATH"]
        learning_rate = config_dict["LEARNING_RATE"]
        lr_scheduler_mode = config_dict["LR_SCHEDULER_MODE"]
        lr_scheduler_factor = config_dict["LR_SCHEDULER_FACTOR"]
        lr_scheduler_patience = config_dict["LR_SCHEDULER_PATIENCE"]
        epochs = config_dict["EPOCHS"]

        model_save_path = os.path.join(
            config_dict["MODEL_SAVE_PATH"], config_dict["MODEL_SAVE_NAME"]
        )
        es_patience = config_dict["ES_PATIENCE"]

    else:
        optimizer = "adamw"
        criterion = "crossentropyloss"
        model_name = "bert"
        model_path_name = "bert-base-uncased"
        multilabel = False
        surface_encoder_method = "self-attentive"
        label_aware_layer_method = "gram"
        batch_size = 32
        utterance_pad_length = 50
        label_pad_length = 10
        bert_vocab_size = 32000
        bert_hidden_size = 768
        bert_num_hidden_layers = 12
        bert_num_attention_heads = 12
        bert_intermediate_size = 3072
        resume_training_weights_path = None
        learning_rate = 2e-5
        lr_scheduler_mode = "max"
        lr_scheduler_factor = 0.1
        lr_scheduler_patience = 4
        epochs = 30
        es_patience = 6

    """Main zero-shot training pipeline"""

    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    torch.backends.cudnn.enabled = False

    if not isinstance(train_data, (tuple, list)):
        logger.error(
            "Incorrect type for 'train_data', provided: {}, expected: 'list or tuple'.".format(
                type(train_data)
            )
        )
        raise ValueError("Incorrect type for 'train_data', provide a valid list.")

    if not isinstance(val_data, (tuple, list)):
        logger.error(
            "Incorrect type for 'val_data', provided: {}, expected: 'list or tuple'.".format(
                type(val_data)
            )
        )
        raise ValueError("Incorrect type for 'val_data', provide a valid list.")

    if not isinstance(train_tokens, dict):
        logger.error(
            "Incorrect type for 'train_tokens', provided: {}, expected: 'dict'.".format(
                type(train_tokens)
            )
        )
        raise ValueError("Incorrect type for 'train_tokens', provide a valid list.")

    if not isinstance(optimizer, str):
        logger.error(
            "Incorrect type for 'optimizer', provided {}, expected: 'str'.".format(
                type(optimizer)
            )
        )
        raise ValueError("Incorrect type for 'optimizer', provide a valid string.")

    if not isinstance(criterion, str):
        logger.error(
            "Incorrect type for 'criterion', provided {}, expected: 'str'.".format(type(criterion))
        )
        raise ValueError("Incorrect type for 'criterion', provide a valid string.")

    if not isinstance(multilabel, bool):
        logger.error(
            "Incorrect type for 'multilabel', provided {}, expected: 'bool'.".format(
                type(multilabel)
            )
        )
        raise ValueError("Incorrect type for 'multilabel', provide 'True' or 'False'.")

    if not isinstance(model_name, str):
        logger.error(
            "Incorrect type for 'model_name', provided {}, expected: 'str'.".format(
                type(model_name)
            )
        )
        raise ValueError("Incorrect type for 'model_name', provide a valid string.")

    if model_name not in ["bert", "todbert", "albert"]:
        logger.error(
            "Incorrect choice {} for 'model_name', expected: 'bert', or 'todbert', or 'albert'".format(
                model_name
            )
        )
        raise ValueError(
            "Incorrect choice {} for 'model_name', expected: 'bert', or 'todbert', or 'albert'".format(
                model_name
            )
        )

    if not isinstance(model_path_name, str):
        logger.error(
            "Incorrect type {} for 'model_path_name', expected a valid string.".format(
                model_path_name
            )
        )
        raise ValueError(
            "Incorrect type {} for 'model_path_name', expected a valid string.".format(
                model_path_name
            )
        )

    if not isinstance(surface_encoder_method, str):
        logger.error(
            "Incorrect type {} for 'surface_encoder_method', expected a valid string.".format(
                surface_encoder_method
            )
        )
        raise ValueError(
            "Incorrect type {} for 'surface_encoder_method', expected a valid string.".format(
                surface_encoder_method
            )
        )

    if surface_encoder_method not in [
        "normal",
        "max-pooling",
        "h-max-pooling",
        "self-attentive",
        "self-attentive-mean",
        "bissect",
    ]:
        logger.error(
            "Incorrect choice {} for 'surface_encoder_method', expected: {}".format(
                surface_encoder_method,
                [
                    "normal",
                    "max-pooling",
                    "h-max-pooling",
                    "self-attentive",
                    "self-attentive-mean",
                    "bissect",
                ],
            )
        )
        raise ValueError(
            "Incorrect choice {} for 'surface_encoder_method', expected: {}".format(
                surface_encoder_method,
                [
                    "normal",
                    "max-pooling",
                    "h-max-pooling",
                    "self-attentive",
                    "self-attentive-mean",
                    "bissect",
                ],
            )
        )

    if not isinstance(label_aware_layer_method, str):
        logger.error(
            "Incorrect type {} for 'label_aware_layer_method', expected a valid string.".format(
                label_aware_layer_method
            )
        )
        raise ValueError(
            "Incorrect type {} for 'label_aware_layer_method', expected a valid string.".format(
                label_aware_layer_method
            )
        )

    if label_aware_layer_method not in [
        "zero-shot",
        "normal",
        "student",
        "dnn",
        "dot",
        "gram",
    ]:
        logger.error(
            "Incorrect choice {} for 'label_aware_layer_method', expected: {}".format(
                label_aware_layer_method,
                ["zero-shot", "normal", "student", "dnn", "dot", "gram"],
            )
        )
        raise ValueError(
            "Incorrect choice {} for 'label_aware_layer_method', expected: {}".format(
                label_aware_layer_method,
                ["zero-shot", "normal", "student", "dnn", "dot", "gram"],
            )
        )

    if not isinstance(batch_size, int):
        logger.error("Incorrect type {} for 'batch_size', expected an integer.".format(batch_size))
        raise ValueError(
            "Incorrect type {} for 'batch_size', expected an integer.".format(batch_size)
        )

    if not isinstance(utterance_pad_length, int):
        logger.error(
            "Incorrect type {} for 'utterance_pad_length', expected an integer.".format(
                utterance_pad_length
            )
        )
        raise ValueError(
            "Incorrect type {} for 'utterance_pad_length', expected an integer.".format(
                utterance_pad_length
            )
        )

    if not isinstance(label_pad_length, int):
        logger.error(
            "Incorrect type {} for 'label_pad_length', expected an integer.".format(
                label_pad_length
            )
        )
        raise ValueError(
            "Incorrect type {} for 'label_pad_length', expected an integer.".format(
                label_pad_length
            )
        )

    if not isinstance(learning_rate, float):
        logger.error(
            "Incorrect type {} for 'learning_rate', expected 'float'.".format(learning_rate)
        )
        raise ValueError(
            "Incorrect type {} for 'learning_rate', expected 'float'.".format(learning_rate)
        )

    if es_patience and not isinstance(es_patience, int):
        logger.error(
            "Incorrect type {} for 'es_patience', expected an integer.".format(es_patience)
        )
        raise ValueError(
            "Incorrect type {} for 'es_patience', expected an integer.".format(es_patience)
        )

    if not isinstance(epochs, int):
        logger.error("Incorrect type {} for 'epochs', expected an integer.".format(epochs))
        raise ValueError("Incorrect type {} for 'epochs', expected an integer.".format(epochs))

    if model_save_path and not isinstance(model_save_path, str):
        logger.error(
            "Incorrect type {} for 'model_save_path', expected a valid string.".format(
                model_save_path
            )
        )
        raise ValueError(
            "Incorrect type {} for 'model_save_path', expected a valid string.".format(
                model_save_path
            )
        )

    if log_level not in ["INFO", "ERROR"]:
        logger.error(
            "Incorrect choice {} for 'log_level', expected: {}".format(
                log_level, ["INFO", "ERROR"]
            )
        )
        raise ValueError(
            "Incorrect choice {} for 'log_level', expected: {}".format(
                log_level,
                ["INFO", "ERROR"],
            )
        )

    if log_file_path and not isinstance(log_file_path, str):
        logger.error(
            "Incorrect type {} for 'log_file_path', expected a valid string.".format(log_file_path)
        )
        raise ValueError(
            "Incorrect type {} for 'log_file_path', expected a valid string.".format(log_file_path)
        )

    logger.info("Number of labels: {}.".format(len(train_tokens)))

    X_train, y_train = zip(*train_data)
    X_test, y_test = zip(*val_data)

    # Perform padding for texts
    X_train, mask_train = pad_data(X_train, utterance_pad_length)
    X_test, mask_test = pad_data(X_test, utterance_pad_length)

    # Get train and validation data loader
    train_loader = get_dataloader(
        X_train,
        y_train,
        mask_train,
        len(train_tokens),
        batch_size=batch_size,
        maxlen=utterance_pad_length,
        multilabel=multilabel,
    )
    val_loader = get_dataloader(
        X_test,
        y_test,
        mask_test,
        len(train_tokens),
        batch_size=batch_size,
        maxlen=utterance_pad_length,
        multilabel=multilabel,
    )

    # Get all possible train labels
    label_tokens = [label for _, (_, label) in train_tokens.items()]
    # Perform padding and get masks
    label_tok, mask_tok = pad_data(label_tokens, label_pad_length)
    label_tokens = torch.zeros(len(label_tok), label_pad_length).long().to(device)
    mask_tokens = torch.zeros(len(mask_tok), label_pad_length).long().to(device)
    for i in range(len(label_tok)):
        label_tokens[i] = torch.tensor(label_tok[i])
    for i in range(len(mask_tok)):
        mask_tokens[i] = torch.tensor(mask_tok[i])

    # Bert Config
    bert_config = BertConfig(
        vocab_size_or_config_json_file=bert_vocab_size,
        hidden_size=bert_hidden_size,
        num_hidden_layers=bert_num_hidden_layers,
        num_attention_heads=bert_num_attention_heads,
        intermediate_size=bert_intermediate_size,
    )

    # LABAN model
    model = BertZSL(
        bert_config,
        model_name=model_name,
        model_path_name=model_path_name,
        surface_encoder_method=surface_encoder_method,
        label_aware_layer_method=label_aware_layer_method,
        num_labels=len(train_tokens),
    )

    # If training is to be resumed
    if resume_training_weights_path is not None:
        model.load_state_dict(torch.load(resume_training_weights_path, map_location=device))
        logger.info("Pretrained model has been loaded.")
    else:
        logger.info("Train from scratch...")
    model = model.to(device)

    # optimizer, criterion
    if optimizer == "adamw":
        optimizer = AdamW(model.parameters(), weight_decay=0.01, lr=learning_rate)
    else:
        raise NotImplementedError("Only adamw is supported.")

    if criterion == "crossentropyloss":
        criterion = torch.nn.CrossEntropyLoss().to(device)
    elif criterion == "bcewithlogitsloss":
        criterion = torch.nn.BCEWithLogitsLoss(reduction="sum").to(device)
    else:
        raise NotImplementedError("Only crosstenropy and bcewithlogitsloss are supported.")

    best_loss = 100
    best_accuracy = 0
    best_F_1 = 0

    # Learning rate scheduler
    scheduler = ReduceLROnPlateau(
        optimizer,
        mode=lr_scheduler_mode,
        factor=lr_scheduler_factor,
        patience=lr_scheduler_patience,
        verbose=True,
    )

    # Early stopping counter
    es_counter = 0
    # If model save path is not provided, save best model to "_checkpoints/best_model.pth" by default
    if model_save_path is None:
        # If not model save path is specified, save to _checkpoints folder
        model_save_path = "_checkpoints/best_model.pth"

    if not os.path.isdir(os.path.dirname(model_save_path)):
        os.makedirs(os.path.dirname(model_save_path))

    # converting train_tokens to required format
    train_dict_labels = dict([(index, label) for label, (index, _) in train_tokens.items()])

    # Start training
    for epoch in range(epochs):
        print("====== epoch %d / %d: ======" % (epoch + 1, epochs))

        # Training Phase
        total_train_loss = 0
        total_P = 0
        total_R = 0
        total_F1 = 0
        total_acc = 0
        model.train()
        ccounter = 0

        if multilabel:
            all_match_ratio, all_missing_actual_ratio, all_missing_predicted_ratio = (
                list(),
                list(),
                list(),
            )

        for (captions_t, labels, masks) in tqdm(train_loader):

            captions_t = captions_t.to(device)
            labels = labels.to(device)
            masks = masks.to(device)

            optimizer.zero_grad()

            _, _, outputs = model(captions_t, masks, label_tokens, mask_tokens)
            train_loss = criterion(outputs, labels)

            train_loss.backward()
            optimizer.step()

            total_train_loss += train_loss

            if multilabel:
                outputs = torch.sigmoid(outputs)
                outputs = torch.where(outputs > 0.5, 1, 0)
                # converting binary values of outputs to string values of outputs
                outputs_strings = []
                for i in range(len(outputs)):
                    indices = torch.where(outputs[i])[0].tolist()
                    strings = []
                    for j in range(len(indices)):
                        strings.append(train_dict_labels[indices[j]])
                    outputs_strings.append(strings)

                # converting binary values of labels to string values of labels
                label_strings = []
                for i in range(len(labels)):
                    indices = torch.where(labels[i])[0].tolist()
                    strings = []
                    for j in range(len(indices)):
                        strings.append(train_dict_labels[indices[j]])
                    label_strings.append(strings)

            else:
                # converting binary values of outputs to string values of outputs
                outputs = torch.argmax(outputs, dim=1)
                outputs_strings = []
                for i in range(len(outputs)):
                    outputs_strings.append(train_dict_labels[int(outputs[i].item())])

                # converting binary values of labels to string values of labels
                labels_strings = []
                for i in range(len(labels)):
                    labels_strings.append(train_dict_labels[int(labels[i].item())])

            report, metrics = classification_model_report(outputs_strings, labels_strings, classes)
            if multilabel:
                P = round(report.loc["macro avg", "precision"], 3)
                R = round(report.loc["macro avg", "recall"], 3)
                F1 = round(report.loc["macro avg", "f1-score"], 3)
                acc = metrics["match_ratio"]
            else:
                P = metrics["precision"]
                R = metrics["recall"]
                F1 = metrics["f1_score"]
                acc = metrics["accuracy"]
            total_P += P
            total_R += R
            total_F1 += F1
            total_acc += acc

            if multilabel:
                (
                    match_ratio,
                    missing_actual_ratio,
                    missing_predicted_ratio,
                ) = partial_match_metrics(outputs, labels)

                all_match_ratio = all_match_ratio + list(match_ratio)
                all_missing_actual_ratio = all_missing_actual_ratio + list(missing_actual_ratio)
                all_missing_predicted_ratio = all_missing_predicted_ratio + list(missing_predicted_ratio)

            ccounter += 1

        total_train_loss = total_train_loss / ccounter

        logger.info(
            "Average train loss: {:.4f}.".format(total_train_loss)
        )

        accuracy = total_acc / ccounter
        precision = total_P / ccounter
        recall = total_R / ccounter
        f1 = total_F1 / ccounter

        if multilabel:
            all_match_ratio = sum(all_match_ratio) / train_loader.dataset.num_data
            all_missing_actual_ratio = (
                sum(all_missing_actual_ratio) / train_loader.dataset.num_data
            )
            all_missing_predicted_ratio = (
                sum(all_missing_predicted_ratio) / train_loader.dataset.num_data
            )

            logger.info(f"Average actual match ratio for train data = {all_match_ratio:.4f}")
            logger.info(
                f"Average actual missing ratio for train data = {all_missing_actual_ratio:.4f}"
            )
            logger.info(
                f"Average predicted missing ratio for train data = {all_missing_predicted_ratio:.4f}"
            )

        logger.info(f"Train accuracy = {accuracy:.4f}")
        logger.info(f"Train precision = {precision:.4f}")
        logger.info(f"Train recall = {recall:.4f}")
        logger.info(f"Train F1 Score = {f1:.4f}")

        # Validation Phase
        total_val_loss = 0
        total_P = 0
        total_R = 0
        total_F1 = 0
        total_acc = 0
        if multilabel:
            all_match_ratio, all_missing_actual_ratio, all_missing_predicted_ratio = (
                list(),
                list(),
                list(),
            )

        model.eval()
        ccounter = 0
        for (captions_t, labels, masks) in val_loader:

            captions_t = captions_t.to(device)
            labels = labels.to(device)
            masks = masks.to(device)

            with torch.no_grad():
                _, _, outputs = model(captions_t, masks, label_tokens, mask_tokens)
            val_loss = criterion(outputs, labels)

            total_val_loss += val_loss
            label_strings = []
            outputs_strings = []
            if multilabel:
                outputs = torch.sigmoid(outputs)
                outputs = torch.where(outputs > 0.5, 1, 0)
                # converting binary values of outputs to string values of outputs

                for i in range(len(outputs)):
                    indices = torch.where(outputs[i])[0].tolist()
                    strings = []
                    for j in range(len(indices)):
                        strings.append(train_dict_labels[indices[j]])
                    outputs_strings.append(strings)

                # converting binary values of labels to string values of labels
                for i in range(len(labels)):
                    indices = torch.where(labels[i])[0].tolist()
                    strings = []
                    for j in range(len(indices)):
                        strings.append(train_dict_labels[indices[j]])
                    label_strings.append(strings)

            else:
                # converting binary values of outputs to string values of outputs
                outputs = torch.argmax(outputs, dim=1)
                for i in range(len(outputs)):
                    outputs_strings.append(train_dict_labels[int(outputs[i].item())])

                # converting binary values of labels to string values of labels
                for i in range(len(labels)):
                    label_strings.append(train_dict_labels[int(labels[i].item())])

            report, metrics = classification_model_report(outputs_strings, label_strings, classes)
            if multilabel:
                P = round(report.loc["macro avg", "precision"], 3)
                R = round(report.loc["macro avg", "recall"], 3)
                F1 = round(report.loc["macro avg", "f1-score"], 3)
                acc = metrics["match_ratio"]
            else:
                P = metrics["precision"]
                R = metrics["recall"]
                F1 = metrics["f1_score"]
                acc = metrics["accuracy"]
            total_P += P
            total_R += R
            total_F1 += F1
            total_acc += acc
            if multilabel:
                (
                    match_ratio,
                    missing_actual_ratio,
                    missing_predicted_ratio,
                ) = partial_match_metrics(outputs, labels)
                all_match_ratio = all_match_ratio + list(match_ratio)
                all_missing_actual_ratio = all_missing_actual_ratio + list(missing_actual_ratio)
                all_missing_predicted_ratio = all_missing_predicted_ratio + list(missing_predicted_ratio)

            ccounter += 1

        total_val_loss = total_val_loss / ccounter

        logger.info(
            "Average val loss: {:.4f}.".format(total_val_loss)
        )

        val_acc = total_acc / ccounter
        precision = total_P / ccounter
        recall = total_R / ccounter
        f1 = total_F1 / ccounter
        if multilabel:
            all_match_ratio = sum(all_match_ratio) / val_loader.dataset.num_data
            all_missing_actual_ratio = sum(all_missing_actual_ratio) / val_loader.dataset.num_data
            all_missing_predicted_ratio = (
                sum(all_missing_predicted_ratio) / val_loader.dataset.num_data
            )

            logger.info(f"Average actual match ratio for validation data = {all_match_ratio:.4f}")
            logger.info(
                f"Average actual missing ratio for validation data = {all_missing_actual_ratio:.4f}"
            )
            logger.info(
                f"Average predicted missing ratio for validation data = {all_missing_predicted_ratio:.4f}"
            )

        logger.info(f"Validation accuracy = {val_acc:.4f}")
        logger.info(f"Validation precision = {precision:.4f}")
        logger.info(f"Validation recall = {recall:.4f}")
        logger.info(f"Validation F1 Score = {f1:.4f}")

        # For multilabel if F1 score is greater than best F1 score, save the model
        if multilabel:
            if total_val_loss < best_loss:
                logger.info(
                    "saving with loss of {}, \n improved over previous {}.".format(
                        total_val_loss, best_loss
                    )
                )
                best_loss = total_val_loss
                best_F_1 = f1
                es_counter = 0
                # Save the model
                torch.save(model.state_dict(), model_save_path)

            else:
                # If model doesn't improve, increment early stopping counter
                es_counter += 1
            scheduler.step(f1)

            # update best validation accuracy
            if val_acc > best_accuracy:
                best_accuracy = val_acc

        # If current validation accuracy is greater than best accuracy (for single label) so far, save the model
        else:
            if val_acc > best_accuracy:

                logger.info(
                    "saving with loss of {}, \n improved over previous {}.".format(
                        total_val_loss, best_loss
                    )
                )
                best_loss = total_val_loss
                best_accuracy = val_acc

                es_counter = 0
                # Save the model
                torch.save(model.state_dict(), model_save_path)

            else:
                # If model doesn't improve, increment early stopping counter
                es_counter += 1

            scheduler.step(val_acc)

        if es_patience:
            # If early stopping is enabled and patience level is reached, stop training
            if es_counter == es_patience:
                if multilabel:
                    logger.info(
                        f"Early stopping due to no improvement in validation F1-Score for {es_counter} epochs\n"
                    )
                else:
                    logger.info(
                        f"Early stopping due to no improvement in validation accuracy for {es_counter} epochs\n"
                    )
                break
    logger.info("Best total Validation loss: {:.4f}".format(total_val_loss))
    if multilabel:
        logger.info("Best validation F1-Score: {:.4f}".format(best_F_1))
    else:
        logger.info("Best Validation Accuracy: {:.4f}".format(best_accuracy))
    print("\n")


#####################################################################


def run_test(
    test_data: list,
    classes: list,
    test_tokens: Dict[str, Tuple[int, tuple]],
    train_tokens: Dict[str, Tuple[int, tuple]],
    config=None,
    model_load_path: str = None,
    error_report_path: str = None,
    log_level: str = "INFO",
    log_file_path: str = None,
    verbose: bool = True,
):
    """
    Tests model on test data and prints accuracy, precision, recall and f1 score

    Parameters
    ----------
    test_data : list
        Data to test on.
        It accepts lists containing [(X1, y1), (X2, y2)]
    test_tokens : Dict[str, Tuple[int, tuple]]
        Test label dictionary containing label as key, and a tuple of its index and tokenized form as value.
        Example {label1 : (0, [100, 121, 150])}
    train_tokens : Dict[str, Tuple[int, tuple]]
        Train label dictionary containing label as key, and a tuple of its index and tokenized form as value.
        Example {label1 : (0, [100, 121, 150])}
    config: object, optional
        If object is provided, Make sure it should contain the following attributes:
        If set as ``None``, the model will be tested against default parameters as mentioned below.

        model_load_path : str
            Full path of the trained model
        multilabel : bool, optional
            Set as ``True`` if a sentence in the data contains more than one labels/labels or multiple labels/labels need to be identified, by default ``False``.
        model_name : str, optional
            Which model architecture is used by loaded model.
            Expected options are "bert", "todbert", "albert", by default "bert"
        surface_encoder_method : str, optional
            Surface encoder method of loaded model.
            Expected options are "normal", "max-pooling", "h-max-pooling", "self-attentive", "self-attentive-mean", "bissect", by default "normal"
        label_aware_layer_method : str, optional
            Label aware layer of loaded model.
            Expected options are "zero-shot", "normal", "student", "dnn", "dot", "gram", by default "zero-shot"
        batch_size : int, optional
            Data batch size to test, by default 32
        bert_vocab_size : int, optional
            Bert config vocab size, by default 32000
        bert_hidden_size : int, optional
            Bert config hidden size, by default 768
        bert_num_hidden_layers : int, optional
            Bert config hidden layers, by default 12
        bert_num_attention_heads : int, optional
            Bert config num attention heads, by default 12
        bert_intermediate_size : int, optional
            Bert config intermediate size, by default 3072
        utterance_pad_length : int, optional
            Text or utterance pad length, by default 50
        label_pad_length : int, optional
            label pad length, by default 10
    model_load_path : str, optional
        Full path of the trained model example: ``"directory/path/to/model.pth"``.
        set to ``None`` if config is provided.
    error_report_path : str, optional
        Directory path to save error report. By default None.
        If path is provided, ``test_errors.txt`` file will be saved in provided directory.
    log_level : str, optional
        Level or severity of the events they are used to track, by default "INFO"
    log_file_path : str, optional
        File path to save the logs, by default None
    verbose : bool, optional
        If ``True`` logs will be printed to console, by default ``False``.

    Raises
    ------
    ValueError
        If any of the provided parameters is invalid or of incorrect type
    FileNotFoundError
        If model path or name is not found.
    """

    logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    if config:
        # get parameters from config
        config_dict = {
            param: getattr(config, param) for param in dir(config) if not param.startswith("__")
        }

        # check for all config parameters
        if "MODEL_SAVE_PATH" not in config_dict.keys():
            logger.error("'MODEL_SAVE_PATH' is not defined in config.")
            raise ValueError("'MODEL_SAVE_PATH' is not defined in config.")

        if "MODEL_SAVE_NAME" not in config_dict.keys():
            logger.error("'MODEL_SAVE_NAME' is not defined in config.")
            raise ValueError("'MODEL_SAVE_NAME' is not defined in config.")

        if "MULTILABEL" not in config_dict.keys():
            logger.error("'MULTILABEL' is not defined in config.")
            raise ValueError("'MULTILABEL' is not defined in config.")

        if "MODEL_NAME" not in config_dict.keys():
            logger.error("'MODEL_NAME' is not defined in config.")
            raise ValueError("'MODEL_NAME' is not defined in config.")

        if "MODEL_PATH_NAME" not in config_dict.keys():
            logger.error("'MODEL_PATH_NAME' is not defined in config.")
            raise ValueError("'MODEL_PATH_NAME' is not defined in config.")

        if "SURFACE_ENCODER_METHOD" not in config_dict.keys():
            logger.error("'SURFACE_ENCODER_METHOD' is not defined in config.")
            raise ValueError("'SURFACE_ENCODER_METHOD' is not defined in config.")

        if "LABEL_AWARE_LAYER_METHOD" not in config_dict.keys():
            logger.error("'LABEL_AWARE_LAYER_METHOD' is not defined in config.")
            raise ValueError("'LABEL_AWARE_LAYER_METHOD' is not defined in config.")

        if "BATCH_SIZE" not in config_dict.keys():
            logger.error("'BATCH_SIZE' is not defined in config.")
            raise ValueError("'BATCH_SIZE' is not defined in config.")

        if "BERT_VOCAB_SIZE" not in config_dict.keys():
            logger.error("'BERT_VOCAB_SIZE' is not defined in config.")
            raise ValueError("'BERT_VOCAB_SIZE' is not defined in config.")

        if "BERT_HIDDEN_SIZE" not in config_dict.keys():
            logger.error("'BERT_HIDDEN_SIZE' is not defined in config.")
            raise ValueError("'BERT_HIDDEN_SIZE' is not defined in config.")

        if "BERT_NUM_HIDDEN_LAYERS" not in config_dict.keys():
            logger.error("'BERT_NUM_HIDDEN_LAYERS' is not defined in config.")
            raise ValueError("'BERT_NUM_HIDDEN_LAYERS' is not defined in config.")

        if "BERT_NUM_ATTENTION_HEADS" not in config_dict.keys():
            logger.error("'BERT_NUM_ATTENTION_HEADS' is not defined in config.")
            raise ValueError("'BERT_NUM_ATTENTION_HEADS' is not defined in config.")

        if "BERT_INTERMEDIATE_SIZE" not in config_dict.keys():
            logger.error("'BERT_INTERMEDIATE_SIZE' is not defined in config.")
            raise ValueError("'BERT_INTERMEDIATE_SIZE' is not defined in config.")

        if "UTTERANCE_PAD_LENGTH" not in config_dict.keys():
            logger.error("'UTTERANCE_PAD_LENGTH' is not defined in config.")
            raise ValueError("'UTTERANCE_PAD_LENGTH' is not defined in config.")

        if "LABEL_PAD_LENGTH" not in config_dict.keys():
            logger.error("'LABEL_PAD_LENGTH' is not defined in config.")
            raise ValueError("'LABEL_PAD_LENGTH' is not defined in config.")

        # set parameters

        multilabel = config_dict["MULTILABEL"]
        model_name = config_dict["MODEL_NAME"]
        model_path_name = config_dict["MODEL_PATH_NAME"]
        surface_encoder_method = config_dict["SURFACE_ENCODER_METHOD"]
        label_aware_layer_method = config_dict["LABEL_AWARE_LAYER_METHOD"]
        batch_size = config_dict["BATCH_SIZE"]
        bert_vocab_size = config_dict["BERT_VOCAB_SIZE"]
        bert_hidden_size = config_dict["BERT_HIDDEN_SIZE"]
        bert_num_hidden_layers = config_dict["BERT_NUM_HIDDEN_LAYERS"]
        bert_num_attention_heads = config_dict["BERT_NUM_ATTENTION_HEADS"]
        bert_intermediate_size = config_dict["BERT_INTERMEDIATE_SIZE"]
        utterance_pad_length = config_dict["UTTERANCE_PAD_LENGTH"]
        label_pad_length = config_dict["LABEL_PAD_LENGTH"]
        model_load_path = os.path.join(
            config_dict["MODEL_SAVE_PATH"], config_dict["MODEL_SAVE_NAME"]
        )

    else:
        multilabel = False
        model_name = "bert"
        model_path_name = "bert-base-uncased"
        surface_encoder_method = "self-attentive"
        label_aware_layer_method = "gram"
        batch_size = 32
        bert_vocab_size = 32000
        bert_hidden_size = 768
        bert_num_hidden_layers = 12
        bert_num_attention_heads = 12
        bert_intermediate_size = 3072
        utterance_pad_length = 50
        label_pad_length = 10

        if not model_load_path:
            logger.error("model_load_path is not provided.")
            raise ValueError("model_load_path is not provided.")

    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    torch.backends.cudnn.enabled = False

    dataProcessor = DataProcessor()

    if not isinstance(test_data, list):
        logger.error(
            "Incorrect type for 'test_data', provided: {}, expected: 'list'.".format(
                type(test_data)
            )
        )
        raise ValueError("Incorrect type for 'test_data', provide a valid list.")

    if not isinstance(test_tokens, dict):
        logger.error(
            "Incorrect type for 'test_tokens', provided: {}, expected: 'dict'.".format(
                type(test_tokens)
            )
        )
        raise ValueError("Incorrect type for 'test_tokens', provide a valid list.")

    if not isinstance(train_tokens, dict):
        logger.error(
            "Incorrect type for 'train_tokens', provided: {}, expected: 'dict'.".format(
                type(train_tokens)
            )
        )
        raise ValueError("Incorrect type for 'train_tokens', provide a valid list.")

    if not isinstance(multilabel, bool):
        logger.error(
            "Incorrect type for 'multilabel', provided {}, expected: 'bool'.".format(
                type(multilabel)
            )
        )
        raise ValueError("Incorrect type for 'multilabel', provide 'True' or 'False'.")

    if not isinstance(model_name, str):
        logger.error(
            "Incorrect type for 'model_name', provided {}, expected: 'str'.".format(
                type(model_name)
            )
        )
        raise ValueError("Incorrect type for 'model_name', provide a valid string.")

    if model_name not in ["bert", "todbert", "albert"]:
        logger.error(
            "Incorrect choice {} for 'model_name', expected: 'bert', or 'todbert', or 'albert'".format(
                model_name
            )
        )
        raise ValueError(
            "Incorrect choice {} for 'model_name', expected: 'bert', or 'todbert', or 'albert'".format(
                model_name
            )
        )

    if not isinstance(model_path_name, str):
        logger.error(
            "Incorrect type {} for 'model_path_name', expected a valid string.".format(
                model_path_name
            )
        )
        raise ValueError(
            "Incorrect type {} for 'model_path_name', expected a valid string.".format(
                model_path_name
            )
        )

    if not isinstance(surface_encoder_method, str):
        logger.error(
            "Incorrect type {} for 'surface_encoder_method', expected a valid string.".format(
                surface_encoder_method
            )
        )
        raise ValueError(
            "Incorrect type {} for 'surface_encoder_method', expected a valid string.".format(
                surface_encoder_method
            )
        )

    if surface_encoder_method not in [
        "normal",
        "max-pooling",
        "h-max-pooling",
        "self-attentive",
        "self-attentive-mean",
        "bissect",
    ]:
        logger.error(
            "Incorrect choice {} for 'surface_encoder_method', expected: {}".format(
                surface_encoder_method,
                [
                    "normal",
                    "max-pooling",
                    "h-max-pooling",
                    "self-attentive",
                    "self-attentive-mean",
                    "bissect",
                ],
            )
        )
        raise ValueError(
            "Incorrect choice {} for 'surface_encoder_method', expected: {}".format(
                surface_encoder_method,
                [
                    "normal",
                    "max-pooling",
                    "h-max-pooling",
                    "self-attentive",
                    "self-attentive-mean",
                    "bissect",
                ],
            )
        )

    if not isinstance(label_aware_layer_method, str):
        logger.error(
            "Incorrect type {} for 'label_aware_layer_method', expected a valid string.".format(
                label_aware_layer_method
            )
        )
        raise ValueError(
            "Incorrect type {} for 'label_aware_layer_method', expected a valid string.".format(
                label_aware_layer_method
            )
        )

    if label_aware_layer_method not in [
        "zero-shot",
        "normal",
        "student",
        "dnn",
        "dot",
        "gram",
    ]:
        logger.error(
            "Incorrect choice {} for 'label_aware_layer_method', expected: {}".format(
                label_aware_layer_method,
                ["zero-shot", "normal", "student", "dnn", "dot", "gram"],
            )
        )
        raise ValueError(
            "Incorrect choice {} for 'label_aware_layer_method', expected: {}".format(
                label_aware_layer_method,
                ["zero-shot", "normal", "student", "dnn", "dot", "gram"],
            )
        )

    if not isinstance(batch_size, int):
        logger.error("Incorrect type {} for 'batch_size', expected an integer.".format(batch_size))
        raise ValueError(
            "Incorrect type {} for 'batch_size', expected an integer.".format(batch_size)
        )

    if not isinstance(utterance_pad_length, int):
        logger.error(
            "Incorrect type {} for 'utterance_pad_length', expected an integer.".format(
                utterance_pad_length
            )
        )
        raise ValueError(
            "Incorrect type {} for 'utterance_pad_length', expected an integer.".format(
                utterance_pad_length
            )
        )

    if not isinstance(label_pad_length, int):
        logger.error(
            "Incorrect type {} for 'label_pad_length', expected an integer.".format(
                label_pad_length
            )
        )
        raise ValueError(
            "Incorrect type {} for 'label_pad_length', expected an integer.".format(
                label_pad_length
            )
        )

    if error_report_path and not isinstance(error_report_path, str):
        logger.error(
            "Incorrect type {} for 'error_report_path', expected a valid string.".format(
                error_report_path
            )
        )
        raise ValueError(
            "Incorrect type {} for 'error_report_path', expected a valid string.".format(
                error_report_path
            )
        )

    if log_level not in ["INFO", "ERROR"]:
        logger.error(
            "Incorrect choice {} for 'log_level', expected: {}".format(
                log_level, ["INFO", "ERROR"]
            )
        )
        raise ValueError(
            "Incorrect choice {} for 'log_level', expected: {}".format(
                log_level,
                ["INFO", "ERROR"],
            )
        )

    if log_file_path and not isinstance(log_file_path, str):
        logger.error(
            "Incorrect type {} for 'log_file_path', expected a valid string.".format(log_file_path)
        )
        raise ValueError(
            "Incorrect type {} for 'log_file_path', expected a valid string.".format(log_file_path)
        )

    # dataset
    logger.info("Train dictionary: \n {}".format(train_tokens))
    logger.info("Test dictionary: \n {}".format(test_tokens))
    logger.info("Number of training labels: {}".format(len(train_tokens)))
    logger.info("Number of testing labels: {}".format(len(test_tokens)))

    # Load data
    X_test, y_test = zip(*test_data)

    # Pad utterances
    X_test, mask_test = pad_data(X_test, utterance_pad_length)

    # Get all possible train labels
    all_tokens = train_tokens.copy()
    all_tokens.update(test_tokens)
    label_tokens = [label for name, (tag, label) in all_tokens.items()]
    # Perform padding and get masks
    label_tok, mask_tok = pad_data(label_tokens, label_pad_length)
    label_tokens = torch.zeros(len(label_tok), label_pad_length).long().to(device)
    mask_tokens = torch.zeros(len(mask_tok), label_pad_length).long().to(device)
    for i in range(len(label_tok)):
        label_tokens[i] = torch.tensor(label_tok[i])
    for i in range(len(mask_tok)):
        mask_tokens[i] = torch.tensor(mask_tok[i])

    # Bert Config
    bert_config = BertConfig(
        vocab_size_or_config_json_file=bert_vocab_size,
        hidden_size=bert_hidden_size,
        num_hidden_layers=bert_num_hidden_layers,
        num_attention_heads=bert_num_attention_heads,
        intermediate_size=bert_intermediate_size,
    )

    # LABAN model
    model = BertZSL(
        bert_config,
        model_name=model_name,
        model_path_name=model_path_name,
        surface_encoder_method=surface_encoder_method,
        label_aware_layer_method=label_aware_layer_method,
        num_labels=len(train_tokens),
    )

    # Load trained model
    model.load_state_dict(torch.load(model_load_path, map_location=device))
    logger.info(f"Pretrained model {model_load_path} has been loaded.")
    model = model.to(device)

    # Get all labels present in train and test
    all_label_tokens = train_tokens.copy()
    all_label_tokens.update(test_tokens)

    # Test Data loader
    test_loader = get_dataloader(
        X_test,
        y_test,
        mask_test,
        len(all_label_tokens),
        batch_size=batch_size,
        maxlen=utterance_pad_length,
        multilabel=multilabel,
    )
    # converting test_tokens to required format
    test_dict_labels = dict([(index, label) for label, (index, _) in test_tokens.items()])

    if multilabel:
        all_match_ratio, all_missing_actual_ratio, all_missing_predicted_ratio = (
            list(),
            list(),
            list(),
        )
    total_P, total_R, total_F1, total_acc = 0, 0, 0, 0
    ccounter = 0
    model.eval()

    error_ids, pred_labels, real_labels = [], [], []
    all_labels = list(all_tokens.keys())
    for i, (captions_t, labels, masks) in enumerate(test_loader):
        logger.info("Run prediction: {}".format(i))

        captions_t = captions_t.to(device)
        labels = labels.to(device)
        masks = masks.to(device)

        with torch.no_grad():
            _, _, outputs = model(captions_t, masks, label_tokens, mask_tokens)

        if multilabel:
            outputs = torch.sigmoid(outputs)
            outputs = torch.where(outputs > 0.5, 1, 0)

            # converting binary values of outputs to string values of outputs
            outputs_strings = []
            for i in range(len(outputs)):
                indices = torch.where(outputs[i])[0].tolist()
                strings = []
                for j in range(len(indices)):
                    strings.append(test_dict_labels[indices[j]])
                outputs_strings.append(strings)

            # converting binary values of labels to string values of labels
            label_strings = []
            for i in range(len(labels)):
                indices = torch.where(labels[i])[0].tolist()
                strings = []
                for j in range(len(indices)):
                    strings.append(test_dict_labels[indices[j]])
                label_strings.append(strings)

        else:
            # converting binary values of outputs to string values of outputs
            outputs = torch.argmax(outputs, dim=1)
            outputs_strings = []
            for i in range(len(outputs)):
                outputs_strings.append(test_dict_labels[int(outputs[i].item())])

            # converting binary values of labels to string values of labels
            labels_strings = []
            for i in range(len(labels)):
                labels_strings.append(test_dict_labels[int(labels[i].item())])

        report, metrics = classification_model_report(outputs_strings, labels_strings, classes)

        if multilabel:
            P = round(report.loc["macro avg", "precision"], 3)
            R = round(report.loc["macro avg", "recall"], 3)
            F1 = round(report.loc["macro avg", "f1-score"], 3)
            acc = metrics["match_ratio"]
        else:
            P = metrics["precision"]
            R = metrics["recall"]
            F1 = metrics["f1_score"]
            acc = metrics["accuracy"]
        total_P += P
        total_R += R
        total_F1 += F1
        total_acc += acc

        if multilabel:
            match_ratio, missing_actual_ratio, missing_predicted_ratio = partial_match_metrics(
                outputs, labels
            )
            all_match_ratio = all_match_ratio + list(match_ratio)
            all_missing_actual_ratio = all_missing_actual_ratio + list(missing_actual_ratio)
            all_missing_predicted_ratio = all_missing_predicted_ratio + list(missing_predicted_ratio)

        ccounter += 1

        # Save errors to a file
        # TODO: generate error report for multilabel
        if error_report_path:
            if multilabel:
                logger.info("error report is not implemented for multilabel.")
                error_report_path = None
            else:
                idx = labels.cpu() != torch.argmax(outputs.cpu(), dim=1)
                wrong_ids = [
                    dataProcessor.tokenizer.convert_ids_to_tokens(
                        caption, skip_special_tokens=True
                    )
                    for caption in captions_t[idx]
                ]
                error_ids += wrong_ids
                pred_labels += [
                    all_labels[label.item()] for label in torch.argmax(outputs.cpu(), dim=1)[idx]
                ]
                real_labels += [all_labels[label.item()] for label in labels.cpu()[idx]]

    if error_report_path:
        error_report_name = "test_errors.txt"
        if not os.path.isdir(error_report_path):
            os.makedirs(error_report_path)
        with open(
            os.path.join(error_report_path, error_report_name.replace(".txt", "") + ".txt"), "w"
        ) as f:
            f.write("----------- Wrong Examples ------------\n")
            for i, (caption, pred, real) in enumerate(zip(error_ids, pred_labels, real_labels)):
                f.write(str(i) + "\n")
                f.write(" ".join(caption) + "\n")
                p_r = pred  # [all_labels[p] for p in pred]
                r_r = real  # [all_labels[r] for r in real]
                f.write("Predicted label: {}\n".format(p_r))
                f.write("Real label: {}\n".format(r_r))
                f.write("------\n")

    precision = total_P / ccounter
    recall = total_R / ccounter
    f1 = total_F1 / ccounter
    accuracy = total_acc / ccounter

    if multilabel:
        all_match_ratio = sum(all_match_ratio) / test_loader.dataset.num_data
        all_missing_actual_ratio = sum(all_missing_actual_ratio) / test_loader.dataset.num_data
        all_missing_predicted_ratio = (
            sum(all_missing_predicted_ratio) / test_loader.dataset.num_data
        )

        logger.info(f"Average actual match ratio for test data = {all_match_ratio:.4f}")
        logger.info(f"Average actual missing ratio for test data = {all_missing_actual_ratio:.4f}")
        logger.info(
            f"Average predicted missing ratio for test data = {all_missing_predicted_ratio:.4f}"
        )

    logger.info(f"Test accuracy = {accuracy:.4f}")
    logger.info(f"Test Precision = {precision:.4f}")
    logger.info(f"Test Recall = {recall:.4f}")
    logger.info(f"Test F1-Score = {f1:.4f}")
