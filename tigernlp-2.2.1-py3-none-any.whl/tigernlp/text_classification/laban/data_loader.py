import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset
from typing import List


class CoreDataset(Dataset):
    def __init__(
        self,
        data: list,
        labels: List[int],
        masks: list,
        num_labels: int,
        multilabel: bool = False,
        maxlen: int = 50,
    ):
        """
        Parameters
        ----------
        data : list
            Data containing list of token ids for each text
        labels : list
            List of labels
        masks : list
            List of masks for utterances or texts
        num_labels : int
            Total number of labels in the dataset
        maxlen : int, optional
            Pad length for text, by default 50
        """
        self.data = data
        self.labels = labels
        self.masks = masks
        self.num_data = len(self.data)
        self.maxlen = maxlen
        self.num_labels = num_labels
        self.multilabel = multilabel

    def __getitem__(self, index):
        """

        Parameters
        ----------
        index : int
            Index of each row in dataset.

        Returns
        -------
        captions,labels,masks
            Returns pytorch values of captions,labels,masks of that index.

        """
        # caps
        caps = self.data[index]
        caps = torch.tensor(caps)

        # labels
        label = self.labels[index]
        if not self.multilabel:
            labels = torch.from_numpy(np.array(label))
        else:
            label = torch.LongTensor(np.array(label))
            labels = torch.zeros(self.num_labels).scatter_(0, label, 1)

        # masks
        masks = torch.tensor(self.masks[index])

        return caps, labels, masks

    def __len__(self):
        return len(self.data)


def get_dataloader(
    data: list,
    labels: List[int],
    masks: list,
    num_labels: int,
    multilabel: bool = False,
    batch_size: int = 32,
    maxlen: int = 50,
):
    """
    Generate pytorch data

    Parameters
    ----------
    data : list
        Data containing list of token ids for each text
    labels : List[int]
        List of labels
    masks : list
        List of masks for utterances or texts
    num_labels : int
        Total number of labels in the dataset
    multilabel: bool, optional
        Set as `True` if a sentence in the data contains more than one label/intent, by default `False`.
    batch_size : int, optional
        Data Loader batch size, by default 32
    maxlen : int, optional
        Padding length for encoding text, by default 50
    """
    dataset = CoreDataset(
        data,
        labels,
        masks,
        num_labels,
        multilabel,
        maxlen=maxlen,
    )
    return DataLoader(dataset, batch_size=batch_size, shuffle=False)
