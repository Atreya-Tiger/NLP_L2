import fasttext as ft
import numpy as np
import os
import pandas as pd
import time
from sklearn.metrics import accuracy_score

from tigernlp.core.utils import MyLogger
from tigernlp.text_classification.fast_text.inference import FastTextPredictor
from tigernlp.text_classification.fast_text.utils import data_prep


class FastTextTrainer(FastTextPredictor):
    """FastTextTrainer text classification model trainer class

    Parameters
    -----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Example
    -------

    >>> from tigernlp.text_classification.api import FastTextTrainer
    >>> FT = FastTextTrainer()
    >>> # Option 1 training with manual params
    >>> FT.train(input='project_folder/data/train.txt',lr=0.1,epoch=25)
    >>> # Option 2 auto hyper parameter tuning
    >>> FT.train(input='project_folder/data/train.txt',
    >>>            autotuneValidationFile = 'project_folder/data/val.txt',
    >>>            autotuneDuration=20)
    >>> # doing cross vaidation
    >>> cv_score, score_list = FT.cross_val( list_of_kfold_dataframes,
    >>>                                                text_col="text",
    >>>                                                label_col="label",
    >>>                                                path = 'project_folder/data/')
    """

    def __init__(
        self,
        log_level: str = "INFO",
        log_file_path: str = None,
        verbose: bool = True,
    ):
        """Fasttext text classification class initialization"""
        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

    def train(self, *kwrgs, **arg):
        """This function is used to train fasttext classifier.

        Parameters
        ----------
        input: str
            training text file path with file name.
        lr: int
            learning rate, recommended range 0.01 to 5.00, default 0.1
        dim: int
            size of word vectors, recommended range 1 to 1000, default 100
        ws: int
            size of the context window, default 5
        epoch: int
            number of epochs, recommended range 1 to 100, default 5
        minCount: int
            minimal number of word occurences, default 1
        minCountLabel:
            minimal number of label occurences, default 1
        minn: int
            min length of char ngram, recommended range 1 to 3, default 0
        maxn: int
            max length of char ngram, recommended range 1 to minn + 3, default 0
        neg: int
            number of negatives sampled, default 5
        wordNgrams: int
            max length of word ngram, recommended range 1 to 5, default 1
        loss: str
            loss function {ns, hs, softmax, ova}, default 'softmax'
        bucket: int
            number of buckets, recommended range 10000 to 10000000, default 2000000
        thread: int
            number of threads, default 1
        lrUpdateRate: int
            change the rate of updates for the learning rate, default 100
        t: float
            sampling threshold, default 0.0001
        label : str
            label prefix, default '__label__'
        verbose : int
            verbose, default 2
        autotuneDuration: int
            duration in seconds to do autotuning, default 10.
        autotuneValidationFile: str
            Validation file that need to be passed for the autotune. Should be in the same format as training set, default None.
        autotuneMetric: str
            metric to do autotuning on,
                {f1}
                {f1:labelname}. default "f1".
        autotuneModelSize: str
             Desired size of the model already quantized. If the value is empty, it means "do not quantize". Byte units available:
                {'k', 1000}
                {'K', 1000}
                {'m', 1000000}
                {'M', 1000000}
                {'g', 1000000000}
                {'G', 1000000000}
                example "200m" represents 200 MB. default '' (recommended)

        Example
        -------

        >>> # Option 1 training with manual params
        >>> from tigernlp.text_classification.api import FastTextTrainer
        >>> FT = FastTextTrainer()
        >>> FT.train(input='/project_folder/train.txt',lr=0.1,epoch=25)
        >>> # Option 2 auto hyper parameter tuning
        >>> from tigernlp.text_classification.api import FastTextTrainer
        >>> FT = FastTextTrainer()
        >>> FT.train(input='/project_folder/data/train.txt',
        >>>            autotuneValidationFile = '/project_folder/data/val.txt',
        >>>            autotuneDuration = 5)

        """
        try:
            self.model = ft.train_supervised(**arg)
        except Exception as e:
            self.logger.error(f"Error occurred during training.\n {e}")
            raise Exception(f"Error occurred during training.\n {e}")

    def cross_val(
        self,
        list_of_kfold_dataframes,
        text_col: str = "text",
        label_col: str = "label",
        path: str = "./",
    ):
        """This function generates cross validation score for a trained model.

        Parameters
        -----------
        list_of_kfold_dataframes: list[(pd.DataFrame,pd.DataFrame)],
            list of tuple of train and val dataframes.
        text_col : str
            name of text/example/utterance column to do prediction on. Default "text"
        label_col : str
            name of the label colum in dataframe. Default "label"
        path: str
            path of experiment folder to save cross val data for training. Example - "project_folder/data/". Default "./"

        Returns
        -------
        cv_score: float
            zverage cross validation accuracy.
        score_list: list
            list of all accuracy across cross validation.

        Raises
        ------
        ValueError
            raises value error if, no model is present or no data is present or value of k_folds has abnormal value
        TypeError
            raises type error if k_folds is not interger.

        Example
        -------
        >>> from tigernlp.text_classification.api import FastTextTrainer
        >>> FT = FastTextTrainer()
        >>> FT.train(input=input='/project_folder/train.txt',
        >>>            autotuneValidationFile = '/project_folder/val.txt',
        >>>            autotuneDuration = 5)
        >>> cv_score, score_list = FT.cross_val(list_of_kfold_dataframes,
        >>>                                            text_col="text",
        >>>                                            label_col="label",
        >>>                                            path = '/project_folder/data/')


        """
        try:
            if isinstance(self.model.epoch, int):
                self.logger.info("Cross validating trained model.")
        except Exception as e:
            self.logger.error(f"Model not found. {e}")
            raise Exception(f"Model not found. {e}")

        if not isinstance(list_of_kfold_dataframes, list):
            self.logger.error("Input must be a list of tuples of dataframe.")
            raise TypeError("Input must be a list of tuples of dataframe.")
        if not isinstance(text_col, str):
            self.logger.error("text_col must be of string type.")
            raise TypeError("text_col must be of string type.")
        if not isinstance(label_col, str):
            self.logger.error("label_col must be of string type.")
            raise TypeError("label_col must be of string type.")

        for tuple_df in list_of_kfold_dataframes:
            if not isinstance(tuple_df, tuple):
                self.logger.error("Please check the type of data inside the list.")
                TypeError("Please check the type of data inside the list.")
            if not isinstance(tuple_df[0], pd.DataFrame):
                self.logger.error("Please check the type of data inside the tuple.")
                raise TypeError("Please check the type of data inside the tuple.")
            if not isinstance(tuple_df[1], pd.DataFrame):
                self.logger.error("Please check the type of data inside the tuple.")
                raise TypeError("Please check the type of data inside the tuple.")
            train = tuple_df[0]
            val = tuple_df[1]
            if text_col not in tuple_df[0]:
                self.logger.error(f"{text_col} column not found in the dataframe")
                raise NameError(f"{text_col} column not found in the dataframe")
            if label_col not in tuple_df[0]:
                self.logger.error(f"{label_col} column not found in the dataframe")
                raise NameError(f"{label_col} column not found in the dataframe")
            if text_col not in tuple_df[1]:
                self.logger.error(f"{text_col} column not found in the dataframe")
                raise NameError(f"{text_col} column not found in the dataframe")
            if label_col not in tuple_df[1]:
                self.logger.error(f"{label_col} column not found in the dataframe")
                raise NameError(f"{label_col} column not found in the dataframe")
        try:
            score_list = []
            idx = 0
            for tuple_df in list_of_kfold_dataframes:
                train = tuple_df[0]
                val = tuple_df[1]
                train_name = os.path.join(path, "cv_train_" + str(time.time()) + ".txt")
                data_prep(
                    data=train, text_col=text_col, label_col=label_col, file_path_name=train_name
                )
                modelcv = ft.train_supervised(
                    input=train_name,
                    lr=self.model.lr,
                    dim=self.model.dim,
                    ws=self.model.ws,
                    epoch=self.model.epoch,
                    minCount=self.model.minCount,
                    minCountLabel=self.model.minCountLabel,
                    minn=self.model.minn,
                    maxn=self.model.maxn,
                    neg=self.model.neg,
                    wordNgrams=self.model.wordNgrams,
                    loss="softmax",
                    bucket=self.model.bucket,
                    thread=self.model.thread,
                    lrUpdateRate=self.model.lrUpdateRate,
                    t=self.model.t,
                    verbose=self.model.verbose,
                )

                val = self.predict(val, text_col=text_col, model=modelcv)
                accuracy = accuracy_score(val[label_col].astype(str), val["pred"].astype(str))
                score_list.append(accuracy)
                self.logger.info(f"Val Accuracy fold {idx+1} : {accuracy}")
                idx += 1
            time.sleep(1)
            cv_score = np.round(sum(score_list) / idx, 3)
            self.logger.info(f"Average cross validation accuracy : {cv_score}")
            self.logger.info("Cross vaildation done.")
            return cv_score, score_list
        except Exception as e:
            self.logger.error(f"Error occurred during cross validation.\n {e}")
            raise Exception(f"Error occurred during cross validation.\n {e}")

    def model_saver(self, path: str = "fasttext_model.bin"):
        """This function saves the trained model.

        Parameters
        ----------
        path: str
            path to save the model. Example - "project_folder/model/model_version.bin". Default "fasttext_model.bin"

        Raises
        ------
        OSError
            raises OSError when model path already exist.
        """
        if os.path.exists(path):
            raise OSError(f"{path} already exists.")
        self.model.save_model(path)
        self.logger.info("Model saved.")
