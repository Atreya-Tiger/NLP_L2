import numpy as np
import pandas as pd
import tqdm
from bertopic import BERTopic
from collections import OrderedDict
from kneed import KneeLocator
from matplotlib import pyplot as plt
from operator import itemgetter
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer

from tigernlp.core.api import get_silhouette_score, tsne_components
from tigernlp.core.visualization import hyperparameter_plot_graph, tsne_2d_visualization

from .utils import bertopic_compute_coherence_values, gsdmm_compute_coherence_values, lda_compute_coherence_values


class HyperParameterTuning:
    """
    Hyperparameter tuning class for clustering module

    Parameters
    ----------
    corpus : list
        list contains list of tuples, where each list represents one sentence, and each tuple represents word ID and number of occurences for word id in the sentence.

        For example: ``[[(0,1), (1,1), (2,1), (3,1)], [(0,1), (1,1), (4,1), (5,1)]]``
        In first sentence, word ID "2" occurs once whereas it is not present in second sentence
    id2word : dictionary
        ID to word dictionary where IDs are keys and words are values.
        Each word will have unique ID associated with it.

        For example ``{0 : "this", 1 : "is", 2 : "datawords", 3 : "sample", 4 : "one", 5 : "more"}``
    data_words : list
        list of tokenized sentences generated using input_text.

        For example: ``[["this", "is", "datawords", "sample"], ["this", "is", "one", "more"]]``
    hyper_parameter_tuning_parameters : dictionary
        hyperparameter tuning parameters for the respective algorithm
    logger : tigernlp.core.api.MyLogger
        Object of MyLogger class to log infos and errors.

    Raises
    ------
    ValueError
        hyper_parameter_tuning_parameters["metric"] supports only "silhouette" and "wcss".
        If any other value provided then function raises ValueError.
    """

    def __init__(self, input_text, corpus, id2word, data_words, hyper_parameter_tuning_parameters, logger):
        """HyperParameterTuning class initialization"""
        self.input_text = input_text
        self.data_words = data_words
        self.corpus = corpus
        self.id2word = id2word
        self.logger = logger
        self.hyper_parameter_tuning_parameters = hyper_parameter_tuning_parameters

        if "alpha" in self.hyper_parameter_tuning_parameters.keys():
            # Alpha parameter
            self.alpha = np.around(hyper_parameter_tuning_parameters["alpha"], 3)

        if "beta" in self.hyper_parameter_tuning_parameters.keys():
            # Beta parameter
            self.beta = np.around(hyper_parameter_tuning_parameters["beta"], 3)

        if "n_topics_list" in self.hyper_parameter_tuning_parameters.keys():
            # Topics range
            self.topics_range = hyper_parameter_tuning_parameters["n_topics_list"]

        if "metric" in self.hyper_parameter_tuning_parameters.keys():
            self.metric = hyper_parameter_tuning_parameters["metric"]
            if self.metric not in ["silhouette", "wcss"]:
                self.logger.error(
                    f"""Hyperparameter tuning supports "silhouette" and "wcss" metrics. Provided metric {self.metric} is not supported by the current pipeline"""
                )
                raise ValueError(
                    f"""Hyperparameter tuning supports "silhouette" and "wcss" metrics. Provided metric {self.metric} is not supported by the current pipeline"""
                )

        if "min_topic_size_list" in self.hyper_parameter_tuning_parameters.keys():
            # Minimum Topic Size Parameter
            self.min_topic_size = hyper_parameter_tuning_parameters["min_topic_size_list"]

    def best_parameter_selection(self, model_results_df, model=None):
        """Returns best hyperparameters based on coherence score for GSDMM, LDA,BERTopic"""
        best_param_dict = dict()
        best_param_output = dict()
        if model in ["bert"]:
            n_topics = model_results_df[model_results_df["Coherence"] == model_results_df["Coherence"].max()]["n_topics"].to_list()[0]
            min_topic_size = model_results_df[model_results_df["Coherence"] == model_results_df["Coherence"].max()][
                "min_topic_size"
            ].to_list()[0]
            coherence = model_results_df["Coherence"].max()
            model_results_n_topic_df = model_results_df[model_results_df["min_topic_size"] == min_topic_size]
            model_results_min_topic_size_df = model_results_df[model_results_df["n_topics"] == n_topics]

            best_param_dict["n_topics"] = int(n_topics)
            best_param_dict["min_topic_size"] = int(min_topic_size)
            best_param_dict["coherence"] = float(coherence)

            best_param_output["model_results_n_topic_df"] = model_results_n_topic_df
            best_param_output["model_results_min_topic_size_df"] = model_results_min_topic_size_df

        else:
            alpha = model_results_df[model_results_df["Coherence"] == model_results_df["Coherence"].max()]["Alpha"].to_list()[0]
            beta = model_results_df[model_results_df["Coherence"] == model_results_df["Coherence"].max()]["Beta"].to_list()[0]
            coherence = model_results_df["Coherence"].max()

            model_results_alpha_df = model_results_df[model_results_df["Beta"] == beta]
            model_results_beta_df = model_results_df[model_results_df["Alpha"] == alpha]

            best_param_dict["alpha"] = float(alpha)
            best_param_dict["beta"] = float(beta)
            best_param_dict["coherence"] = float(coherence)

            best_param_output["model_results_beta_df"] = model_results_beta_df
            best_param_output["model_results_alpha_df"] = model_results_alpha_df

        if model in ["lda"]:
            n_topics = model_results_df[model_results_df["Coherence"] == model_results_df["Coherence"].max()]["Topics"].to_list()[0]

            model_results_topics_df = model_results_df[model_results_df["Alpha"] == alpha]
            model_results_topics_df = model_results_topics_df[model_results_topics_df["Beta"] == beta]

            model_results_alpha_df = model_results_alpha_df[model_results_alpha_df["Topics"] == n_topics]
            model_results_beta_df = model_results_beta_df[model_results_beta_df["Topics"] == n_topics]

            best_param_dict["n_topics"] = int(n_topics)
            best_param_output["model_results_beta_df"] = model_results_beta_df
            best_param_output["model_results_alpha_df"] = model_results_alpha_df
            best_param_output["model_results_topics_df"] = model_results_topics_df

        return (best_param_dict, best_param_output)

    def best_hyperparameter_graph(self, model_results_df, model=None):
        """Returns best parameter and matplot lib graph for the GSDMM, LDA"""

        best_param_dict, best_param_output = self.best_parameter_selection(model_results_df, model)
        n_row = 1
        n_col = 2
        if model in ["lda"]:
            n_col = 3

        graph, ax = plt.subplots(n_row, n_col, sharex="col", sharey="row", figsize=(10, 8))

        if model in ["bert"]:
            n_topics_list = best_param_output["model_results_n_topic_df"]["n_topics"]
            coherence_list = best_param_output["model_results_n_topic_df"]["Coherence"]
            hyperparameter_plot_graph(
                ax[0], n_topics_list, coherence_list, x_label="n_topics", y_label="Coherence Value", line_x=best_param_dict["n_topics"]
            )

            min_topic_size_list = best_param_output["model_results_min_topic_size_df"]["min_topic_size"]
            coherence_list = best_param_output["model_results_min_topic_size_df"]["Coherence"]
            hyperparameter_plot_graph(
                ax[1],
                min_topic_size_list,
                coherence_list,
                x_label="min_topic_size",
                y_label="Coherence Value",
                line_x=best_param_dict["min_topic_size"],
            )
        else:
            alpha_list = best_param_output["model_results_alpha_df"]["Alpha"]
            coherence_list = best_param_output["model_results_alpha_df"]["Coherence"]
            hyperparameter_plot_graph(
                ax[0], alpha_list, coherence_list, x_label="Alpha", y_label="Coherence Value", line_x=best_param_dict["alpha"]
            )

            beta_list = best_param_output["model_results_beta_df"]["Beta"]
            coherence_list = best_param_output["model_results_beta_df"]["Coherence"]
            hyperparameter_plot_graph(
                ax[1], beta_list, coherence_list, x_label="Beta", y_label="Coherence Value", line_x=best_param_dict["beta"]
            )

        if model in ["lda"]:
            topic_list = best_param_output["model_results_topics_df"]["Topics"]
            coherence_list = best_param_output["model_results_topics_df"]["Coherence"]
            hyperparameter_plot_graph(
                ax[2],
                topic_list,
                coherence_list,
                x_label="Number of Clusters",
                y_label="Coherence Value",
                line_x=best_param_dict["n_topics"],
            )

        if model in ["lda"]:
            graph.suptitle(
                "Topic Coherence: Determining optimal value of "
                + "\nalpha = "
                + str(round(best_param_dict["alpha"], 2))
                + " beta = "
                + str(round(best_param_dict["beta"], 2))
                + "\nnumber of clusters = "
                + str(round(best_param_dict["n_topics"], 2))
                + "\nCoherence Value = "
                + str(round(best_param_dict["coherence"], 3))
            )
        elif model in ["bert"]:
            graph.suptitle(
                "Topic Coherence: Determining optimal value of "
                + "\nn_topics = "
                + str(round(best_param_dict["n_topics"], 2))
                + " min_topic_size = "
                + str(round(best_param_dict["min_topic_size"], 2))
                + "\nCoherence Value = "
                + str(round(best_param_dict["coherence"], 3))
            )
        else:
            graph.suptitle(
                "Topic Coherence: Determining optimal value of "
                + "\nalpha = "
                + str(round(best_param_dict["alpha"], 2))
                + " beta = "
                + str(round(best_param_dict["beta"], 2))
                + "\nCoherence Value = "
                + str(round(best_param_dict["coherence"], 3))
            )

        return (best_param_dict, graph)

    def gsdmm_topic_mapping(self, mgp, top_index, topic_maping_df):

        topic_dict = {}
        for i, topic_num in enumerate(top_index):
            topic_dict[topic_num] = i  # "Topic " + str(topic_num)

        prob = topic_maping_df["stems"].apply(lambda x: mgp.choose_best_label(x))
        topic_maping_df["topic_number"] = prob

        def topic_mapping(x, topic_dict):
            if x[1] >= 0:  # threshold:
                return topic_dict[x[0]]
            else:
                return -1

        # check for continuous topic number
        topic_maping_df["topic_number"] = topic_maping_df["topic_number"].apply(lambda x: topic_mapping(x, topic_dict))

        return topic_maping_df

    def lda_topic_mapping(self, lda_model, topic_maping_df):
        temp = lda_model[self.corpus]

        topic_maping_df["topic_number"] = np.arange(len(topic_maping_df))

        def topic_mapping(x, temp):
            return max(temp[x], key=lambda a: a[1])[0]

        topic_maping_df["topic_number"] = topic_maping_df["topic_number"].apply(lambda x: topic_mapping(x, temp))

        return topic_maping_df

    def gsdmm_hyper_parameter_tuning(self, max_n_topics, n_iteration, n_words, tsne_plot=False):
        """Function to run hyper parameter tuning on GSDMM

        Parameters
        ----------
        max_n_topics : int
            Maximum number of clusters to populate. GSDMM will populate less than or equal number of clusters than max_n_topics
        n_iteration : int
            Number of iterations
        n_words : int
            maximum number of words to show for each cluster
        tsne_plot: bool, optional
            if True, will return tsne_plot across hyperparameters

        Returns
        -------
        dict
            Optimal alpha and beta value after hyperparameter tuning
        matplotlib.pyplot.figure
            Graph of topic coherence score vs alpha and beta
        matplotlib.pyplot.figure
            tsne plot across hyperparameters

        """
        model_results = {"Topics": [], "Alpha": [], "Beta": [], "Coherence": []}
        fig = None
        graph = None
        topic_mapping_df = self.input_text.copy()
        # Can take a long time to run
        pbar = tqdm.tqdm(total=(len(self.beta) * len(self.alpha)))

        if tsne_plot:
            ncols = len(self.alpha)
            nrows = len(self.beta)
            fig, axes = plt.subplots(ncols=ncols, nrows=nrows, figsize=(16 * ncols, 10 * nrows))
            if ncols > 1 or nrows > 1:
                for axi in axes.ravel():
                    axi.set_axis_off()
            # iterate through alpha values
            model = TfidfVectorizer()
            matrix = model.fit_transform(topic_mapping_df["stem_text"]).toarray()
            feature_array = tsne_components(matrix, 2)

        ncol = -1
        for a in self.alpha:
            ncol = ncol + 1
            nrow = -1
            # iterare through beta values
            for b in self.beta:
                nrow = nrow + 1
                # get the coherence score for the given parameters
                self.logger.info("alpha = " + str(a) + ", beta = " + str(b))
                coherence_model, mgp, top_index = gsdmm_compute_coherence_values(
                    corpus=self.corpus,
                    dictionary=self.id2word,
                    data_words=self.data_words,
                    max_num_topics=max_n_topics,
                    alpha=a,
                    beta=b,
                    itr=n_iteration,
                    n_words=n_words,
                )

                if tsne_plot:
                    topic_mapping_df = self.gsdmm_topic_mapping(mgp, top_index, topic_mapping_df)
                    labels = np.array(topic_mapping_df["topic_number"])

                    title_to_append = " with alpha = " + str(a) + ", beta = " + str(b)

                    if ncols == 1 and nrows == 1:
                        tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes)
                        axes.set_axis_on()
                        title = axes.get_title() + title_to_append
                        axes.set_title(title)
                    elif nrows == 1:
                        tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes[ncol])
                        axes[ncol].set_axis_on()
                        title = axes[ncol].get_title() + title_to_append
                        axes[ncol].set_title(title)

                    elif ncols == 1:
                        tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes[nrow])
                        axes[nrow].set_axis_on()
                        title = axes[nrow].get_title() + title_to_append
                        axes[nrow].set_title(title)
                    else:
                        tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes[nrow][ncol])
                        axes[nrow][ncol].set_axis_on()
                        title = axes[nrow][ncol].get_title() + title_to_append
                        axes[nrow][ncol].set_title(title)

                # Save in the model results
                model_results["Topics"].append(len(coherence_model._topics))
                model_results["Alpha"].append(a)
                model_results["Beta"].append(b)
                model_results["Coherence"].append(round(coherence_model.get_coherence(), 3))

                pbar.update(1)

        pbar.close()

        model_results_df = pd.DataFrame(model_results)

        best_param_dict, graph = self.best_hyperparameter_graph(model_results_df)

        return (best_param_dict, graph, fig)

    def lda_hyper_parameter_tuning(self, n_iteration, tsne_plot=False):
        """Function to run hyper parameter tuning on LDA

        Parameters
        ----------
        n_iteration : int, optional
            number of iterations through the corpus during training, by default 40
        tsne_plot: bool, optional
            if True, will return tsne_plot across hyperparameters

        Returns
        -------
        dict
            Optimal n_topic, alpha and beta value after hyperparameter tuning
        matplotlib.pyplot.figure
            matplotlib graph of topic coherence score vs number of topics, alpha, beta
        matplotlib.pyplot.figure
            tsne plot across hyperparameters
        """

        model_results = {"Topics": [], "Alpha": [], "Beta": [], "Coherence": []}
        fig = None
        graph = None
        topic_mapping_df = self.input_text.copy()

        pbar = tqdm.tqdm(total=(len(self.beta) * len(self.alpha) * len(self.topics_range)))

        if tsne_plot:
            ncols = len(self.alpha)
            nrows = len(self.beta) * len(self.topics_range)
            fig, axes = plt.subplots(ncols=ncols, nrows=nrows, figsize=(16 * ncols, 10 * nrows))

            if ncols > 1 or nrows > 1:
                for axi in axes.ravel():
                    axi.set_axis_off()

            # iterate through alpha values
            # model = TfidfVectorizer()
            # matrix = model.fit_transform(topic_mapping_df["stem_text"]).toarray()
            # feature_array = tsne_components(matrix, 2)

        ncol = -1

        # iterate through alpha values
        for a in self.alpha:
            ncol = ncol + 1
            nrow = -1
            # iterare through beta values
            for b in self.beta:
                for k in self.topics_range:
                    nrow = nrow + 1
                    self.logger.info("alpha = " + str(a) + ", beta = " + str(b) + ", topic number = " + str(k))
                    # get the coherence score for the given parameters
                    coherence_model, lda_model = lda_compute_coherence_values(
                        corpus=self.corpus,
                        dictionary=self.id2word,
                        data_words=self.data_words,
                        num_topics=k,
                        alpha=a,
                        beta=b,
                        itr=n_iteration,
                    )

                    if tsne_plot:

                        # print("ncol = ", ncol, "nrow = ", nrow)
                        # print("alpha = " + str(a) + ", beta = " + str(b) + ", topic number = " + str(k))
                        topic_mapping_df = self.lda_topic_mapping(lda_model, topic_mapping_df)
                        labels = np.array(topic_mapping_df["topic_number"])

                        top_dist = []
                        for d in self.corpus:
                            tmp = {i: 0 for i in range(topic_mapping_df["topic_number"].nunique())}
                            tmp.update(dict(lda_model[d]))
                            vals = list(OrderedDict(tmp).values())
                            top_dist += [np.array(vals)]
                        top_dist = np.array(top_dist)
                        feature_array = tsne_components(top_dist, 2)  # , init="pca")

                        title_to_append = " with alpha = " + str(a) + ", beta = " + str(b)

                        if ncols == 1 and nrows == 1:
                            tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes)
                            axes.set_axis_on()
                            title = axes.get_title() + title_to_append
                            axes.set_title(title)
                        elif nrows == 1:
                            tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes[ncol])
                            axes[ncol].set_axis_on()
                            title = axes[ncol].get_title() + title_to_append
                            axes[ncol].set_title(title)
                        elif ncols == 1:
                            tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes[nrow])
                            axes[nrow].set_axis_on()
                            title = axes[nrow].get_title() + title_to_append
                            axes[nrow].set_title(title)
                        else:
                            tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes[nrow][ncol])
                            axes[nrow][ncol].set_axis_on()
                            title = axes[nrow][ncol].get_title() + title_to_append
                            axes[nrow][ncol].set_title(title)

                    model_results["Topics"].append(k)
                    model_results["Alpha"].append(a)
                    model_results["Beta"].append(b)
                    model_results["Coherence"].append(round(coherence_model.get_coherence(), 3))

                    pbar.update(1)
        pbar.close()

        model_results_df = pd.DataFrame(model_results)

        best_param_dict, graph = self.best_hyperparameter_graph(model_results_df, model="lda")

        return (best_param_dict, graph, fig)

    def kmeans_hyper_parameter_tuning(self, feature_array, tsne_plot=False):
        """Function to run hyper parameter tuning on K-Means

        Parameters
        ----------
        feature_array : np.Array
            Numpy array containing feature vectors.
        tsne_plot: bool, optional
            if True, will return tsne_plot across hyperparameters, by default False

        Returns
        -------
        int
            Optimal number of clusters from given number of clusters list.
        matplotlib.pyplot.figure
            A graph contains various values of n_topics and respective metric values.
        matplotlib.pyplot.figure
            tsne plot across hyperparameters
        """
        graph = None
        fig = None

        if tsne_plot:
            ncols = min(3, len(self.topics_range))
            if ncols >= 3:
                nrows = max(1, int((len(self.topics_range) + 2) / ncols))
            else:
                nrows = 1
            fig, axes = plt.subplots(ncols=ncols, nrows=nrows, figsize=(16 * ncols, 10 * nrows))
            if ncols >= 3:
                for axi in axes.ravel():
                    axi.set_axis_off()
            # iterate through alpha values
            feature_array_2d = tsne_components(feature_array, 2)

        pbar = tqdm.tqdm(total=(len(self.topics_range)))
        ncol = -1
        nrow = 0
        tot_top = 1
        metricScores = []
        for i in self.topics_range:
            ncol = ncol + 1
            self.logger.info("----- Cluster " + str(i) + " running -----")
            Kmeans = KMeans(n_clusters=i, random_state=42)
            Kmeans.fit(feature_array)
            cluster_labels = Kmeans.predict(feature_array)
            if tsne_plot:
                labels = cluster_labels
                if ncols == 1 and nrows == 1:
                    tsne_2d_visualization(feature_array=feature_array_2d, feature_array_2d=True, labels=labels, ax=axes)
                    axes.set_axis_on()
                elif nrows == 1:
                    tsne_2d_visualization(feature_array=feature_array_2d, feature_array_2d=True, labels=labels, ax=axes[ncol])
                    axes[ncol].set_axis_on()
                else:
                    tsne_2d_visualization(feature_array=feature_array_2d, feature_array_2d=True, labels=labels, ax=axes[nrow][ncol])
                    axes[nrow][ncol].set_axis_on()

                if (tot_top % (ncols)) == 0:
                    nrow = nrow + 1
                    ncol = -1
                tot_top = tot_top + 1

            if self.metric == "silhouette":
                silhouetteScore = round(get_silhouette_score(feature_array, cluster_labels), 3)
                metricScores.append((i, silhouetteScore))
            elif self.metric == "wcss":
                metricScores.append((i, round(Kmeans.inertia_, 3)))

            pbar.update(1)
        pbar.close()

        if self.metric == "silhouette":
            optimal_cluster = max(metricScores, key=itemgetter(1))[0]
            silhouette_score = max(metricScores, key=itemgetter(1))[1]
            score = round(silhouette_score, 5)

        elif self.metric == "wcss":
            # elbow logic here
            x = np.array(self.topics_range)
            y = np.array([x[1] for x in metricScores])
            kneedle = KneeLocator(x, y, S=1.0, curve="convex", direction="decreasing")
            optimal_cluster = kneedle.knee
            wcss_score = y[list(x).index(optimal_cluster)]
            score = round(wcss_score, 5)

        graph, ax = plt.subplots(1, 1, sharex="col", sharey="row")

        hyperparameter_plot_graph(
            ax,
            self.topics_range,
            [x[1] for x in metricScores],
            x_label="Number of Clusters",
            y_label=self.metric + " score",
            line_x=optimal_cluster,
        )

        ax.text(
            optimal_cluster,
            score,
            "Optimal number of clusters = " + str(optimal_cluster) + "\n" + self.metric + " score = " + str(score),
        )

        graph.suptitle("Determining optimal number of clusters using " + self.metric + " score")

        self.logger.info("Optimal number of Clusters = " + str(optimal_cluster))
        return (optimal_cluster, graph, fig)

    def bert_hyper_parameter_tuning(
        self,
        bertopic_parameters={
            "n_gram_range": (1, 1),
            "sentence_model": None,
            "embedding": None,
            "umap_model": None,
            "hdbscan_model": None,
            "vectorizer_model": None,
            "verbose": False,
        },
        tsne_plot=False,
    ):
        """Function to run hyper parameter tuning on BERTopic

        Parameters
        ----------

        bertopic_parameters : dictionary,optional
            Dictionary contains parameters for the bertopic model. for example: {'n_gram_range':(1,1),'sentence_model':None,'umap_model':None,'hdbscan_model':None,'vectorizer_model':None,'verbose':False}
        tsne_plot: bool, optional
            if True, will return tsne_plot across hyperparameters, by default False
        Returns
        -------
        dict
            Optimal n_topic and minimum topic size value after hyperparameter tuning
        matplotlib.pyplot.figure
            matplotlib graph of topic coherence score vs number of topics
        matplotlib.pyplot.figure
            tsne plot across hyperparameters
        """

        graph = None
        fig = None

        model_results = {"n_topics": [], "min_topic_size": [], "Coherence": []}

        pbar = tqdm.tqdm(total=(len(self.min_topic_size) * len(self.topics_range)))

        if tsne_plot:
            ncols = len(self.min_topic_size)
            nrows = len(self.topics_range)
            fig, axes = plt.subplots(ncols=ncols, nrows=nrows, figsize=(16 * ncols, 10 * nrows))
            if ncols > 1 or nrows > 1:
                for axi in axes.ravel():
                    axi.set_axis_off()

            feature_array = tsne_components(bertopic_parameters["embedding"], 2)

        ncol = -1
        # iterare through min_topic_size values
        for topic_size in self.min_topic_size:
            ncol = ncol + 1
            nrow = -1
            for topic in self.topics_range:
                nrow = nrow + 1
                # get the coherence score for the given parameters
                bertopic_model = BERTopic(
                    nr_topics=topic,
                    min_topic_size=topic_size,
                    n_gram_range=bertopic_parameters["n_gram_range"],
                    umap_model=bertopic_parameters["umap_model"],
                    hdbscan_model=bertopic_parameters["hdbscan_model"],
                    vectorizer_model=bertopic_parameters["vectorizer_model"],
                    verbose=bertopic_parameters["verbose"],
                )
                topics, _ = bertopic_model.fit_transform(self.input_text.text.tolist(), embeddings=bertopic_parameters["embedding"])
                coherence_model = bertopic_compute_coherence_values(self.input_text.text.tolist(), topics, bertopic_model)

                if tsne_plot:

                    labels = topics

                    title_to_append = " min_topic_size = " + str(topic_size) + ", nr_topics = " + str(topic)

                    if ncols == 1 and nrows == 1:
                        tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes)
                        axes.set_axis_on()
                        title = axes.get_title() + title_to_append
                        axes.set_title(title)
                    elif nrows == 1:
                        tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes[ncol])
                        axes[ncol].set_axis_on()
                        title = axes[ncol].get_title() + title_to_append
                        axes[ncol].set_title(title)

                    elif ncols == 1:
                        tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes[nrow])
                        axes[nrow].set_axis_on()
                        title = axes[nrow].get_title() + title_to_append
                        axes[nrow].set_title(title)
                    else:
                        tsne_2d_visualization(feature_array=feature_array, feature_array_2d=True, labels=labels, ax=axes[nrow][ncol])
                        axes[nrow][ncol].set_axis_on()
                        title = axes[nrow][ncol].get_title() + title_to_append
                        axes[nrow][ncol].set_title(title)
                no_of_topics = len(bertopic_model.get_topics())
                model_results["n_topics"].append(no_of_topics)
                model_results["min_topic_size"].append(topic_size)
                model_results["Coherence"].append(round(coherence_model.get_coherence(), 3))

                pbar.update(1)
        pbar.close()

        model_results_df = pd.DataFrame(model_results)

        best_param_dict, graph = self.best_hyperparameter_graph(model_results_df, model="bert")
        return best_param_dict, graph, fig
