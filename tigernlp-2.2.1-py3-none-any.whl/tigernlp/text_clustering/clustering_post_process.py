"""This module contains functions for post processing of clustered data."""
import pandas as pd
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from ast import literal_eval
import numpy as np


def generate_wordcloud(
    data: pd.DataFrame, topic_column: str, topic, ao_pair_column=None, path=None
):
    """Generates wordcloud for action object text in a given cluster.

    Parameters
    ----------

    data : pd.DataFrame
        dataframe with cluster/topic index and action object pair column
    topic_column : str
        name of the column with cluster/topic index
    topic : int or str
        topic/cluster for wordcloud
    ao_pair_column: str
    name of the column containing list of action object pair dictionary with `pairs_lemma` as one of the key

    """

    if not ao_pair_column:
        ao_pair_column = "action_object_pairs"

    data[topic_column] = data[topic_column].astype(str)
    data = data[data[topic_column] == str(topic)]

    all_pairs = []

    for i in data.index:
        pairs = []

        if isinstance(data[ao_pair_column][i], str):
            ao_list = eval(data[ao_pair_column][i])

        if isinstance(data[ao_pair_column][i], list):
            ao_list = data[ao_pair_column][i]

        for conv_dic in ao_list:
            pair = list(conv_dic["pairs_lemma"])
            pairs.extend(pair)

        all_pairs.extend(pairs)

    all_pairs = [text.replace(" ", "_") for text in all_pairs]

    text = " ".join(all_pairs)

    wordcloud = WordCloud(
        width=1600, height=800, background_color="white", min_font_size=20
    ).generate(str(text))

    plt.figure(figsize=(12, 8), facecolor=None)
    plt.imshow(wordcloud)
    plt.axis("off")

    if isinstance(topic, int):
        topic_title = "Wordcloud for topic :{}".format(topic)

    if isinstance(topic, str):
        topic_title = "Wordcloud for :{}".format(topic)

    plt.title(topic_title)

    if path:
        plt.savefig(path)
    plt.show()


def map_most_frequent_ao_pair(
    data: pd.DataFrame,
    ao_pair_column: str,
    topic_column: str,
    threshold=None,
) -> pd.DataFrame:
    """Assigns most frequently occuring action object pair in a cluster/topic to all the rows of that cluster.

    Parameters
    ----------

    data: pd.DataFrame
        dataframe having cluster index mapped.
    ao_pair_column: str
        action object pair column name.
    topic_column: str
        name of column having cluster/topic index.
    threshold: optional (float)
        :attr:`[0, 1]`
        thresholding value to map the most occuring action object pair in a cluster/topic,

        the most frequent action object pair is mapped, if the ratio of occurances of most frequent action object pair
        in a cluster to the size of cluster/topic is greater than the threshold value.

    Returns
    -------

    pd.DataFrame
        dataframe with most frequent action object pair mapping for each cluster/topic.

    """

    # count the number of occurrences of action object pairs in a topic using pivot table
    data["count"] = 1

    AO_table = pd.pivot_table(
        data,
        values=["count"],
        index=[ao_pair_column],
        columns=[topic_column],
        aggfunc="count",
        fill_value=0,
    )

    AO_table = AO_table["count"]

    # Generate a mapping of most occuring action object pair for each topic
    max_AO_mapping = pd.DataFrame(AO_table.idxmax())
    max_AO_mapping = max_AO_mapping.reset_index().rename(
        columns={0: "most_frequent_AO_pair"}
    )

    # Merge the most frequent action object pairs with the data using left join
    data = pd.merge(left=data, right=max_AO_mapping, on=topic_column, how="left")

    # Calculating the topic size
    topic_size = pd.DataFrame(data.groupby(topic_column).size()).reset_index()

    # Merge the topic size with data
    data = pd.merge(data, topic_size, how="left", on=topic_column).rename(
        columns={0: "topic_size"}
    )

    # Calculate the number of occurances of most frequent action object pair in a cluster
    most_frequent_AO_pair_count = (
        pd.DataFrame(
            pd.pivot_table(
                data,
                values=["count"],
                index=["most_frequent_AO_pair"],
                columns=[ao_pair_column],
                aggfunc="count",
                fill_value=0,
            )["count"].max(axis=1)
        )
        .reset_index()
        .rename(columns={0: "count_of_max_AOP"})
    )

    # Merge occurances of most frequent action object pair with data
    data = pd.merge(
        data, most_frequent_AO_pair_count, how="left", on="most_frequent_AO_pair"
    )

    # Calculate the ratio of occurances of most frequent action object pair to topic size
    data["max_AOP_topic_size_ratio"] = data["count_of_max_AOP"] / data["topic_size"]

    # Map most frequent action object pair based on threshold value
    if threshold:
        data["most_frequent_AO_pair"] = np.where(
            data["max_AOP_topic_size_ratio"] >= threshold,
            data["most_frequent_AO_pair"],
            "",
        )

    # Drop the unnecessory columns
    drop_cols = ["count", "topic_size", "count_of_max_AOP"]
    data.drop(columns=drop_cols, inplace=True)

    return data


def map_cluster_results(
    data: pd.DataFrame,
    topic_mapping_df: pd.DataFrame,
    topic_words_df: pd.DataFrame,
) -> pd.DataFrame:
    """Map the cluster/topic number, topic words and topic_label to the corresponding text.

    Parameters
    ----------

    data : pd.DataFrame
        dataframe to map the cluster/topic number, topic words and topic_label.
        `processed_action_object_pairs` column should be present in the dataframe.
    topic_mapping_df: pd.DataFrame
        dataframe with topic mapping for action object pairs having `["text", "topic", "topic_number"]` columns.
        (one of the output from BERTopic clustering.)
    topic_words_df: pd.DataFrame
        dataframe with topic words and topic label mapping for action object pairs`["text", "topic", "topic_number"]` columns.
        (one of the output from BERTopic clustering.)

    Returns
    -------

    pd.DataFrame
        dataframe with cluster/topic index, words, and label mapped.
    """

    # list of unique action object pairs
    unique_AO = topic_mapping_df.text.unique()

    for i in unique_AO:

        temp = topic_mapping_df[topic_mapping_df["text"] == i]

        # count the number of occurances of a action object pair in different clusters/topics
        freq_topic_number = pd.DataFrame(temp.topic_number.value_counts())
        freq_topic_number["counts"] = freq_topic_number["topic_number"]
        freq_topic_number["topic_number"] = freq_topic_number.index

        # select the topic number in which a action object pair is occuring mostly
        max_topic_number = freq_topic_number["topic_number"].to_list()[0]

        if (max_topic_number == -1) & (
            len(freq_topic_number["topic_number"].to_list()) > 1
        ):
            max_topic_number = freq_topic_number["topic_number"].to_list()[1]

        max_topic_title = "Topic {}".format(max_topic_number)

        # re-assign the cluster/topic number and title having most frequent action object pair
        topic_mapping_df["topic_number"] = np.where(
            topic_mapping_df["text"] == i,
            max_topic_number,
            topic_mapping_df["topic_number"],
        )
        topic_mapping_df["topic"] = np.where(
            topic_mapping_df["text"] == i,
            max_topic_title,
            topic_mapping_df["topic"],
        )

        topic_words_df["topic_number"] = np.where(
            topic_words_df["text"] == i,
            max_topic_number,
            topic_words_df["topic_number"],
        )
        topic_words_df["topic"] = np.where(
            topic_words_df["text"] == i, max_topic_title, topic_words_df["topic"]
        )

    # drop the duplicate rows (now one action object pair is mapped to only one cluster)
    topic_mapping_df = topic_mapping_df.drop_duplicates("text")
    topic_words_df = topic_words_df.drop_duplicates("text")

    topic_mapping_df["topic_number"] = topic_mapping_df["topic_number"].astype(str)
    topic_words_df["topic_number"] = topic_words_df["topic_number"].astype(str)
    # reset the topic label
    topic_words_df["topic_words"] = (
        topic_words_df["topic_words"].astype(str).apply(literal_eval)
    )
    topic_words_df["topic_label"] = (
        topic_words_df["topic_number"].astype(str)
        + "_"
        + topic_words_df["topic_words"].apply(lambda x: x[0] + "_" + x[1])
    )

    # assign the topic words and topic labels
    mapped_topics = pd.merge(
        left=topic_mapping_df,
        right=topic_words_df,
        on=["text", "topic", "topic_number"],
        how="inner",
    )

    # map the clusters/topics to data
    data = pd.merge(
        left=data,
        right=mapped_topics,
        left_on="processed_action_object_pairs",
        right_on="text",
        how="left",
    )

    data = data.drop(columns=["text_y"])
    data = data.rename(columns={"text_x": "text"})

    return data
