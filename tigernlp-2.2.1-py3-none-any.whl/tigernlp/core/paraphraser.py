from tqdm import tqdm
from typing import Optional

from tigernlp.core.parrot.parrot import Parrot
from tigernlp.core.utils import MyLogger


class Paraphraser:
    """Praphraser class can be used to rephrase a sentence

    Parameters
    ----------
    paraphraser_model : union[str, paraphraser model]
        A parameter that specifies the name or path of hugging face parpaphraser or the model instance its self used for paraphrasing. This is used to generate variations of questions if the explode parameter is set to True. Options for path: "prithivida/parrot_paraphraser_on_T5" (default), "ramsrigouthamg/t5_sentence_paraphraser"
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Returns
    -------
    exp_phrases : list
        list of paraphraser sentences of input text.

    Example
    -------
    >>> from tigernlp.core.api import Paraphraser
    >>> para_object = Paraphraser()
    >>> para_object.paraphrase(
    >>>                text=["What is the name of the series of novels written by J.K. Rowling?"]
    >>>                )
    >>> # output
    >>> ['tell me the name of the jk rowling novels?',
    >>>  'which is the name of the jk rowling - series of novels?',
    >>>  "what's the name of a series of novels by jk rowling?",
    >>>  'what is the name of the novel series written by jk rowling?',
    >>>  'which is the name of the series of novels by jk rowling?',
    >>>  'what is the name of the series of novels written by jk rowling?',
    >>>  'What is the name of the series of novels written by J.K. Rowling?']
    >>>
    >>> para_object.paraphrase(text=[["I want to add my kids to my insurance policy."],
    >>>                       ["What is Voldemort's goal?"]])
    >>> # output
    >>> [['i want my kids covered under my insurance',
    >>>  'i want my children to be included on my insurance policy',
    >>>  'i want my kids included in my insurance policy',
    >>>  'i want to add my children to my insurance policy',
    >>>  'i want to add my kids to my insurance policy',
    >>>  'I want to add my kids to my insurance policy.'],
    >>>  ['tell me the mission of voldemort?',
    >>>  "what's voldemort's goal?",
    >>>  "what is voldemort's goal?",
    >>>  "What is Voldemort's goal?"]]

    """

    def __init__(
        self,
        paraphraser_model="prithivida/parrot_paraphraser_on_T5",
        log_level="INFO",
        log_file_path=None,
        verbose: Optional[bool] = False,
    ):
        """Paraphraser class initialization

        Parameters
        ----------
        paraphraser_model : union[str, paraphraser model]
            A parameter that specifies the name or path of hugging face parpaphraser or the model instance its self used for paraphrasing. This is used to generate variations of questions if the explode parameter is set to True. Options for path: "prithivida/parrot_paraphraser_on_T5" (default), "ramsrigouthamg/t5_sentence_paraphraser"
        log_level : str, optional
            Level or severity of the events needed to be tracked, by default "INFO"
        log_file_path: str, optional
            File path to save the logs, by default None
        verbose: bool,
            If `True` logs will be printed to console, by default True

        Raises
        ------
        Exception
            raises an error if the given model name could not be loaded

        """

        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger
        if isinstance(paraphraser_model, str):
            try:
                self.logger.info("Loading given model")
                self.parrot = Parrot(model_tag=paraphraser_model)
            except Exception as e:
                self.logger.error(
                    f'"{paraphraser_model}" is not a valid path. Make sure the right path to paraphraser is provided.{e}'
                )
                raise OSError("Enable to load model", paraphraser_model, ":", e)

        else:
            self.logger.info("Using given model object")

    def paraphrase(
        self,
        text: str,
        diversity_ranker: str = "levenshtein",
        do_diverse: bool = False,
        max_return_phrases: int = 10,
        max_length: int = 32,
        adequacy_threshold: float = 0.80,
        fluency_threshold: float = 0.80,
        use_gpu: bool = False,
    ):
        """Paraphrase method of class Paraphraser used to generate different phrases of given input string based on the other parameters.


        Parameters
        ----------
        text : str / List[str,str] / List[List[str,str],List[str,str]]
            Input string that needs to be paraphrased, It could be string, list of strings or list of list of strings
        diversity_ranker : str
            The parameter specifies the method to use for ranking the diversity of generated questions. Options - "levenshtein" (default), "euclidean", "diff"
        do_diverse : bool
            True if Lexical / Phrasal / Syntactical changes are allowed while paraphrasing. default False
        max_return_phrases : int
            maximum number of paraphrased sentences to return. default 10
        max_length : int
            maximum length of each paraphrased sentece. default 32
        adequacy_threshold : float
            float number ranging from 0 - 1 , 1 being the meaning or sentenct is preserved adequately. default 0.99
        fluency_threshold : float
            float number ranging from 0 - 1 , 1 being the paraphrase is fluent English default 0.90
        use_gpu : bool
            True if one wants to use gpu. default False

        Returns
        -------
        exp_phrases : list
            list of paraphraser sentences of input text

        Raises
        ------
        TypeError
            raises type error when input is not in required type
        Exception
            raises exception if any error occur during excecution

        Example
        -------
        >>> from tigernlp.core.api import Paraphraser
        >>> para_object = Paraphraser()
        >>> para_object.paraphrase(
        >>>                text=["What is the name of the series of novels written by J.K. Rowling?"]
        >>>                )
        >>> # output
        >>> ['tell me the name of the jk rowling novels?',
        >>>  'which is the name of the jk rowling - series of novels?',
        >>>  "what's the name of a series of novels by jk rowling?",
        >>>  'what is the name of the novel series written by jk rowling?',
        >>>  'which is the name of the series of novels by jk rowling?',
        >>>  'what is the name of the series of novels written by jk rowling?',
        >>>  'What is the name of the series of novels written by J.K. Rowling?']
        >>>
        >>> para_object.paraphrase(text=[["I want to add my kids to my insurance policy."],
        >>>                       ["What is Voldemort's goal?"]])
        >>> # output
        >>> [['i want my kids covered under my insurance',
        >>>  'i want my children to be included on my insurance policy',
        >>>  'i want my kids included in my insurance policy',
        >>>  'i want to add my children to my insurance policy',
        >>>  'i want to add my kids to my insurance policy',
        >>>  'I want to add my kids to my insurance policy.'],
        >>>  ['tell me the mission of voldemort?',
        >>>  "what's voldemort's goal?",
        >>>  "what is voldemort's goal?",
        >>>  "What is Voldemort's goal?"]]

        """
        try:
            if isinstance(text, str):
                text = [text]
            if isinstance(text, list):
                exp_phrases = []
                for phrase in tqdm(text):
                    if isinstance(phrase, str):
                        que = self.parrot.augment(
                            input_phrase=phrase,
                            use_gpu=use_gpu,
                            diversity_ranker=diversity_ranker,
                            do_diverse=do_diverse,
                            max_return_phrases=max_return_phrases,
                            max_length=max_length,
                            adequacy_threshold=adequacy_threshold,
                            fluency_threshold=fluency_threshold,
                        )
                        if isinstance(que, list):
                            for q in que:
                                if isinstance(q, tuple):
                                    exp_phrases.append(q[0])
                        exp_phrases.append(phrase)
                    elif isinstance(phrase, list):
                        for p in phrase:
                            exp_phrases_p = []
                            que = self.parrot.augment(
                                input_phrase=p,
                                use_gpu=use_gpu,
                                diversity_ranker=diversity_ranker,
                                do_diverse=do_diverse,
                                max_return_phrases=max_return_phrases,
                                max_length=max_length,
                                adequacy_threshold=adequacy_threshold,
                                fluency_threshold=fluency_threshold,
                            )
                            if isinstance(que, list):
                                for q in que:
                                    if isinstance(q, tuple):
                                        exp_phrases_p.append(q[0])
                        exp_phrases.append(exp_phrases_p + [p])

            else:
                self.logger.error(
                    f"Expected list or str {type(text)} was passed. Please provide text in correct input format."
                )
                raise TypeError(
                    f"Expected list or str {type(text)} was passed. Please provide text in correct input format."
                )
            return exp_phrases
        except Exception as e:
            self.logger.error(f"Error occurred during paraphrasing.\n {e}")
            raise Exception(f"Error occurred during paraphrasing.\n {e}")
