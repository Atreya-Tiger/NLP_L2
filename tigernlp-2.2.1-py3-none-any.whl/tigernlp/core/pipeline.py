import inspect
import operator
import traceback
from collections import OrderedDict
from typing import List, Optional, Tuple, Union

from .utils import MyLogger


class Pipeline:
    """
    Given a list of method names as strings, run all the methods in the order specified.

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path : _type_, optional
        File path to save the logs, by default None
    verbose : bool, optional
        If True logs will be printed to console, by default True

    Examples
    --------
    >>> from tigernlp.text_processing.api import TextProcessor
    >>> import pandas as pd

    >>> pipeline = Pipeline()
    >>> # Load the data
    >>> df = pd.read_csv('data.csv')
    >>> textProcessor = TextProcessor(df=df)

    >>> # Option 1: Pass as list of tuples
    >>> pipeline.pipeline(
            class_module=textProcessor,
            methods=[
                (
                    "extract_mentions",
                    {
                        "col_in": "text",
                        "col_out": "processed_text",
                        "mention_handler": "remove",
                    },
                ),
                (
                    "to_lower",
                    {
                        "col_in": "processed_text",
                        "col_out": "processed_text",
                    }
                ),
                (
                    "remove_punctuations",
                    {
                        "col_in": "processed_text",
                        "col_out": "processed_text",
                    }
                )
            ],
            skip_errors=False,
        )

    >>> # Option 2: Pass common parameters as kwargs,
    >>> # Pass tuple only to override kwargs
    >>> # This returns same output as above
    >>> pipeline.pipeline(
            class_module=textProcessor,
            methods=[
                (
                    "extract_mentions",
                    {
                        "col_in": "text",
                    },
                ),
                "to_lower",
                "remove_punctuations",
            ],
            skip_errors=False,
            col_in="processed_text",
            col_out="processed_text",
            mention_handler="remove",
        )

    >>> # Option 3: Given a certain data, pass it through the pipeline
    >>> # and run on all the methods mentioned,
    >>> # auto pass result of previous method onto the next
    >>> input_data = [('text', "@moon is Shining very brightly in the sky, don't you think?!!")]
    >>> output_data = pipeline.pipeline(
            class_module=textProcessor,
            methods=["extract_mentions", "to_lower", "remove_punctuations"],
            data_parameters=input_data,
            skip_errors=False,
            mention_handler='remove'
        )
    >>> output_data
        [('text', 'is shining very brightly in the sky don t you think')]
    >>> If 'text' should not be auto passed to all methods, specify "_input_index=None"
    >>> This means no value from "input_data" is passed to the functions specified.
    >>> Also "_input_index=[1, 2]" would mean only pass data from 1st and 2nd index into function and ignore the rest.

    >>> # Option 4: When working with multiple data parameters,
    >>> # If a length of result of certain method is not same as length of data parameters
    >>> # pass a parameter "_return_index" to specify which data parameter is to be updated
    >>> input_data = [
            ("text", "@moon is Shining very brightly in the sky, don't you think?!!"),
            ("tokens", []),
        ]
    >>> output_data = pipeline.pipeline(
            class_module=textProcessor,
            methods=[
                "extract_mentions",
                "to_lower",
                "remove_punctuations",
                ("get_tokens", {"_return_index": 1}),
            ],
            data_parameters=input_data,
            _return_index=0,
            skip_errors=False,
            mention_handler="remove",
        )
    >>> output_data
        [('text', 'is shining very brightly in the sky don t you think'),
            ('tokens', ['is', 'shining', 'very', 'brightly', 'in', 'the', 'sky', 'don', 't', 'you', 'think'])]
    >>> # In the above example "_return_index" in kwargs says to use it universally
    >>> # _return_index=0 in kwargs would mean for a certain result from any method,
    >>> # the first item in the result should be set to zeroth index in "input_data" which is "text" and ignore "tokens" as its not specified.
    >>> # Inside "get_tokens" we have "_return_index":1 which overrides the "_return_index" from kwargs
    >>> # So for "get_tokens" method alone,
    >>> # the first value of the result is to be set to first index of "input_data" which is "tokens"
    >>> # and ignore updating "text" because its not specified
    """

    def __init__(
        self,
        log_level: str = "INFO",
        log_file_path=None,
        verbose=True,
    ):
        """
        Parameters
        ----------
        log_level : str, optional
            Level or severity of the events needed to be tracked, by default "INFO"
        log_file_path : _type_, optional
            File path to save the logs, by default None
        verbose : bool, optional
            If True logs will be printed to console, by default True
        """

        # Create logger object
        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

    def _list_all_methods(self, class_module, skip_internal_funcs: bool = True) -> List[str]:
        """
        List all available methods in a class module. Dunder methods are skipped.

        Parameters
        ----------
        class_module : Any
            Class whose methods are to be listed

        skip_internal_funcs : bool, optional
            Internal method defined by "_func" are to be skipped, by default True

        Returns
        -------
        List[str]
            List of methods in the class module
        """

        all_methods = [
            func
            for func in dir(class_module)
            if callable(getattr(class_module, func))
            if not func.startswith("__")
        ]
        if skip_internal_funcs:
            return [func for func in all_methods if not func.startswith("_")]
        return all_methods

    def _is_sublist(self, sub_list, main_list):
        return set(sub_list) <= set(main_list)

    def _validate_methods(
        self, class_module, methods: List[Tuple[str, dict]], skip_errors=False
    ) -> List[Tuple[str, dict]]:
        """
        Validate if given method names are correct.
        Depending on skip_errors parameter, will either raise an error or will proceed with correct methods list.

        Parameters
        ----------
        class_module : Any
            Class whose methods are to be validated to

        methods : List[Tuple[str, dict]]
            List of tuples where first element in tuple is method name and second element is its function parameters as a dictionary

        skip_errors : bool, optional
            If a certain method name doesn't exist, raise an error or remove it from list, by default False

        Returns
        -------
        List[Tuple[str, dict]]
            List of all correct methods after removing methods that do not exist

        Raises
        ------
        ValueError
            If skip_errors is False and a certain method name is incorrect, ValueError is raised
        """

        all_methods = self._list_all_methods(class_module, skip_internal_funcs=True)

        if skip_errors:
            error_methods = [
                f'"{method[0]}"' for method in methods if method[0] not in all_methods
            ]
            if error_methods:
                self.logger.warning(
                    f"{', '.join(error_methods).strip()} not found in {class_module.__class__.__name__}"
                )
            return [method for method in methods if method[0] in all_methods]

        if not self._is_sublist([method[0] for method in methods], all_methods):
            error_methods = [
                f'"{method[0]}"' for method in methods if method[0] not in all_methods
            ]
            self.logger.error(
                f"{', '.join(error_methods).strip()} not found in {class_module.__class__.__name__}"
            )
            raise ValueError(
                f"{', '.join(error_methods).strip()} not found in {class_module.__class__.__name__}"
            )

        return methods

    def _get_params(self, method) -> dict:
        """
        Returns a dictionary of all parameters for the method along with their default values.

        Parameters
        ----------
        method : method or function
            Method whose parameters need to be returned

        Returns
        -------
        dict
            Returns dictionary with key as parameter name and value as its default value

        Raises
        ------
        ValueError
            If method parameter is not a method or function
        """

        if inspect.isfunction(method) or inspect.ismethod(method):
            signature = inspect.signature(method)
            return {param: value.default for param, value in signature.parameters.items()}

        self.logger.error(f'Expected a method or function. Received "{type(method).__name__}".')
        raise ValueError(f'Expected a method or function. Received "{type(method).__name__}".')

    def _validate_list_types(
        self, list_items: List[str], item_type: type
    ) -> Tuple[bool, List[str]]:
        """
        Checks if all items in a list are of the given type

        Parameters
        ----------
        list : List[str]
            List of items to check type for

        item_type : type
            Item type expected in a list. Needs to be type instance like str, list etc.

        Returns
        -------
        bool
            Returns True if all items the list are of item_type, else False

        List[str]
            Returns a list of all unique types availble in the list

        Raises
        ------
        ValueError
            If item_type is not type instance
        """

        if not isinstance(item_type, type):
            self.logger.error(
                f'Item type expected to be a type instance. Received "{type(item_type)}"'
            )
            raise ValueError(
                f'Item type expected to be a type instance. Received "{type(item_type)}"'
            )

        return all(isinstance(item, item_type) for item in list_items), list(
            {type(item).__name__ for item in list_items}
        )

    def _verify_input_return_param_in_syntax(
        self,
        methods: list,
        param_return_index: bool = True,
        data_parameters: dict = None,
        **kwargs,
    ):
        """
        Verify if "_return_index" or "_input_index" parameters are present in either methods or kwargs.
        Additionally, verify if all values provided are either integers or None.

        Parameters
        ----------
        methods : list
            List of tuples containing method name and dict of method parameters
        param_return_index : bool, optional
            Verify for "_input_index if False, else "_return_index", by default True
        data_parameters : dict, optional
            Any data variable which needs to be passed to all methods specified, by default None

        Raises
        ------
        ValueError
            If "_input_index" or "_return_index" are not specified in methods or kwargs
        ValueError
            Values inside "_input_index" or "_return_index" are not integers or None
        ValueError
            Max index of "_input_index" or "_return_index" is greater than length of data parameters - 1
        """
        param = "_return_index" if param_return_index else "_input_index"
        for method in methods:
            if param in method[1]:
                # If param is specified in methods
                # Save it to a variable first
                indices = method[1][param]
            elif param in kwargs:
                # If param is specified in kwargs
                # Save it to a variable first
                indices = kwargs[param]
            else:
                indices = [None] if param_return_index else list(range(len(data_parameters)))

                # self.logger.error(
                #     f'"{param}" parameter not found. Pass it as part of a tuple or kwargs to {"update data parameters" if param_return_index else "pass data parameters as input"}.'
                # )
                # raise ValueError(
                #     f'"{param}" parameter not found. Pass it as part of a tuple or kwargs to {"update data parameters" if param_return_index else "pass data parameters as input"}.'
                # )

            # Convert return indices to a list as it preserves order
            if isinstance(indices, tuple):
                indices = list(indices)
            elif not isinstance(indices, list):
                indices = [indices]

            indices_no_none = [index for index in indices if index is not None]

            if indices_no_none:
                ret, types = self._validate_list_types(indices_no_none, int)
                if not ret:
                    # If its not an integer
                    types = [f'"{item}"' for item in types]
                    # Raise a ValueError
                    self.logger.error(
                        f'Index values inside "{param}" must be integers or None. Received {", ".join(types).strip()} in {method[0] if param in method[1] else "kwargs"}'
                    )
                    raise ValueError(
                        f'Index values inside "{param}" must be integers or None. Received {", ".join(types).strip()} in {method[0] if param in method[1] else "kwargs"}'
                    )

            if indices_no_none and max(indices_no_none) > len(data_parameters) - 1:
                self.logger.error(
                    f'Max index of "{param}" is {max(indices)} whereas highest index of data_parameters is {len(data_parameters)-1} which are not equal for "{method[0]}"'
                )
                raise ValueError(
                    f'Max index of "{param}" is {max(indices)} whereas highest index of data_parameters is {len(data_parameters)-1} which are not equal for "{method[0]}"'
                )

    def _select_data_parameters(
        self, data_parameters: OrderedDict, method_parameters: dict, kwargs: dict
    ) -> OrderedDict:
        """
        Given data parameters, filter selected parameters based on _input_index value.
        If _input_index is None, then no data parameters are selected.

        Parameters
        ----------
        data_parameters : dict
            Any data variable which needs to be passed to all methods specified
        method_parameters : dict
            Function parameters present in a method
        kwargs : dict
            Key word arguments passed to pipeline

        Returns
        -------
        OrderedDict
            Return ordered dictionary selected based on indices in _input_index,
            or return empty ordered dictionary if _input_index is None
        """
        if not data_parameters:
            return data_parameters

        if "_input_index" in method_parameters:
            input_indices = method_parameters["_input_index"]
        elif "_input_index" in kwargs:
            input_indices = kwargs["_input_index"]
        else:
            # If _input_index is not specified, then by default select all data parameters
            input_indices = list(range(len(data_parameters)))

        # Convert return indices to a list as it preserves order
        if isinstance(input_indices, tuple):
            input_indices = list(input_indices)
        elif not isinstance(input_indices, list):
            input_indices = [input_indices]

        input_indices_no_none = [
            input_index for input_index in input_indices if input_index is not None
        ]

        # Operator throws an error if input_indices_no_none is only 1
        # So manually return respective data parameter if only 1 index is present

        if len(input_indices_no_none) == 1:
            return OrderedDict([list(data_parameters.items())[input_indices_no_none[0]]])

        return (
            OrderedDict(operator.itemgetter(*input_indices_no_none)(list(data_parameters.items())))
            if input_indices_no_none
            else OrderedDict()
        )

    def _validate_data_parameters(self, data_parameters: OrderedDict, methods: list, kwargs: dict):
        """
        Validate data parameters such that they are not repeated as part of methods tuple or kwargs.

        Parameters
        ----------
        data_parameters : OrderedDict
            Any data variable which needs to be passed to all methods specified
        methods : list
            List of tuples containing method name and dict of method parameters
        kwargs : dict
            Key word arguments passed to pipeline

        Raises
        ------
        ValueError
            If any data parameters are repeating in any method or kwargs
        """
        if not data_parameters:
            return
        method_parameters_conflict = {}
        kwargs_conflict_params = []
        for parameter in data_parameters.keys():
            for method in methods:
                if parameter in method[1]:
                    if parameter not in method_parameters_conflict:
                        method_parameters_conflict[parameter] = []
                    method_parameters_conflict[parameter].append(f'"{method[0]}"')
            if parameter in kwargs:
                kwargs_conflict_params.append(f'"{parameter}"')

        if method_parameters_conflict or kwargs_conflict_params:
            error_msg = ""
            for parameter in method_parameters_conflict:
                error_msg += (
                    f'Parameter "{parameter}" is already specified in "data_parameters". '
                    f'But it is also passed as input parameter to methods {", ".join(method_parameters_conflict[parameter]).strip()} which is causing a conflict. '
                    f'Remove "{parameter}"" from the specified functions.\n'
                )

            if kwargs_conflict_params:
                error_msg += (
                    f'Parameters {", ".join(kwargs_conflict_params).strip()} are already specified in data_parameters. '
                    "But they are also passed as kwargs which is a conflict. Remove specified parameters from kwargs."
                )

            error_msg = error_msg.strip()
            self.logger.error(error_msg)
            raise ValueError(error_msg)

    def pipeline(
        self,
        class_module,
        methods: List[Union[Tuple[str, dict], str]],
        data_parameters: List[Union[list, tuple]] = None,
        skip_errors: bool = False,
        **kwargs,
    ) -> Optional[List[Union[list, tuple]]]:
        """
        Given a class list of methods, run those methods in order specified

        Parameters
        ----------
        class_module : class
            Class whose methods should be run in order

        methods : List[Union[Tuple[str, dict], str]]
            List of tuples where first element in tuple is method name and second element is its function parameters as a dictionary.
            List of method names alone can be passed as well given that required function parameters are specified as kwargs
            All methods will run in the order specified.

        data_parameters : List[Union[list, tuple]], optional
            Any data variable which needs to be passed to all methods specified above and optionally updated after each method can be passed here.
            In order to specify which index of result from method to be used to set data parameters internally after each run,
            use '_return_index' parameter as shown in examples below.

        skip_errors : bool, optional
            If errors are to be skipped, if True will skip functions having errors and proceed.
            Will raise error if False in case function is not present or any errors during execution,
            by default False

        Returns
        -------
        List[Union[list, tuple]]: Optional
            If `data_parameters` are passed, the resultant updated values after running pipeline will be returned


        Raises
        ------
        ValueError
            class_module is not initialized
        ValueError
            methods parameter is not a list
        ValueError
            data_parameters is not a dictionary or None
        ValueError
            skip_errors parameter is not boolean
        ValueError
            method names ie first element of tuple passed inside methods are not string
        ValueError
            function parameters, second element of tuple passed inside methods are not dictionary
        ValueError
            if a certain required parameter is not passed as function_parameters
        ValueError
            length of _return_index and data parameters are not same
        ValueError
            indices passed to _return_index are not integer
        ValueError
            index inside _return_index is more than highest index of result of a method
        ValueError
            if an error occured when running a method

        Examples
        --------
        >>> from tigernlp.text_processing.api import TextProcessor
        >>> import pandas as pd
        >>> pipeline = Pipeline()
        >>> df = pd.read_csv('data.csv')
        >>> textProcessor = TextProcessor(df=df)

        >>> # Option 1: Pass as list of tuples
        >>> pipeline.pipeline(
                class_module=textProcessor,
                methods=[
                    (
                        "extract_mentions",
                        {
                            "col_in": "text",
                            "col_out": "processed_text",
                            "mention_handler": "remove",
                        },
                    ),
                    (
                        "to_lower",
                        {
                            "col_in": "processed_text",
                            "col_out": "processed_text",
                        }
                    ),
                    (
                        "remove_punctuations",
                        {
                            "col_in": "processed_text",
                            "col_out": "processed_text",
                        }
                    )
                ],
                skip_errors=False,
            )

        >>> # Option 2: Pass common parameters as kwargs,
        >>> # Pass tuple only to override kwargs
        >>> # This returns same output as above
        >>> pipeline.pipeline(
                class_module=textProcessor,
                methods=[
                    (
                        "extract_mentions",
                        {
                            "col_in": "text",
                        },
                    ),
                    "to_lower",
                    "remove_punctuations",
                ],
                skip_errors=False,
                col_in="processed_text",
                col_out="processed_text",
                mention_handler="remove",
            )

        >>> # Option 3: Given a certain data, pass it through the pipeline
        >>> # and run on all the methods mentioned,
        >>> # auto pass result of previous method onto the next
        >>> input_data = [('text', "@moon is Shining very brightly in the sky, don't you think?!!")]
        >>> output_data = pipeline.pipeline(
                class_module=textProcessor,
                methods=["extract_mentions", "to_lower", "remove_punctuations"],
                data_parameters=input_data,
                skip_errors=False,
                mention_handler='remove'
            )
        >>> output_data
            [('text', 'is shining very brightly in the sky don t you think')]
        >>> If 'text' should not be auto passed to all methods, specify "_input_index=None"
        >>> This means no value from "input_data" is passed to the functions specified.
        >>> Also "_input_index=[1, 2]" would mean only pass data from 1st and 2nd index into function and ignore the rest.

        >>> # Option 4: When working with multiple data parameters,
        >>> # If a length of result of certain method is not same as length of data parameters
        >>> # pass a parameter "_return_index" to specify which data parameter is to be updated
        >>> input_data = [
                ("text", "@moon is Shining very brightly in the sky, don't you think?!!"),
                ("tokens", []),
            ]
        >>> output_data = pipeline.pipeline(
                class_module=textProcessor,
                methods=[
                    "extract_mentions",
                    "to_lower",
                    "remove_punctuations",
                    ("get_tokens", {"_return_index": 1}),
                ],
                data_parameters=input_data,
                _return_index=0,
                skip_errors=False,
                mention_handler="remove",
            )
        >>> output_data
            [('text', 'is shining very brightly in the sky don t you think'),
             ('tokens', ['is', 'shining', 'very', 'brightly', 'in', 'the', 'sky', 'don', 't', 'you', 'think'])]
        >>> # In the above example "_return_index" in kwargs says to use it universally
        >>> # _return_index=0 in kwargs would mean for a certain result from any method,
        >>> # the first item in the result should be set to zeroth index in "input_data" which is "text" and ignore "tokens" as its not specified.
        >>> # Inside "get_tokens" we have "_return_index":1 which overrides the "_return_index" from kwargs
        >>> # So for "get_tokens" method alone,
        >>> # the first value of the result is to be set to first index of "input_data" which is "tokens"
        >>> # and ignore updating "text" because its not specified
        """

        # TODO: Add support to multiple class modules
        # TODO: Fix edge case of data_parameters is if return is expected to be a Tuple
        # TODO: Add parameter name mapper if some functions have data2 and usage is same
        # TODO: If a certain data parameter is not selected to be input to a certain function, can I allow passing it as tuple?

        # Class module needs to be initialized before passing to pipeline
        if callable(class_module):
            self.logger.error(f'"{class_module.__name__}" needs to be initialized first.')
            raise ValueError(f'"{class_module.__name__}" needs to be initialized first.')

        if not isinstance(methods, list):
            # Raise an error if methods is not a list
            self.logger.error(f'Parameter "methods" must be a list. Received "{type(methods)}"')
            raise ValueError(f'Parameter "methods" must be a list. Received "{type(methods)}"')

        # Check if data_parameters is a List
        if not data_parameters:
            # If its None, make it an empty dict
            data_parameters = []

        if not isinstance(data_parameters, list):
            self.logger.error(
                f'Parameter "data_parameters" must be a list or None. Received "{type(data_parameters)}"'
            )
            raise ValueError(
                f'Parameter "data_parameters" must be a list or None. Received "{type(data_parameters)}"'
            )

        if not isinstance(skip_errors, bool):
            self.logger.error(
                f'Parameter "skip_errors" is expected to be a boolean value. Received "{type(skip_errors)}".'
            )
            raise ValueError(
                f'Parameter "skip_errors" is expected to be a boolean value. Received "{type(skip_errors)}".'
            )

        # As of python 3.7 its not required to use OrderedDict but will raise issues for older python versions
        data_parameters = OrderedDict(data_parameters)

        # If single string is passed, convert it to a tuple and empty dictionary
        methods = [(method, {}) if isinstance(method, str) else method for method in methods]

        # Check if first item inside methods list is a string
        ret, types = self._validate_list_types([method[0] for method in methods], str)
        if not ret:
            # If its not a string
            types = [f'"{item}"' for item in types]
            # Raise a ValueError
            self.logger.error(
                f'Method names passed to "methods" parameter must be a string. Received {", ".join(types).strip()}'
            )
            raise ValueError(
                f'Method names passed to "methods" parameter must be a string. Received {", ".join(types).strip()}'
            )

        # Check if second item inside methods list is a dictionary
        ret, types = self._validate_list_types([method[1] for method in methods], dict)
        if not ret:
            # If its not a string
            types = [f'"{item}"' for item in types]
            # Raise a ValueError
            self.logger.error(
                f'Function parameters passed to "methods" parameter must be a dictionary. Received {", ".join(types).strip()}'
            )
            raise ValueError(
                f'Function parameters passed to "methods" parameter must be a dictionary. Received {", ".join(types).strip()}'
            )

        # Validate all methods to make sure it is present in class module
        methods = self._validate_methods(class_module, methods, skip_errors=skip_errors)

        # Validate data parameters such that they are not repeating in method tuples or kwargs
        self._validate_data_parameters(data_parameters, methods, kwargs)

        if data_parameters:
            # Verify if _input_index is present for all methods
            self._verify_input_return_param_in_syntax(
                methods, param_return_index=False, data_parameters=data_parameters, **kwargs
            )

            # Verify if _return_index is present for all methods
            self._verify_input_return_param_in_syntax(
                methods, param_return_index=True, data_parameters=data_parameters, **kwargs
            )

        # For each method in methods
        for method in methods:
            self.logger.info(f"Running {class_module.__class__.__name__}.{method[0]} method")
            # Get all parameters and its default values for the function
            # This dictionary will finally be unpacked into the function
            input_function_params = self._get_params(getattr(class_module, method[0]))
            for param, value in input_function_params.items():
                # error_params holds required parameters which are not passed as function_parameters
                error_params = []
                # If a certain paramter is passed as function_parameters
                if param in method[1]:
                    # Update input function parameters dict
                    input_function_params[param] = method[1][param]
                # If parameter is in selected data parameters based on _input_index
                elif param in self._select_data_parameters(data_parameters, method[1], kwargs):
                    input_function_params[param] = data_parameters[param]
                elif param in kwargs:
                    input_function_params[param] = kwargs[param]
                elif value is inspect.Parameter.empty:
                    # If value is a required parameter and not present in function parameters
                    # Append to error_params to show as warning or error message
                    error_params.append(param)
                # If any parameters raised an error
                if error_params:
                    # Change for formatting
                    error_params = [f'"{error_param}"' for error_param in error_params]
                    if skip_errors:
                        # If errors are to be skipped, show warning and move on
                        self.logger.warning(
                            f"{', '.join(error_params).strip()} are required parameters in {method} method."
                        )
                    else:
                        # If errors are not to be skipped, raise ValueError
                        self.logger.error(
                            f"{', '.join(error_params).strip()} are required parameters in {method} method."
                        )

                        raise ValueError(
                            f"{', '.join(error_params).strip()} are required parameters in {method} method."
                        )
            try:
                # Run method with specified parameters
                result = getattr(class_module, method[0])(**input_function_params)
                # TODO: If return is None don't update, or warn user?
                if data_parameters and result is not None:
                    # If data parameters are given it means next functions are expecting output of previous functions
                    if not isinstance(result, tuple):
                        result = [result]
                    # If more than one value is returned from function
                    if "_return_index" in method[1]:
                        # If return index is specified in methods
                        # Then update data_parameters according to indices from _return_index
                        # Save it to a variable first
                        return_indices = method[1]["_return_index"]
                    elif "_return_index" in kwargs:
                        # If return_index is specified in kwargs
                        # Then update data_parameters according to indices from _return_index
                        # Save it to a variable first
                        return_indices = kwargs["_return_index"]

                    elif len(result) == len(data_parameters) == 1:
                        # If there is only one return value and 1 data parameter, then auto update data parameter
                        return_indices = [0]

                    else:
                        # # If no "_return_index" is specified, then don't update anything
                        # return_indices = [None] * len(result)

                        # If no "_return_index" is specified, raise an error
                        self.logger.error(
                            '"_return_index" parameter not found. Pass it as part of a tuple or kwargs to update data parameters.'
                        )
                        raise ValueError(
                            '"_return_index" parameter not found. Pass it as part of a tuple or kwargs to update data parameters.'
                        )

                    # Convert return indices to a list as it preserves order
                    if isinstance(return_indices, tuple):
                        return_indices = list(return_indices)
                    elif not isinstance(return_indices, list):
                        return_indices = [return_indices]
                    return_indices_no_none = [
                        return_index for return_index in return_indices if return_index is not None
                    ]
                    if (
                        return_indices_no_none
                        and max(return_indices_no_none) > len(data_parameters) - 1
                    ):
                        self.logger.error(
                            f'Max index of "_return_index" is {max(return_indices)} whereas highest index of data_parameters is {len(data_parameters)-1} which are not equal for "{method[0]}"'
                        )
                        raise ValueError(
                            f'Max index of "_return_index" is {max(return_indices)} whereas highest index of data_parameters is {len(data_parameters)-1} which are not equal for "{method[0]}"'
                        )
                    if len(return_indices) > len(result):
                        self.logger.error(
                            f'Length of "_return_index" is {len(return_indices)} whereas length of result of "{method[0]}" is {len(result)} which is excess.'
                        )
                        raise ValueError(
                            f'Length of "_return_index" is {len(return_indices)} whereas length of result of "{method[0]}" is {len(result)} which is excess.'
                        )

                    # For each return index and its location, update data parameters
                    for idx, result_index in enumerate(return_indices):
                        # Here idx is index in result tuple and result_index is index in data parameter
                        if result_index is not None:
                            # Only if result_index is not None, update data parameters
                            data_parameters[list(data_parameters.keys())[result_index]] = result[
                                idx
                            ]

            except Exception as e:
                self.logger.error(traceback.format_exc())
                if not skip_errors:
                    raise ValueError from e
            self.logger.info(f"{class_module.__class__.__name__}.{method[0]} method is completed.")

        if data_parameters:
            return list(data_parameters.items())
