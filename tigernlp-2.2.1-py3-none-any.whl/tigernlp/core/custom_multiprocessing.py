import pandas as pd
from collections import defaultdict
from joblib import Parallel, delayed, effective_n_jobs
from sklearn.utils import gen_even_slices


def parallelize_row_wise(
    df: pd.DataFrame, func, kwargs: dict = None, n_jobs: int = -1
) -> pd.DataFrame:
    """Applies ``func`` parallely to each row in ``df`` which gives a new dataframe for each row. This function merges the resulting dataframes to one final dataframe.

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe
    func : callable
        Function that needs to be applied to dataframe.
    kwargs : dict, optional
        key word arguments that need to be applied to the func, by default None
    n_jobs : int, optional
        number of concurrent workers, by default -1 i.e., use all available workers

    Returns
    -------
    pd.DataFrame
        Dataframe after applying ``func`` to input ``df``
    """
    with Parallel(n_jobs=effective_n_jobs(n_jobs), backend="loky", verbose=1) as p:
        if kwargs:
            row_wise_output = p(delayed(func)(df.iloc[[i]], **kwargs) for i in range(df.shape[0]))
        else:
            row_wise_output = p(delayed(func)(df.iloc[[i]]) for i in range(df.shape[0]))

    return pd.concat(row_wise_output)


def parallelize(df: pd.DataFrame, func, kwargs: dict = None, n_jobs: int = -1) -> pd.DataFrame:
    """This function does parallelization of df.apply. It involves breaking up ``df`` into ``n_jobs`` slices, applies ``func`` to each slice and concats these slices to return the final dataframe.

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe
    func : callable
        Function that needs to be applied to dataframe.
    kwargs : dict, optional
        key word arguments that need to be applied to the func, by default None
    n_jobs : int, optional
        number of concurrent workers, by default -1 i.e., use all available workers

    Returns
    -------
    pd.DataFrame
        Dataframe after applying ``func`` to input ``df``
    """
    if effective_n_jobs(n_jobs) == 1:  # Same as df.apply
        if kwargs:
            return df.apply(func, **kwargs)

        return df.apply(func)

    else:
        if kwargs:
            chunks = Parallel(n_jobs=effective_n_jobs(n_jobs), backend="loky", verbose=50)(
                delayed(type(df).apply)(df.iloc[custom_slices], func, **kwargs)
                for custom_slices in gen_even_slices(
                    n=df.shape[0], n_packs=effective_n_jobs(n_jobs)
                )
            )
            return pd.concat(chunks)
        else:
            chunks = Parallel(n_jobs=effective_n_jobs(n_jobs), backend="loky", verbose=50)(
                delayed(type(df).apply)(df.iloc[custom_slices], func)
                for custom_slices in gen_even_slices(
                    n=df.shape[0], n_packs=effective_n_jobs(n_jobs)
                )
            )
            return pd.concat(chunks)


def grpby_wrapper(grp_df: pd.DataFrame, func, groupby_cols: list, kwargs: dict) -> pd.DataFrame:
    """Helper function that is utilized by parallel_groupby function.

    Parameters
    ----------
    grp_df : pd.DataFrame
        Input dataframe that needs to be aggregated
    func : callable
        Function that needs to be applied to dataframe.
    groupby_cols : list
        List of columns that needs to be applied in groupby.
    kwargs : dict
        key word arguments that need to be applied to the func

    Returns
    -------
    pd.DataFrame
        Dataframe after applying ``func`` to input ``df``
    """
    if kwargs:
        result = grp_df.groupby(by=groupby_cols).apply(func, **kwargs).reset_index(drop=True)
    else:
        result = grp_df.groupby(by=groupby_cols).apply(func).reset_index(drop=True)
    return result


def parallelize_groupby(
    df: pd.DataFrame, groupby_cols: list, func, kwargs: dict = None, n_jobs: int = -1
) -> pd.DataFrame:
    """Applies ``func`` to each groups defined by ``groupby_cols`` in ``df``. It splits ``df`` into ``n_jobs`` slices, then does groupby.apply for each slice. Resulting dataframes from each slice is merged to final dataframe.

    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe
    groupby_cols : list
        List of columns that needs to be applied in groupby.
    func : callable
        Function that needs to be applied to dataframe.
    kwargs : dict, optional
        key word arguments that need to be applied to the func, by default None
    n_jobs : int, optional
        number of concurrent workers, by default -1 i.e., use all available workers

    Returns
    -------
    pd.DataFrame
        Dataframe after applying ``func`` to input ``df``
    """

    if effective_n_jobs(n_jobs) == 1:  # Same as df.apply
        if kwargs:
            return df.groupby(groupby_cols).apply(func, **kwargs)

        return df.groupby(groupby_cols).apply(func)

    else:
        df_grouped = df.groupby(by=groupby_cols)
        # Construct chunks of grouped objects
        all_grps = []
        for name, _ in df_grouped:
            all_grps.append(name)

        total_pandas_groups = []
        for custom_slices in gen_even_slices(n=df_grouped.ngroups, n_packs=effective_n_jobs(-1)):
            current_grp_list = [df_grouped.get_group(g) for g in all_grps[custom_slices]]
            current_grp = pd.concat(current_grp_list)
            total_pandas_groups.append(current_grp)

        with Parallel(n_jobs=effective_n_jobs(n_jobs), backend="loky", verbose=1) as p:
            if kwargs:
                chunks = p(
                    delayed(grpby_wrapper)(each_group, func, groupby_cols, kwargs)
                    for each_group in total_pandas_groups
                )
            else:
                chunks = p(
                    delayed(grpby_wrapper)(each_group, func, groupby_cols, kwargs)
                    for each_group in total_pandas_groups
                )

        return pd.concat(chunks)


def parallelize_dict_counter(
    series: pd.Series, func, kwargs: dict = None, n_jobs: int = -1
) -> dict:
    """Accepts a pandas series that will be converted to dictionary counter object. Splits pandas series into ``n_jobs`` slices where each slice is converted to a dict by applying ``func``. Resulting dictionaries are merged to form a final dictionary.

    Parameters
    ----------
    series : pd.Series
        Input Series
    func : callable
        Function that needs to be applied to series which returns a dictionary.
    kwargs : dict, optional
        key word arguments that need to be applied to the func, by default None
    n_jobs : int, optional
        number of concurrent workers, by default -1 i.e., use all available workers

    Returns
    -------
    dict
        Final counter returned as dict after merging several smaller counters.
    """
    if effective_n_jobs(n_jobs) == 1:  # Same as df.apply
        if kwargs:
            return func(series, **kwargs)

        return func(series)
    else:
        master_dict = defaultdict(int)

        with Parallel(n_jobs=effective_n_jobs(n_jobs), backend="loky", verbose=1) as p:
            if kwargs:
                slave_dicts = p(
                    delayed(func)(series.iloc[custom_slices], **kwargs)
                    for custom_slices in gen_even_slices(
                        n=len(series), n_packs=effective_n_jobs(n_jobs)
                    )
                )
            else:
                slave_dicts = p(
                    delayed(func)(series.iloc[custom_slices])
                    for custom_slices in gen_even_slices(
                        n=len(series), n_packs=effective_n_jobs(n_jobs)
                    )
                )

        for slave in slave_dicts:
            for k, v in slave.items():
                master_dict[k] = master_dict.get(k, 0) + v

        return master_dict
