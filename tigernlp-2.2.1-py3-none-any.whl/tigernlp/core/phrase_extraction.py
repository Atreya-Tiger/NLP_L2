import numpy as np
import os
import pandas as pd
import re
import spacy
import traceback
from joblib import Parallel, delayed, effective_n_jobs
from nltk import Tree, ne_chunk, pos_tag, word_tokenize
from typing import Union

from tigernlp.core.nlp_downloads import spacy_download_validate
from tigernlp.core.utils import MyLogger


# TODO : include dataframe option
class PhraseExtraction:
    """Phrase extraction module to extract noun chunks for the text documents.
    There are two methods user can select to generate noun phrases -

    *Option 1*: nltk
     - utilizes nltk ne_chunk to generate the noun phrase
    *Option 2*: spacy
     - utilizes spacy ner model doc.ents to generate the noun phrase


    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> from tigernlp.core.api import PhraseExtration
    >>> input_text = 'sentences from which we need to extract noun chunks'
    >>> phrase_extraction = PhraseExtration()
    >>> # Option 1
    >>> phrase_df = phrase_extraction.nltk_noun_chunks(input_text)
    >>> # Option 2
    >>> phrase_df = phrase_extraction.spacy_noun_chunks(input_text)

    """

    def __init__(self, log_level="WARNING", log_file_path=None, verbose=True):
        self.log_file_path = log_file_path
        self.log_level = log_level
        self.verbose = verbose
        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def _spacy_nchunks(self, text, remove_person_gpe):
        """Gets all the important word present for person and geo political entity in the text for spacy

        Parameters
        ----------
        text : str
            text document for extracting noun chunks, by default None
        remove_person_gpe : bool, optional
            If true removes person and geopolitical entities (gpe) from text, by default `False`

        Returns
        -------
        List
            Returns all the important word  for a given text/list of texts

        """

        doc = self.nlp_spacy(text)
        current_chunk = [str(i) for i in doc.noun_chunks]
        if remove_person_gpe:
            for ent in doc.ents:
                try:
                    if ent.label_.lower() in ["person", "gpe"]:
                        current_chunk = [
                            i for i in current_chunk if (ent.text.lower() not in i.lower()) and (i.lower() not in ent.text.lower())
                        ]
                except Exception:
                    pass
        current_chunk = [x.strip() for x in current_chunk if len(x.strip()) > 0]
        return current_chunk

    def _nltk_nchunks(self, text):
        """
        Gets all the important word present in the text for nltk
        Parameters
        ----------
        text : str
            text string for extracting noun chunks, by default None

        Returns
        -------
        List
            Returns all the important word  for a given text/list of texts

        """

        chunked = ne_chunk(pos_tag(word_tokenize(text)))
        current_chunk = []
        prvs = ""
        s = ""
        for subtree in chunked:
            if type(subtree) == Tree:
                current_chunk.append(s)
                s = ""
                if subtree._label.lower() == "gpe":
                    continue
                current_chunk.append(" ".join([token for token, pos in subtree.leaves()]))
            else:
                if isinstance(subtree, tuple):
                    if len(subtree) == 2:
                        if prvs in ["NN", "NNS", "NNP", "NNPS", "JJ"]:
                            if subtree[1] in ["NN", "NNS", "NNP", "NNPS"]:
                                s = s + " " + subtree[0]
                            elif subtree[1] == "JJ":
                                current_chunk.append(s)
                                s = ""
                                s = s + " " + subtree[0]
                            else:
                                current_chunk.append(s)
                                s = ""
                        else:
                            if subtree[1] in ["NN", "NNS", "NNP", "NNPS", "JJ"]:
                                s = s + " " + subtree[0]
                        prvs = subtree[1]
                        if subtree[0] == chunked[-1][0]:
                            current_chunk.append(s)
                            s = ""
                    else:
                        s = ""
        current_chunk = [x.strip() for x in current_chunk if len(x.strip()) > 0]
        return current_chunk

    def nltk_noun_chunks(self, text: Union[str, list] = None, parallel_processing=False, n_core=-1):
        """Get all possible noun chunks from the text using nltk

        Parameters
        ----------
        text : Union[str, list]
            text document for extracting noun chunks, by default None
            Example - 'sentences from which we need to extract noun chunks' or ['sentences from which we need to extract noun chunks', 'second sentence for noun extraction']
        parallel_processing: bool, optional
            Whether to use parallel processing, by default False.
        n_core: int, optional
            number of concurrent workers, by default -1 i.e., use all available workers


        Returns
        -------
        List
            list of all noun chunks for a given text/list of text document

        Examples
        --------
        >>> from tigernlp.core.api import PhraseExtration
        >>> input_text = ['sentences from which we need to extract noun chunks', 'second sentence for noun extraction']
        >>> phrase_extraction = PhraseExtration()
        >>> phrase_df = phrase_extraction.nltk_noun_chunks(text = input_text)
        """
        try:
            if text is None:
                self.logger.error(f"Bad input passed to text {text}")
                raise ValueError("Bad input text column")

            if not (isinstance(text, str) | isinstance(text, list)):
                raise ValueError(f"Input text is of incorrect type - {type(text)} in this method. Requires an input string or list")

            if isinstance(text, str):
                current_chunk = self._nltk_nchunks(text=text)

            def func(text_func):
                current_chunk = [self._nltk_nchunks(text=t) for t in text_func]
                return current_chunk

            if isinstance(text, list):

                if parallel_processing:
                    current_chunk = []
                    n_jobs = effective_n_jobs(n_core)
                    text_splits = np.array_split(text, n_jobs)
                    all_chunk = Parallel(n_jobs=n_jobs, verbose=50, backend="loky")(delayed(func)(t) for t in text_splits)
                    for chunk in all_chunk:
                        current_chunk = current_chunk + chunk
                else:
                    current_chunk = func(text)

            return current_chunk

        except Exception as e:
            self.logger.error(f"Error {e} occured while extracting noun phrases using nltk")

    def spacy_noun_chunks(
        self,
        text: Union[str, list] = None,
        remove_person_gpe=False,
        en_core_web_model="en_core_web_sm",
        parallel_processing=False,
        n_core=-1,
    ):
        """Get all possible noun chunks from text using spacy

        Parameters
        ----------
        text : Union[str, list]
            text document for extracting noun chunks, by default None
            Example - 'sentences from which we need to extract noun chunks' or ['sentences from which we need to extract noun chunks', 'second sentence for noun extraction']
        remove_person_gpe : bool, optional
            If true removes person and geopolitical entities (gpe) from text, by default `False`
        en_core_web_model: str,
            spacy model name or path to be used for generating phrases, by default `en_core_web_sm`
        parallel_processing: bool, optional
            Whether to use parallel processing, by default False.
        n_core: int, optional
            number of concurrent workers, by default -1 i.e., use all available workers


        Returns
        -------
        List
            list of all noun chunks for a given text/list of text document

        Examples
        --------
        >>> from tigernlp.core.api import PhraseExtration
        >>> input_text = ['sentences from which we need to extract noun chunks', 'second sentence for noun extraction']
        >>> phrase_extraction = PhraseExtration()
        >>> phrase_df = phrase_extraction.spacy_noun_chunks(input_text)
        """
        try:
            if text is None:
                self.logger.error(f"Bad input passed to text {text}")
                raise ValueError("Bad input passed in text column")

            if not (isinstance(text, str) | isinstance(text, list)):
                self.logger.error(
                    f"Input text is of incorrect type - {type(text)}. Can not proceed further, " "Requires an input string or list"
                )
                raise ValueError(f"Input text is of incorrect type - {type(text)} in this method. Requires an input string or list")

            try:
                if spacy_download_validate(en_core_web_model):
                    self.nlp_spacy = spacy.load(en_core_web_model)
                elif os.path.exists(en_core_web_model):
                    self.nlp_spacy = spacy.load(en_core_web_model)
                else:
                    raise ValueError(f"{en_core_web_model} is not a valid directory or model does not exist")

            except Exception:
                self.logger.error(traceback.format_exc())
                self.logger.info(
                    "Download the en_core_web_sm 3.3.0 model from https://github.com/explosion/spacy-models/releases/tag/en_core_web_sm-3.3.0."
                )
                self.logger.info(
                    " or Download the en_core_web_md-3.4.1 model from https://github.com/explosion/spacy-models/releases/tag/en_core_web_md-3.4.1"
                )
                self.logger.info(
                    " or Download the en_core_web_lg-3.4.1 model from https://github.com/explosion/spacy-models/releases/tag/en_core_web_lg-3.4.1"
                )
                self.logger.info("Make sure the right en_core_web_model path is passed to the module as follows")
                self.logger.info(
                    """>>> phrase_extraction.spacy_noun_chunks(text=text, en_core_web_model="en_core_web_sm-3.3.0/en_core_web_sm/en_core_web_sm-3.3.0")"""
                )

            if isinstance(text, str):
                current_chunk = self._spacy_nchunks(text=text, remove_person_gpe=remove_person_gpe)

            def func(text_func, remove_person_gpe):
                current_chunk = [self._spacy_nchunks(text=str(t), remove_person_gpe=remove_person_gpe) for t in text_func]
                return current_chunk

            if isinstance(text, list):
                if parallel_processing:
                    current_chunk = []
                    n_jobs = effective_n_jobs(n_core)
                    text_splits = np.array_split(text, n_jobs)
                    all_chunk = Parallel(n_jobs=n_jobs, verbose=50, backend="loky")(
                        delayed(func)(t, remove_person_gpe) for t in text_splits
                    )
                    for chunk in all_chunk:
                        current_chunk = current_chunk + chunk
                else:
                    current_chunk = func(text, remove_person_gpe=remove_person_gpe)

            return current_chunk
        except Exception as e:
            self.logger.error(f"Error {e} occured while extracting noun phrases using spacy")


class PhraseProcessing:
    def __init__(self, log_level="WARNING", log_file_path=None, verbose=True):
        self.log_file_path = log_file_path
        self.log_level = log_level
        self.verbose = verbose
        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    # TODO - add docstring, documentation
    # TODO - convert it in the Text Processing class, init can take df as in input, functions can take noun phrase list as an input
    # TODO - add functions like remove stopwords from start, end, remove short words from start, end

    def remove_short_noun_phrase(
        self, noun_chunks, col_noun_chunk: Union[list, pd.DataFrame] = list(), len_min_wrd=3, noun_chunks_to_keep=[]
    ):
        try:
            if isinstance(noun_chunks, pd.DataFrame):
                if col_noun_chunk not in noun_chunks.columns:
                    raise ValueError(f"{col_noun_chunk} is not present in the noun chunks dataframe. Please pass the correct column name")

            def fx(x):
                return [word for word in x if (len(word) > len_min_wrd - 1) or (word in noun_chunks_to_keep)]

            if isinstance(noun_chunks, list):
                if not any(isinstance(el, list) for el in noun_chunks):
                    noun_chunks = pd.DataFrame({col_noun_chunk: [noun_chunks]})
                else:
                    noun_chunks = pd.DataFrame({col_noun_chunk: noun_chunks})
                noun_chunks[col_noun_chunk] = noun_chunks[col_noun_chunk].apply(lambda x: fx(x))
                return list(noun_chunks[col_noun_chunk])
            else:
                noun_chunks[col_noun_chunk] = noun_chunks[col_noun_chunk].apply(lambda x: fx(x))
                return noun_chunks
        except Exception as e:
            self.logger.error(f"Following error occured while removing short noun phrase {e}")

    def remove_special_character_noun_phrases(self, noun_chunks: Union[list, pd.DataFrame] = list(), col_noun_chunk=None):
        try:
            if isinstance(noun_chunks, pd.DataFrame):
                if col_noun_chunk not in noun_chunks.columns:
                    raise ValueError(f"{col_noun_chunk} is not present in the noun chunks dataframe. Please pass the correct column name")

            def fx(x):
                return [word for word in x if re.search("[a-zA-Z]", word)]

            if isinstance(noun_chunks, list):
                if not any(isinstance(el, list) for el in noun_chunks):
                    noun_chunks = pd.DataFrame({col_noun_chunk: [noun_chunks]})
                else:
                    noun_chunks = pd.DataFrame({col_noun_chunk: noun_chunks})
                noun_chunks[col_noun_chunk] = noun_chunks[col_noun_chunk].apply(lambda x: fx(x))
                return list(noun_chunks[col_noun_chunk])
            else:
                noun_chunks[col_noun_chunk] = noun_chunks[col_noun_chunk].apply(lambda x: fx(x))
                return noun_chunks
        except Exception as e:
            self.logger.error(f"Following error occured while removing special character noun phrase {e}")

    def remove_ngram_noun_chunks(
        self, noun_chunks: Union[list, pd.DataFrame] = list(), col_noun_chunk="noun_chunk_col", remove_gram="unigram"
    ):

        """Function to remove ngram noun chunks from the list of noun chunks generated using nltk and spacy

        Parameters
        ----------
        noun_chunks : Union[list, pd.DataFrame], optional
            list or list of list or pd.DataFrame of ngram noun chunks, by default list()
            Example - ['sentences', 'noun chunks'] or [['sentences', 'noun chunks'], ['second sentence', 'noun extraction']]
            or dataframe with noun chunks in the column
        col_noun_chunk: str, optional
            column name for noun chunks in the noun_chunks dataframe, by default "noun_chunk_col"
        remove_gram : str, optional
            removes type of ngram word from unigram/polygram, by default "unigram"

        Returns
        -------
        list or pd.DataFrame
            list of noun chunks after removing unigram or polygrams or dataframe with removed unigrams and polygrams
        """
        try:
            if isinstance(noun_chunks, pd.DataFrame):
                if col_noun_chunk not in noun_chunks.columns:
                    raise ValueError(f"{col_noun_chunk} is not present in the noun chunks dataframe. Please pass the correct column name")

            if remove_gram == "unigram":

                def fx(noun_chunk_x):
                    return [i for i in noun_chunk_x if (len(i.split()) > 1)]

            elif remove_gram == "polygram":

                def fx(noun_chunk_x):
                    return [i for i in noun_chunk_x if (len(i.split()) <= 1)]

            else:
                raise ValueError("Incorrect value for remove_ngram parameter. Please pass remove_ngram parameter as unigram or polygram")

            if isinstance(noun_chunks, list):
                if not any(isinstance(el, list) for el in noun_chunks):
                    noun_chunks = pd.DataFrame({col_noun_chunk: [noun_chunks]})
                else:
                    noun_chunks = pd.DataFrame({col_noun_chunk: noun_chunks})
                noun_chunks[col_noun_chunk] = noun_chunks[col_noun_chunk].apply(lambda x: fx(x))
                return list(noun_chunks[col_noun_chunk])
            else:
                noun_chunks[col_noun_chunk] = noun_chunks[col_noun_chunk].apply(lambda x: fx(x))
                return noun_chunks
        except Exception as e:
            self.logger.error(f"Following error occured while removing ngram noun phrase {e}")
