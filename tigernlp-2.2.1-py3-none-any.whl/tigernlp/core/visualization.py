import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import plotly.express as px
import scipy.sparse as sp
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.preprocessing import MinMaxScaler, normalize
from sklearn.utils import check_array
from typing import List
from umap.umap_ import UMAP
from wordcloud import WordCloud

from .utils import tsne_components

# import plotly.graph_objects as go


class ClassTFIDF(TfidfTransformer):
    """
    A Class-based TF-IDF procedure using scikit-learns TfidfTransformer as a base.

    ![](../img/ctfidf.png)

    C-TF-IDF can best be explained as a TF-IDF formula adopted for multiple classes
    by joining all documents per class. Thus, each class is converted to a single document
    instead of set of documents. Then, the frequency of words **t** are extracted for
    each class **i** and divided by the total number of words **w**.
    Next, the total, unjoined, number of documents across all classes **m** is divided by the total
    sum of word **i** across all classes.
    """

    def __init__(self):
        super(ClassTFIDF, self).__init__()

    def fit(self, X: sp.csr_matrix, multiplier: np.ndarray = None):
        """Learn the idf vector (global term weights).

        Arguments:
            X: A matrix of term/token counts.
            multiplier: A multiplier for increasing/decreasing certain IDF scores
        """
        X = check_array(X, accept_sparse=("csr", "csc"))
        if not sp.issparse(X):
            X = sp.csr_matrix(X)
        dtype = np.float64

        if self.use_idf:
            _, n_features = X.shape

            # Calculate the frequency of words across all classes
            df = np.squeeze(np.asarray(X.sum(axis=0)))

            # Calculate the average number of samples as regularization
            avg_nr_samples = int(X.sum(axis=1).mean())

            # Divide the average number of samples by the word frequency
            # +1 is added to force values to be positive
            idf = np.log((avg_nr_samples / df) + 1)

            # Multiplier to increase/decrease certain idf scores
            if multiplier is not None:
                idf = idf * multiplier

            self._idf_diag = sp.diags(idf, offsets=0, shape=(n_features, n_features), format="csr", dtype=dtype)

        return self

    def transform(self, X: sp.csr_matrix):
        """Transform a count-based matrix to c-TF-IDF

        Arguments:
            X (sparse matrix): A matrix of term/token counts.

        Returns:
            X (sparse matrix): A c-TF-IDF matrix
        """
        if self.use_idf:
            X = normalize(X, axis=1, norm="l1", copy=False)
            X = X * self._idf_diag

        return X


def extract_topics(documents: pd.DataFrame, topic_list):
    """Extract topics from the clusters using a class-based TF-IDF

    Arguments:
        documents: Dataframe with documents and their corresponding IDs

    Returns:
        c_tf_idf: The resulting matrix giving a value (importance score) for each word per topic
    """
    documents_per_topic = documents.groupby(["topic"], as_index=False).agg({"stem_text": " ".join})

    documents = documents_per_topic.stem_text

    vectorizer_model = CountVectorizer(ngram_range=(1, 1))

    vectorizer_model.fit(documents)

    words = vectorizer_model.get_feature_names()
    X = vectorizer_model.transform(documents)

    multiplier = None

    transformer = ClassTFIDF().fit(X, multiplier=multiplier)

    c_tf_idf = transformer.transform(X)

    labels = topic_list

    # Get the top 30 indices and values per row in a sparse c-TF-IDF matrix
    # indices = self._top_n_idx_sparse(c_tf_idf, 30)
    n = 30
    indices = []
    for le, ri in zip(c_tf_idf.indptr[:-1], c_tf_idf.indptr[1:]):
        n_row_pick = min(n, ri - le)
        values = c_tf_idf.indices[le + np.argpartition(c_tf_idf.data[le:ri], -n_row_pick)[-n_row_pick:]]
        values = [values[index] if len(values) >= index + 1 else None for index in range(n)]
        indices.append(values)
    indices = np.array(indices)

    # scores = self._top_n_values_sparse(c_tf_idf, indices)
    top_values = []
    for row, values in enumerate(indices):
        scores = np.array([c_tf_idf[row, value] if value is not None else 0 for value in values])
        top_values.append(scores)
    scores = np.array(top_values)

    sorted_indices = np.argsort(scores, 1)
    indices = np.take_along_axis(indices, sorted_indices, axis=1)
    scores = np.take_along_axis(scores, sorted_indices, axis=1)

    # Get top 30 words per topic based on c-TF-IDF score
    topics = {
        label: [
            (words[word_index], score) if word_index is not None and score > 0 else ("", 0.00001)
            for word_index, score in zip(indices[index][::-1], scores[index][::-1])
        ]
        for index, label in enumerate(labels)
    }

    # Extract word embeddings for the top 30 words per topic and compare it
    # with the topic embedding to keep only the words most similar to the topic embedding

    topics = {label: values[:30] for label, values in topics.items()}

    topic_names = {key: f"{key} |" + " | ".join([word[0] for word in values[:4]]) for key, values in topics.items()}
    return topic_names, c_tf_idf


def _plotly_topic_visualization(df: pd.DataFrame, topic_list: List[str], width: int, height: int):
    """Create plotly-based visualization of topics with a slider for topic selection"""

    def get_color(topic_selected):
        if topic_selected == -1:
            marker_color = ["#B0BEC5" for _ in topic_list]
        else:
            marker_color = ["red" if topic == topic_selected else "#B0BEC5" for topic in topic_list]
        return [{"marker.color": [marker_color]}]

    # Prepare figure range
    x_range = (df.x.min() - abs((df.x.min()) * 0.15), df.x.max() + abs((df.x.max()) * 0.15))
    y_range = (df.y.min() - abs((df.y.min()) * 0.15), df.y.max() + abs((df.y.max()) * 0.15))

    # Plot topics
    fig = px.scatter(
        df,
        x="x",
        y="y",
        size="Size",
        size_max=40,
        template="simple_white",
        labels={"x": "", "y": ""},
        hover_data={"Topic": True, "Words": True, "Size": True, "x": False, "y": False},
    )
    fig.update_traces(marker=dict(color="#B0BEC5", line=dict(width=2, color="DarkSlateGrey")))

    # Update hover order
    fig.update_traces(hovertemplate="<br>".join(["<b>Topic %{customdata[0]}</b>", "Words: %{customdata[1]}", "Size: %{customdata[2]}"]))

    # Create a slider for topic selection
    steps = [dict(label=f"Topic {topic}", method="update", args=get_color(topic)) for topic in topic_list]
    sliders = [dict(active=0, pad={"t": 50}, steps=steps)]

    # Stylize layout
    fig.update_layout(
        title={
            "text": "<b>Intertopic Distance Map",
            "y": 0.95,
            "x": 0.5,
            "xanchor": "center",
            "yanchor": "top",
            "font": dict(size=22, color="Black"),
        },
        width=width,
        height=height,
        hoverlabel=dict(bgcolor="white", font_size=16, font_family="Rockwell"),
        xaxis={"visible": False},
        yaxis={"visible": False},
        sliders=sliders,
    )

    # Update axes ranges
    fig.update_xaxes(range=x_range)
    fig.update_yaxes(range=y_range)

    # Add grid in a 'plus' shape
    fig.add_shape(type="line", x0=sum(x_range) / 2, y0=y_range[0], x1=sum(x_range) / 2, y1=y_range[1], line=dict(color="#CFD8DC", width=2))
    fig.add_shape(type="line", x0=x_range[0], y0=sum(y_range) / 2, x1=x_range[1], y1=sum(y_range) / 2, line=dict(color="#9E9E9E", width=2))
    fig.add_annotation(x=x_range[0], y=sum(y_range) / 2, text="D1", showarrow=False, yshift=10)
    fig.add_annotation(y=y_range[1], x=sum(x_range) / 2, text="D2", showarrow=False, xshift=10)
    fig.data = fig.data[::-1]

    return fig


def visualize_topics(df, width: int = 650, height: int = 650):
    grouped_df = df.groupby(["topic"]).count().sort_values("stem_text", ascending=False).reset_index()
    topic_list = list(grouped_df["topic"])
    frequencies = list(grouped_df["stem_text"])
    documents = list(df["stem_text"])

    topic_names, c_tf_idf = extract_topics(df, topic_list)

    all_topics = topic_list
    indices = np.array([all_topics.index(topic) for topic in all_topics])
    embeddings = c_tf_idf.toarray()[indices]
    embeddings = MinMaxScaler().fit_transform(embeddings)
    if len(embeddings) <= 3:
        print("intertopic_distance_map can not be generated for number of clusters <=3")
        return None

    else:
        embeddings = UMAP(n_neighbors=2, n_components=2, metric="hellinger").fit_transform(embeddings)
        visulization_df = pd.DataFrame(
            {"x": embeddings[:, 0], "y": embeddings[:, 1], "Topic": topic_list, "Words": list(topic_names.values()), "Size": frequencies}
        )

        return _plotly_topic_visualization(visulization_df, topic_list, 650, 650)


def tsne_2d_visualization(feature_array, feature_array_2d=False, labels=None, ax=None, metric="euclidean", random_state=42):
    """Converts the high dimensional data in 2D and plot it on a scatter plot.

    Parameters
    ----------
    feature_array : np.array
        High dimensional data array
    feature_array_2d : bool, optional
        if True, graph will be plotted on the feature array without reducing the dimensionality
    labels : np.array, optional
        target values of feature_array. If present then data points will be plotted using different colors
        If None all datapoints will be plotted using same color, by default None
    ax : matplotlib subplot, optional
        subplot axes for tsne graph, by default None
    metric : str, optional
        the metric to use when calculating distance between instances in a feature array.
        If metric is a string, it must be one of the options allowed by scipy.spatial.distance.pdist for its metric parameter,
        or a metric listed in pairwise.PAIRWISE_DISTANCE_FUNCTIONS, by default "euclidean"
    random_state : int, optional
        determines the random number generator. Pass an int for reproducible results across multiple function calls.
        Note that different initializations might result in different local minima of the cost function, by default 42

    Returns
    -------
    matplotlib.pyplot.figure
        A scatter plot representing multidimensional data in 2D format.
    """
    if isinstance(feature_array, list):
        feature_array = np.array(feature_array)
    if feature_array_2d:
        X = feature_array
    else:
        X = tsne_components(feature_array, 2, metric=metric, random_state=random_state)

    if ax is None:
        fig, ax = plt.subplots(1, 1, figsize=(16, 8))

    if labels is None:
        ax.scatter(x=X[:, 0], y=X[:, 1], s=20)
        ax.set_title("t-SNE visualization")
    else:
        label = list(np.unique(labels))
        graph = ax.scatter(
            x=X[:, 0],
            y=X[:, 1],
            s=20,
            c=labels,
            cmap=plt.get_cmap("tab20b"),
        )
        if len(label) > 25:
            ncol = int((len(label) + 24) / 25)
        else:
            ncol = 1

        ax.legend(
            handles=graph.legend_elements(prop="colors", num=len(label))[0],
            labels=label,
            title="Topic",
            loc="best",
            ncol=ncol,
        )
        ax.set_title("t-SNE visualization of " + str(len(np.unique(labels))) + " topics")

    ax.set_xlabel("tsne-2d-one", fontsize=14)
    ax.set_ylabel("tsne-2d-two", fontsize=14)
    # ax.text(
    #     max(X[:, 0]), min(X[:, 1]) - (abs(min(X[:, 1])) + max(X[:, 1])) / 8, "Refer documentation for more details", fontsize=10, ha="right"
    # )
    ax.axis("tight")

    return ax


def hyperparameter_plot_graph(
    subplot, x, y, graph_format="bx-", x_label="x_label", y_label="y_label", line_x=0, line_color="#90ee90", linestyle="--"
):
    """Function to plot a line graph and vertical line

    Parameters
    ----------
    subplot : matplotlib.axes._subplots.AxesSubplot
        _description_
    x : _type_
        _description_
    y : _type_
        _description_
    graph_format : str, optional
        _description_, by default "bx-"
    x_label : str, optional
        _description_, by default "x_label"
    y_label : str, optional
        _description_, by default "y_label"
    line_x : int, optional
        _description_, by default 0
    line_color : str, optional
        _description_, by default "#90ee90"
    linestyle : str, optional
        _description_, by default "--"
    """
    subplot.plot(x, y, graph_format)
    subplot.axvline(x=line_x, color=line_color, ls=linestyle)  # , label="axvline - full height")

    subplot.set_xlabel(x_label)
    subplot.set_ylabel(y_label)


def word_cloud(text="", max_words=2000, collocation_threshold=5, collocations=True, random_state=42, colormap=None):
    """Generates Word Cloud plot from the input text

    Parameters
    ----------
    text : str, optional
        text for wordcloud, by default ''
    max_words : int, optional
        maximum number of words in wordcloud, by default 2000
    collocation_threshold: int, optional
        bigrams must have a Dunning likelihood collocation score greater than this parameter to be counted as bigrams, by default 5
    collocations : bool, optional
        if False, this wil ensure that the word cloud does not appear as if it contains any duplicate words, by default True

        if True, you may see `web`, `scraping` and `web scraping` as a collocation in the word cloud,
        giving an impression that words have been duplicated
    random_state : int, optional
        It will keep PIL color for each word, set as an int value, by default 42
    colormap: str, optional
        Matplotlib colormap to randomly draw colors from for each word, by default None
        https://matplotlib.org/stable/tutorials/colors/colormaps.html
    """
    try:
        wordcloud = WordCloud(
            background_color="white",
            max_words=max_words,
            collocation_threshold=collocation_threshold,
            collocations=collocations,
            random_state=random_state,
            colormap=colormap,
        ).generate(text)
        graph = plt.figure()
        plt.imshow(wordcloud, interpolation="bilinear")
        plt.axis("off")
        plt.tight_layout(pad=0)

        return graph
    except Exception as e:
        print(f"Error occured while using count {e}")
