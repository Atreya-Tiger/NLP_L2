import nltk
import spacy
import traceback
from spacy.cli.download import get_compatibility
from urllib.request import urlopen

from .utils import MyLogger

logger = MyLogger(level="INFO").logger


def check_spacy_github_access(timeout=10) -> bool:
    """Check if able to access spacy download links from github

    Parameters
    ----------
    timeout : int, optional
        How long to check (in seconds) if able to access spacy github links, by default 10

    Returns
    -------
    bool
        True if able to access Spacy download links from github, False otherwise
    """
    try:
        status = urlopen(spacy.about.__compatibility__, timeout=timeout).status
        return status == 200
    except Exception:
        return False


def spacy_error_log(model_name: str) -> None:
    """
    Function to display steps to manually setup spacy models when the given model in ``model_name`` cannot be downloaded automatically.

    Parameters
    ----------
    model_name : str
        Name of the model given as input to the module.
    """
    first_block_msg = """Model needs to be manually downloaded and passed.\n
    Manual download steps are given below:
    """
    if model_name == "en_core_web_sm":
        second_block_msg = """
        1. Go to https://github.com/explosion/spacy-models/releases/tag/en_core_web_sm-3.3.0 . Download en_core_web_sm-3.3.0-py3-none-any.whl under Assets section.

        2. type "pip install <en_core_web_sm-3.3.0-py3-none-any.whl file path>" in your terminal or command prompt.
        """

    elif model_name == "en_core_web_md":
        second_block_msg = """
        1. Go to https://github.com/explosion/spacy-models/releases/tag/en_core_web_md-3.3.0 . Download en_core_web_md-3.3.0-py3-none-any.whl under Assets section.

        2. type "pip install <en_core_web_md-3.3.0-py3-none-any.whl file path>" in your terminal or command prompt.
        """

    elif model_name == "en_core_web_lg":
        second_block_msg = """
        1. Go to https://github.com/explosion/spacy-models/releases/tag/en_core_web_lg-3.3.0 . Download en_core_web_lg-3.3.0-py3-none-any.whl under Assets section.

        2. type "pip install <en_core_web_lg-3.3.0-py3-none-any.whl file path>" in your terminal or command prompt.
        """
    else:
        second_block_msg = "We currently do not support any other language models."
        logger.warn(f"{second_block_msg}")
        return

    logger.warn(
        f"{first_block_msg}\n{second_block_msg}\nOnce the model is downloaded and extracted its path can directly be passed as a variable to the required classes/functions."
    )


def spacy_download_validate(model_name: str) -> bool:
    """
    Checks if a given model already exists or not.

    If it doesn't exist, model will be downloaded.

    Parameters
    ----------
    model_name : str
        Model name to be validated and downloaded

    Returns
    -------
    bool
        True if model already exists or is successfully downloaded. False if model could not be downloaded.

    Examples
    --------
    >>> from tigernlp.core.nlp_downloads import spacy_download_validate
    >>> # The following will return True if model already exists or is successfully downloaded.
    >>> # False if model could not be downloaded
    >>> ret = spacy_download_validate('en_core_web_sm')
    """

    if not isinstance(model_name, str):
        logger.error(
            f"Received model_name={model_name} which is not a string but a {type(model_name)}"
        )
        # return False
        raise ValueError("Model name must be a string")

    # If model already exists, return True
    if spacy.util.is_package(model_name):
        return True

    # The reason for this check is to make sure we are not restricted by vpns to connect to spacy github for model downloads.
    # get_compatibility() function connects to spacy github as well but it doesn't return an error code, but rather displays error message as output
    # Hence this allows us to make sure we are able to access appropriate download links
    ret = check_spacy_github_access()

    # Unable to access Spacy github
    if not ret:
        logger.warn("Unable to access Spacy github links")
        spacy_error_log(model_name)
        return False

    all_spacy_models = get_compatibility()

    if model_name not in all_spacy_models:
        logger.warn(f'Received model_name "{model_name}" which doesnot exist in spacy repository.')
        logger.warn(
            'All the language models can be found at https://spacy.io/usage/models#languages".'
        )
        # raise ValueError("Invalid model_name received")
        return False

    try:
        # Download the model from spacy cli
        logger.info(f'Downloading "{model_name}" model ...')
        spacy.cli.download(model_name)
        return True
    except Exception:
        # If model is still unable to be downloaded, then follow the below steps to setup the en_core_web_sm model
        logger.warn(traceback.format_exc())
        logger.warn(f'Error downloading "{model_name}" model')
        spacy_error_log(model_name)
        return False


def set_nltk_data_path(path: str):
    """Appends the location of `nltk_data` folder to the list of existing default locations.

    Parameters
    ----------
    path : str
        directory location of the nltk_data folder.
    """
    nltk.data.path.append(path)


def download_nltk_data() -> bool:
    """Function to download nltk resources automatically.

    Returns
    -------
    bool
        True, if there is no error in downloading nltk data. False, otherwise.
    """
    error_flag = False
    try:
        nltk.data.find("tokenizers/punkt")
    except LookupError:
        download_flag = nltk.download("punkt", quiet=True)
        if not download_flag:
            error_flag = True

    try:
        nltk.data.find("corpora/stopwords")
    except LookupError:
        download_flag = nltk.download("stopwords", quiet=True)
        if not download_flag:
            error_flag = True
    try:
        nltk.data.find("corpora/wordnet")
    except LookupError:
        download_flag = nltk.download("wordnet", quiet=True)
        if not download_flag:
            error_flag = True
    try:
        nltk.data.find("corpora/words")
    except LookupError:
        download_flag = nltk.download("words", quiet=True)
        if not download_flag:
            error_flag = True
    try:
        nltk.data.find("chunkers/maxent_ne_chunker")
    except LookupError:
        download_flag = nltk.download("maxent_ne_chunker", quiet=True)
        if not download_flag:
            error_flag = True
    try:
        nltk.data.find("corpora/omw-1.4")
    except LookupError:
        download_flag = nltk.download("omw-1.4", quiet=True)
        if not download_flag:
            error_flag = True
    try:
        nltk.data.find("taggers/averaged_perceptron_tagger")
    except LookupError:
        download_flag = nltk.download("averaged_perceptron_tagger", quiet=True)
        if not download_flag:
            error_flag = True
    try:
        nltk.data.find("help/tagsets")
    except LookupError:
        download_flag = nltk.download("tagsets", quiet=True)
        if not download_flag:
            error_flag = True

    return error_flag


def verify_spacy(model_name: str, spacy_version: str):
    """
    Verifies the available spacy model version with required model version.
    If the specified model is not available, model is downloaded.

    Parameters
    ----------
    model_name : str
        spacy model name or path to model.
    spacy_version : str
        spacy model version reqiured.

    Returns
    -------
    bool : if the available model version matches with the required version specified return True otherwise False.
    """

    try:
        nlp_model = spacy.load(model_name)
        model_version = nlp_model.meta["version"]

        if model_version != spacy_version:
            logger.warn(
                """Provided model version is {} whereas the required version is {}.""".format(
                    model_version, spacy_version
                )
            )
            return False
        else:
            return True
    except Exception:
        return spacy_download_validate(model_name)
