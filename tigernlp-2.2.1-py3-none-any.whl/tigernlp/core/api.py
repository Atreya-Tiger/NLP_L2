"""Core utilities common to all usecases.
This is a namespace housing all the core utilties that could be useful across modules.
"""
from .custom_multiprocessing import parallelize, parallelize_groupby, parallelize_row_wise
from .eval_metrics_ import (
    EvaluationMetrics,
    classification_model_report,
    get_db_index,
    get_silhouette_score,
    partial_match_metrics,
)

# Validate Spacy models
from .nlp_downloads import spacy_download_validate, verify_spacy
from .paraphraser import Paraphraser
from .phrase_extraction import PhraseExtraction, PhraseProcessing
from .pipeline import Pipeline
from .train_test_split_ import StratifiedDataManager
from .utils import MyLogger, convert_df_column_list_values_to_rows, k_func, load_data, rank_func, tsne_components
from .visualization import tsne_2d_visualization, visualize_topics, word_cloud
