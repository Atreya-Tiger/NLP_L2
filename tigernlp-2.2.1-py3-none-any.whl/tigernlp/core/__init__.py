"""This is a namespace housing all the core utilties that could be useful across modules.
"""
