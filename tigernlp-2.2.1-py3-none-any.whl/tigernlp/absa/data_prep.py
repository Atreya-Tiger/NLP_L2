import os
import pandas as pd
import re
import shutil
from pyabsa import make_ABSA_dataset
from pyabsa.utils.file_utils import convert_apc_set_to_atepc_set
from sklearn.model_selection import train_test_split

from tigernlp.core.api import MyLogger


def _creatingTextFile(df: pd.DataFrame, filename: str, logger: MyLogger):  # For internal use only, not available to users
    """Create text file from dataframe

    Parameters
    ----------
    df : pd.DataFrame
        Dataframe containing 'sentence', 'aspect' and 'sentiment' columns
    filename : str
        name of the file to save
    logger : MyLogger
        Object of MyLogger to save logs

    Raises
    ------
    ValueError
        Raises ValueError if type of df is other than pd.Dataframe
    ValueError
        Raises ValueError if input df is empty
    ValueError
        Raises ValueError if 'sentence' column not found in dataframe
    ValueError
        Raises ValueError if 'aspect' column not found in dataframe
    ValueError
        Raises ValueError if 'sentiment' column not found in dataframe
    """
    try:
        if df is None or not isinstance(df, pd.DataFrame):
            raise ValueError("Input dataframe is of incorrect type in this method")
        if not (df.shape[0]) > 0:
            raise ValueError("Input dataframe is empty")
        if 'sentence' not in df.columns:
            raise ValueError("'sentence' column not found in dataframe")
        if 'aspect' not in df.columns:
            raise ValueError("'aspect' column not found in dataframe")
        if 'sentiment' not in df.columns:
            raise ValueError("'sentiment' column not found in dataframe")
        with open(filename, 'w') as f:
            for row in range(df.shape[0]):
                text = str(df.iloc[row]['sentence'])
                aspect_term = df.iloc[row]['aspect']
                polarity = df.iloc[row]['sentiment']
                text = re.sub(r"[\([{})\]]", "", text)
                aspect_term = re.sub(r"[\([{})\]]", "", aspect_term)
                text_1 = re.sub(aspect_term, ' $T$', text)
                f.write(text_1)
                f.write('\n')
                f.write(aspect_term)
                f.write('\n')
                f.write(polarity)
                f.write('\n')
    except Exception as e:
        logger.error(f"Error occurred during preparing dataset.\n {e}")


def _creatingTextInferenceFile(df: pd.DataFrame, filename: str, logger: MyLogger):  # For internal use only, not available to users
    """Create inference text file from dataframe

    Parameters
    ----------
    df : pd.DataFrame
        Dataframe containing 'sentence', 'aspect' and 'sentiment' columns
    filename : str
        name of the file to save
    logger : MyLogger
        Object of MyLogger to save logs

    Raises
    ------
    ValueError
        Raises ValueError if type of df is other than pd.Dataframe
    ValueError
        Raises ValueError if input df is empty
    ValueError
        Raises ValueError if 'sentence' column not found in dataframe
    ValueError
        Raises ValueError if 'aspect' column not found in dataframe
    ValueError
        Raises ValueError if 'sentiment' column not found in dataframe
    """
    try:
        if df is None or not isinstance(df, pd.DataFrame):
            raise ValueError("Input dataframe is of incorrect type in this method")
        if not (df.shape[0]) > 0:
            raise ValueError("Input dataframe is empty")
        if 'sentence' not in df.columns:
            raise ValueError("'sentence' column not found in dataframe")
        if 'aspect' not in df.columns:
            raise ValueError("'aspect' column not found in dataframe")
        if 'sentiment' not in df.columns:
            raise ValueError("'sentiment' column not found in dataframe")
        with open(filename, 'w') as f:
            for row in range(df.shape[0]):
                text = str(df.iloc[row]['sentence'])
                aspect_term = df.iloc[row]['aspect']
                polarity = df.iloc[row]['sentiment']
                text = re.sub(r"[\([{})\]]", "", text)
                aspect_term = re.sub(r"[\([{})\]]", "", aspect_term)
                text_1 = re.sub(aspect_term, ' [ASP]' + aspect_term.strip() + '[ASP]', text)
                f.write(text_1)
                f.write(' ')
                f.write('!sent!')
                f.write(' ')
                f.write(polarity)
                f.write('\n')
    except Exception as e:
        logger.error(f"Error occurred during preparing dataset.\n {e}")


def data_preparation(df: pd.DataFrame, path: str = None, checkpoint: str = "english",
                     log_level: str = "WARNING",
                     log_file_path: str = None,
                     verbose: bool = True
                     ):
    """Converts dataframe into the APC and ATEPC formats required for training

    Parameters
    ----------
    df : pd.Dataframe
        Dataframe containing 'sentence', 'aspect' and 'sentiment' columns
        Example: sentence - "I like this coffee but it is kind of expensive .", aspect - "coffee", sentiment - "Negative"
    path : str, optional
        Path to save APC and ATEPC datasets
        If None data is saved at current_working_directory/data/nlp_models/absa_dataset, by default None
    checkpoint : str, optional
        Which checkpoint to use. Basically, You can select from {'multilingual', 'english', 'chinese'}, by default "english"
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "WARNING"
    log_file_path : str, optional
        File path to save the logs, by default None
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Returns
    -------
    str
        Path to ATEPC dataset directory

    Raises
    ------
    ValueError
        Raises ValueError if type of df is other than pd.Dataframe
    ValueError
        Raises ValueError if input df is empty
    ValueError
        Raises ValueError if 'sentence' column not found in dataframe
    ValueError
        Raises ValueError if 'aspect' column not found in dataframe
    ValueError
        Raises ValueError if 'sentiment' column not found in dataframe
    """
    logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger
    try:
        if df is None or not isinstance(df, pd.DataFrame):
            raise ValueError("Input dataframe is of incorrect type in this method")
        if not (df.shape[0]) > 0:
            raise ValueError("Input dataframe is empty")
        if 'sentence' not in df.columns:
            raise ValueError("'sentence' column not found in dataframe")
        if 'aspect' not in df.columns:
            raise ValueError("'aspect' column not found in dataframe")
        if 'sentiment' not in df.columns:
            raise ValueError("'sentiment' column not found in dataframe")
        X_train, X_rem = train_test_split(df, train_size=0.8)
        X_valid, X_test = train_test_split(X_rem, test_size=0.5)
        _creatingTextFile(X_train, 'reviews.train.txt.ignore', logger)
        _creatingTextFile(X_valid, 'reviews.test.txt.ignore', logger)
        _creatingTextInferenceFile(X_test, 'reviews.inference.txt.ignore', logger)

        if path == None:
            path = os.path.join(os.getcwd(), "data", "nlp_models", "absa_dataset")

        if os.path.exists(path):
            pass
        else:
            os.makedirs(path)
        src = os. getcwd()
        des = path
        allfiles = os.listdir(src)
        for f in allfiles:
            if f.endswith('.ignore'):
                src_path = os.path.join(src, f)
                dst_path = os.path.join(des, f)
                shutil.move(src_path, dst_path)
        make_ABSA_dataset(dataset_name_or_path=path, checkpoint=checkpoint)
        apc_datasets = 'apc_datasets'
        atepc_datasets = 'atepc_datasets'
        apc_path = os.path.join(path, apc_datasets)
        atepc_path = os.path.join(path, atepc_datasets)
        if os.path.exists(apc_path):
            pass
        else:
            os.makedirs(apc_path)
        if os.path.exists(atepc_path):
            pass
        else:
            os.makedirs(atepc_path)
        allfiles = os.listdir(path)
        for f in allfiles:
            if f.endswith('.apc'):
                src_path = os.path.join(src, path, f)
                dst_path = os.path.join(apc_path, f)
                shutil.move(src_path, dst_path)
            if f.endswith('.atepc'):
                src_path = os.path.join(src, path, f)
                dst_path = os.path.join(atepc_path, f)
                shutil.move(src_path, dst_path)
        convert_apc_set_to_atepc_set(path)
        return atepc_path
    except Exception as e:
        logger.error(f"Error occurred during preparing dataset.\n {e}")
