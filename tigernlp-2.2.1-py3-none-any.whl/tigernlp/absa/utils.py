import os
from pyabsa.functional import ATEPCCheckpointManager, ATEPCConfigManager, ATEPCModelList


def get_sample_config():
    """Get sample parameter config required for model training

    Returns
    -------
    pyabsa.functional.config.atepc_config_manager.ATEPCConfigManager
        Sample parameter configuration, User can make changes as per requiremnt and pass to train
    """
    config = ATEPCConfigManager.get_atepc_config_english()
    return config


def get_ATEPC_modellist():
    """Get list of available pre-trained ABSA models

    Returns
    -------
    dict
        Dictionary containing name of model and model
    """
    ATEPC_modellist = {
        "BERT_BASE_ATEPC": ATEPCModelList.BERT_BASE_ATEPC,
        "FAST_LCF_ATEPC": ATEPCModelList.FAST_LCF_ATEPC,
        "FAST_LCFS_ATEPC": ATEPCModelList.FAST_LCFS_ATEPC,
        "LCF_ATEPC": ATEPCModelList.LCF_ATEPC,
        "LCF_ATEPC_LARGE": ATEPCModelList.LCF_ATEPC_LARGE,
        "LCFS_ATEPC": ATEPCModelList.LCFS_ATEPC,
        "LCFS_ATEPC_LARGE": ATEPCModelList.LCFS_ATEPC_LARGE,
    }
    return ATEPC_modellist


def get_ATEPC_model_object(checkpoint: str = "multilingual", path_to_save_checkpoints: str = None):
    """Function to create the ATEPC model object for faster inference

    Parameters
    ----------
    checkpoint : str, optional
        Name of checkpoints to use. User can use pretrained checkpoints from {'english', 'chinese', 'multilingual', 'multilingual-256', 'multilingual-256-2'}.
        Check the list using
        ```
        from pyabsa import available_checkpoints
        checkpoint_map = available_checkpoints()
        ```
        User can give his own trained checkpoits, just pass the path to checkpoints trained on ABSA, by default 'multilingual'
    path_to_save_checkpoints : str, optional
        Path where user wants to download pretrained checkpoints
        If None then checkpoints will be downloaded at current_working_direcory/data/nlp_models/absa, by default None

    Returns
    -------
    model object
        ATEPCCheckpointManager model object for aspect and polarity extraction
    """

    cwd = os.getcwd()
    if path_to_save_checkpoints is None:
        path_to_save_checkpoints = os.path.join(cwd, "data", "nlp_models", "absa")

    if not os.path.exists(path_to_save_checkpoints):
        os.makedirs(path_to_save_checkpoints)

    os.chdir(path_to_save_checkpoints)

    aspect_extractor = ATEPCCheckpointManager.get_aspect_extractor(checkpoint=checkpoint)

    return aspect_extractor
