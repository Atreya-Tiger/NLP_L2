import json
import os
import pandas as pd

from tigernlp.core.api import MyLogger

from .utils import get_ATEPC_model_object


def predict_aspect_polarity(
    data,
    column_name: str = None,
    return_df: bool = True,
    ATEPC_model_object=None,
    checkpoint: str = "multilingual",
    path_to_save_checkpoints: str = None,
    log_level: str = "WARNING",
    log_file_path: str = None,
    verbose: bool = True,
):
    """Predict aspect and polarity for given text using ABSA checkpoints

    Parameters
    ----------
    data : str/List[str]/pd.Series/pd.DataFrame
        Data can be single string, List of strings or pandas series or dataframe containing strings to find aspect and polarity
    column_name : str, optional
        If data is DataFrame then name of column on which user want to predict aspects and polarities else None, by default None
    return_df : bool, optional
        If True return results in pd.DataFrame form or in json form, by default True
    ATEPC_model_object : model object, optional
        ATEPC model object generated using tigernlp.absa.api get_ATEPC_model_object.
        If provided, checkpoint & path_to_save_checkpoints will not be considered
    checkpoint : str, optional
        Name of checkpoints to use. User can use pretrained checkpoints from {'english', 'chinese', 'multilingual', 'multilingual-256', 'multilingual-256-2'}.
        Check the list using
        ```
        from pyabsa import available_checkpoints
        checkpoint_map = available_checkpoints()
        ```
        User can give his own trained checkpoits, just pass the path to checkpoints trained on ABSA, by default 'multilingual'
    path_to_save_checkpoints : str, optional
        Path where user wants to download pretrained checkpoints
        If None then checkpoints will be downloaded at current_working_direcory/data/nlp_models/absa, by default None
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "WARNING"
    log_file_path : str, optional
        File path to save the logs, by default None
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Returns
    -------
    pd.DataFrame/List of dict
        If Pandas dataframe, then it contains 'sentence', 'aspect', 'sentiment', 'probs' and 'aspect_identifier' columns.
        If list, then list contains the dicts. Dict will have fields like 'sentence', 'aspect', 'sentiment', 'probs' and 'aspect_identifier'.
        'probs' is a list of arrays, each array contain 3 values. [ "Negative_prob", "Neutral_prob", "positive_prob"]

    Raises
    ------
    ValueError
        Raises ValueError if type of data is other than str/list/pd.Series/pd.Dataframe
    ValueError
        Raises ValueError if column_name not provided or column_name not present in dataframe
    ValueError
        Raises ValueError if list/series/dataframe contains other than string data

    Examples
        --------
        >>> from tigernlp.absa.api import predict_aspect_polarity
        >>> texts = ['Tastes great and is very figure friendly,only 10 calories', 'Love it. Will be reordering it', 'This item tastes like medicine which turned me off']
        >>> # ABSA available checkpoints example
        >>> aspect_df = predict_aspect_polarity(texts, checkpoint='multilingual')
        >>> # User trained checkpoint example
        >>> aspect_df = predict_aspect_polarity(texts, checkpoint='./data/nlp_models/absa/checkpoints/user_trained_checkpoint_folder_name')
    """
    logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger
    try:
        data_df = 0
        if type(data) not in [list, pd.Series, str, pd.DataFrame]:
            raise ValueError("Data should be of type str or list/series of str or pandas dataframe")

        if isinstance(data, str):
            data = [data]
        elif isinstance(data, pd.Series):
            data = list(data)
        elif isinstance(data, pd.DataFrame):
            data_df = data.copy()
            if column_name is None or column_name not in data.columns:
                raise ValueError("If input is DataFrame then user need to pass name of column where text data is present")
            data = list(data[column_name])

        if all(map(lambda x: isinstance(x, str), data)):
            pass
        else:
            raise ValueError("Data should be list/series of str")

        if ATEPC_model_object is None:
            aspect_extractor = get_ATEPC_model_object(checkpoint=checkpoint, path_to_save_checkpoints=path_to_save_checkpoints)
        else:
            aspect_extractor = ATEPC_model_object

        cwd = os.getcwd()
        atepc_result = aspect_extractor.extract_aspect(
            inference_source=data,
            save_result=False,  # prints the result in .json file then in next step we convert it in DataFrame
            pred_sentiment=True,  # Predict the sentiment of extracted aspect terms
        )

        os.chdir(cwd)
        dataframe = pd.read_json(json.dumps(atepc_result))
        dataframe = dataframe[["sentence", "aspect", "position", "sentiment", "probs"]]

        def aspect_detected(asp):
            if len(asp) == 0:
                return 0
            else:
                return 1

        dataframe["aspect_identifier"] = dataframe["aspect"].apply(aspect_detected)

        if isinstance(data_df, pd.core.frame.DataFrame):
            try:
                data_df = data_df.rename(columns={"sentence": "sentence_x"})
            except Exception:
                pass
            try:
                data_df = data_df.rename(columns={"aspect": "aspect_x"})
            except Exception:
                pass
            try:
                data_df = data_df.rename(columns={"position": "position_x"})
            except Exception:
                pass
            try:
                data_df = data_df.rename(columns={"sentiment": "sentiment_x"})
            except Exception:
                pass
            try:
                data_df = data_df.rename(columns={"probs": "probs_x"})
            except Exception:
                pass
            try:
                data_df = data_df.rename(columns={"aspect_identifier": "aspect_identifier_x"})
            except Exception:
                pass

            data_df.reset_index(drop=True, inplace=True)
            dataframe = pd.concat([data_df, dataframe], axis=1)

        if return_df:
            return dataframe
        else:
            return json.loads(dataframe.to_json(orient="records"))
    except Exception as e:
        logger.error(f"Error occurred during inference.\n {e}")
