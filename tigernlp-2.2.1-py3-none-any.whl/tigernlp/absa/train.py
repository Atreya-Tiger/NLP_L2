import os
from pyabsa.functional import ABSADatasetList, ATEPCCheckpointManager, ATEPCConfigManager, ATEPCModelList, ATEPCTrainer, Trainer

from tigernlp.core.api import MyLogger

from .utils import get_sample_config


def absa_training(dataset_path: str, path_to_save_checkpoints: str = None, checkpoint: str = '', atepc_config=get_sample_config(), auto_device: bool = True,
                  log_level: str = "WARNING",
                  log_file_path: str = None,
                  verbose: bool = True):
    """Train ABSA model on given data

    Parameters
    ----------
    dataset_path : str
        Path to dataset returned from data_preparation() function
    path_to_save_checkpoints : str, optional
        Path to save APC and ATEPC datasets and trained checkpoints
        If None then new folder "checkpoints" will be created in current working directory, by default None
    checkpoint : str, optional
        Name of checkpoints to initiate with {'english', 'chinese', 'multilingual', 'multilingual-256', 'multilingual-256-2'}
        User can pass his/own checkpoints, just need to pass local path to checkpoints, by default ''
    atepc_config : pyabsa.functional.config.atepc_config_manager.ATEPCConfigManager, optional
        Config containing all required parameter values
        User can get sample config by calling get_sample_config() and update it, by default get_sample_config()
    auto_device : True/False/'allcuda'/'cuda:1'/'cpu', optional
        Selects device to train on. True or False, otherwise 'allcuda', 'cuda:1', 'cpu' works, by default True
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "WARNING"
    log_file_path : str, optional
        File path to save the logs, by default None
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Returns
    -------
    aspect_extractor model
        aspect_extractor model

    Raises
    ------
    ValueError
        Raises ValueError if dataset_path is of other type than str. 
    ValueError
        Raises ValueError if dataset_path does not exist.
    ValueError
        Raises ValueError if path_to_save_checkpoints is of other type than str. 
    ValueError
        Raises ValueError if path_to_save_checkpoints does not exist.
    """
    logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    try:
        if not isinstance(dataset_path, str):
            raise ValueError("dataset_path should be string path, got {t}".format(t=type(dataset_path)))
        if not os.path.exists(dataset_path):
            raise ValueError("{dataset_path} does not exists.")

        if not isinstance(path_to_save_checkpoints, str):
            raise ValueError("path_to_save_checkpoints should be string path, got {t}".format(t=type(path_to_save_checkpoints)))
        if not os.path.exists(path_to_save_checkpoints) and (not path_to_save_checkpoints == None):
            raise ValueError("{path_to_save_checkpoints} does not exists.")

        aspect_extractor = ATEPCTrainer(config=atepc_config,
                                        dataset=dataset_path,
                                        from_checkpoint=checkpoint,  # set checkpoint to train on the checkpoint.
                                        checkpoint_save_mode=1,
                                        path_to_save=path_to_save_checkpoints,
                                        auto_device=auto_device
                                        ).load_trained_model()
        return aspect_extractor
    except Exception as e:
        logger.error(f"Error occurred during ABSA training.\n {e}")
