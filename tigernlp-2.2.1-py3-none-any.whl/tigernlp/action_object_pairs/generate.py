import contextlib
import joblib
import math
import os
import pandas as pd
import spacy
from tqdm import tqdm
from typing import Dict, List, Optional, Tuple, Union

from ..core.api import MyLogger, verify_spacy

tqdm.pandas()


class AOPGenerate:
    """
    Extracts subject verb pairs from text/dataframe based on fixed set of rules.

    There are two types of connections available between noun and verb.

    1. Direct connection

    2. Indirect connection

    Among direct connections we have the following rules

    1. Core Dependencies
        Noun and verb having dependency of 'nsubj', 'dobj', 'nsubjpass'.

    2. Conjunctions
        Example: 'Can I verify your name and address'

        Extracts both ('verify', 'name') and ('verify', 'address').

    Among direct connections we have further 2 ways to add extra context to the subject verb pairs

    1. Adjectives to nouns
        Example: 'I walked to the red door'

        Extracts ('walked', 'red door') where 'red' is an adjective to noun 'door'

    2. Noun adpositions
        Example: 'Can I verify your date of birth'

        Extracts ('verify', 'date of birth') where additional context 'of birth' is added to noun 'date'.

    Among indirect connections we have the following rules

    1. Verb adpositions
        Example: 'That drink is made with apples'

        Extracts ('made with', 'apples') where verb 'made' has an indirect connection with noun 'apples' through an adposition 'with'.

    2. Noun conjunctions
        Similar to direct connection, if there is an 'and' or a 'comma', extra verb noun pairs will be extracted

    Among indirect connections we have further 2 ways to add extra context to the subject verb pairs

    1. Adjectives to nouns
        Similar to direct connection, if there is an adjective to a noun, it will be extracted.

    2. Noun adpositions
        Similar to direct connection, if there is an adposition available to a noun it gets extracted

    Parameters
    ----------
    merge_compound_nouns : bool, optional, default-True
        If compound nouns need to be merged.

        For example nouns like 'ecommerce' and 'space' will be merged to form a single subject 'ecommerce space'

    en_core_web_model: str, optional, default-"en_core_web_sm"
        Specify which Spacy english model is to be used. Valid options are "en_core_web_sm", "en_core_web_md", "en_core_web_lg".
        If unable to download en_core_web model, path of the model can be provided manually here.
        If providing the directory location of the model, make sure it is a valid string.

        example- ``r"C:/folder/subfolder/en_core_web_sm-3.3.0/en_core_web_sm/en_core_web_sm-3.3.0"``
        or ``r"C:\\folder\subfolder\en_core_web_lg-3.3.0\en_core_web_lg\en_core_web_lg-3.3.0"``
        or ``"C:\\\\folder\subfolder\en_core_web_lg-3.3.0\en_core_web_lg\en_core_web_lg-3.3.0"``

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    log_level: str, optional
        Level or severity of the events needed to be tracked, by default "INFO"


    Examples
    --------
    >>> from tigernlp.action_object_pairs.api import AOPGenerate
    >>> aopGenerate = AOPGenerate(merge_compound_nouns=True)

    >>> # Option 1 - Run on single text
    >>> aopGenerate.process("I want to add my kids to my insurance policy."
                            include_core_dependencies = True,
                            include_adjectives = True,
                            include_verb_adpositions = True,
                            include_noun_adpositions = True,
                            include_noun_conjunctions = True,
                            additional_noun_verb_deps = None)
        [
            {
                'pairs': ('add to', 'my insurance policy'),
                'named_entities': [],
                'pairs_pos_lemma': [('add', 'VERB'), ('to', 'ADP'), ('my insurance policy', 'NOUN')],
                'pairs_lemma': ('add', 'my insurance policy')
            },
            {
                'pairs': ('add', 'my kids'),
                'named_entities': [],
                'pairs_pos_lemma': [('add', 'VERB'), ('my kid', 'NOUN')],
                'pairs_lemma': ('add', 'my kid')
            }
        ]

    >>> # Option 2 - Run on a dataframe by applying parallel processing
    >>> df = aopGenerate.process_df(dataframe = df,
                                    n_jobs = 4,
                                    include_core_dependencies = True,
                                    include_adjectives = True,
                                    include_verb_adpositions = True,
                                    include_noun_adpositions = True,
                                    include_noun_conjunctions = True,
                                    additional_noun_verb_deps = None)

    >>> # Option 3 - Run on a dataframe without parallel processing
    >>> df = aopGenerate.process_df(dataframe = df,
                                    n_jobs = 1,
                                    include_core_dependencies = True,
                                    include_adjectives = True,
                                    include_verb_adpositions = True,
                                    include_noun_adpositions = True,
                                    include_noun_conjunctions = True,
                                    additional_noun_verb_deps = None)
    """

    def __init__(
        self,
        merge_compound_nouns: Optional[bool] = True,
        en_core_web_model: Optional[str] = "en_core_web_sm",
        log_level="INFO",
        log_file_path=None,
        verbose=True,
    ):
        """
        Parameters
        ----------
        merge_compound_nouns : bool, optional, default-True
            If compound nouns need to be merged

            For example nouns like 'ecommerce' and 'space' will be merged to form a single subject 'ecommerce space'

        en_core_web_model: str, optional, default-"en_core_web_sm"
            Specify which Spacy english model is to be used. Valid options are "en_core_web_sm", "en_core_web_md", "en_core_web_lg".
            If unable to download en_core_web model, path of the model can be provided manually here.
            If providing the directory location of the model, make sure it is a valid string.

            example: ``r"C:/folder/subfolder/en_core_web_sm-3.3.0/en_core_web_sm/en_core_web_sm-3.3.0"``
            or ``r"C:\\folder\subfolder\en_core_web_lg-3.3.0\en_core_web_lg\en_core_web_lg-3.3.0"``
            or ``"C:\\\\folder\subfolder\en_core_web_lg-3.3.0\en_core_web_lg\en_core_web_lg-3.3.0"``

        log_level: str, optional
            Level or severity of the events needed to be tracked, by default "INFO"

        log_file_path: str, optional
            File path to save the logs, by default None

        verbose: bool,
            If `True` logs will be printed to console, by default True
        """

        # Default Spacy version
        self.SPACY_DEFAULT_VERSION = "3.3.0"

        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

        if not isinstance(en_core_web_model, str):
            self.logger.error('"en_core_web_model" paramter must be a string')
            raise ValueError('"en_core_web_model" must be a string')

        # If slash in string, it means its a directory. If directory doesn't exist then raise an error
        if (os.sep in en_core_web_model or "\\" in en_core_web_model) and not os.path.isdir(
            en_core_web_model
        ):
            self.logger.error(
                f'"{en_core_web_model}" is not a valid directory. Make sure the right path to model is provided.'
            )
            raise ValueError(f'"{en_core_web_model}" is not a valid directory')
        # If model name is provided
        # TODO: Add support for trf
        if not os.path.isdir(en_core_web_model) and en_core_web_model not in [
            "en_core_web_sm",
            "en_core_web_md",
            "en_core_web_lg",
        ]:
            self.logger.error(
                'Only english models are accepted. Valid options to en_core_web_model are "en_core_web_sm", "en_core_web_md", "en_core_web_lg". If you are trying to pass a path, make sure it exists.'
            )
            raise ValueError(
                'Valid options to en_core_web_model are "en_core_web_sm", "en_core_web_md", "en_core_web_lg". If you are trying to pass a path, make sure it exists.'
            )

        # If en_core_web is manually downloaded and its path is provided
        spacy_validated = verify_spacy(en_core_web_model, self.SPACY_DEFAULT_VERSION)
        if spacy_validated:
            self.nlp_model = spacy.load(en_core_web_model)

            # If model loading is successful, continue to add pipe if merge_compound_nouns is True
            if merge_compound_nouns:
                self.nlp_model.add_pipe("merge_entities")
                self.nlp_model.add_pipe("merge_noun_chunks")
        else:
            self.nlp_model = spacy.load(en_core_web_model)
            self.logger.error(
                """Provided model version is {} whereas the required version is {}.""".format(
                    self._get_spacy_model_version(), self.SPACY_DEFAULT_VERSION
                )
            )
            self.logger.info(
                "Run 'python -m spacy download en_core_web_sm' in your terminal to download the required version of spacy model. Replace en_core_web_sm to en_core_web_md or en_core_web_lg for medium or large models respectively."
            )
            raise ValueError(
                """Provided model version is {} whereas the required version is {}.""".format(
                    self._get_spacy_model_version(), self.SPACY_DEFAULT_VERSION
                )
            )

    def _get_spacy_model_name(self) -> str:
        """Returns Spacy model name loaded in nlp_model

        Returns
        -------
        str
            Returns if model is "en_core_web_sm" or "en_core_web_md" or "en_core_web_lg"
        """
        return self.nlp_model.meta["lang"] + "_" + self.nlp_model.meta["name"]

    def _get_spacy_model_version(self) -> str:
        """Returns Spacy model version loaded in nlp_model

        Returns
        -------
        str
            Returns version of spacy model loaded in nlp_model
        """
        return self.nlp_model.meta["version"]

    def _adjectivise_noun(
        self, token_: spacy.tokens.token.Token
    ) -> Tuple[str, str, List[Tuple[str, str]], List[Tuple[str, str]]]:
        """
        Return noun with respective adjectives added to it.

        Parameters
        ----------
        token_ : spacy.tokens.token.Token
            Spacy token of the noun whose adjectives are required

        Returns
        -------
        str
            Left adjectives + noun + right adjectives

        str
            Left adjectives lemma + noun lemma + right adjectives lemma

        List[Tuple[str, str], ...]
            List of tuples containing word and respective NER string

        List[Tuple[str, str], ...]
            List of tuples containing word and respective POS string

        Example
        -------
        >>> aopGenerate = AOPGenerate(merge_compound_nouns=True)
        >>> text = "An excited Tom walked up to the bright red door."
        >>> doc = aopGenerate.nlp_model(text)
        >>> (
            adjectives,
            adjectives_lemma,
            adjective_ners,
            adjective_pos,
            ) = aopGenerate._adjectivise_noun(doc[2])
        >>> adjectives
            "excited Tom"

        """

        adjective_ners = []
        adjective_pos = []

        # Find adjectives to the left of the noun (or token) and join them together.
        left_adjectives = []
        left_adjectives_lemma = []
        for left_token in token_.lefts:
            if left_token.pos_.lower() == "adj":
                left_adjectives.append(f"{left_token.text} ")
                if left_token.ent_type_:
                    adjective_ners.append((left_token.text, left_token.ent_type_))
                left_adjectives_lemma.append(f"{left_token.lemma_} ")
                adjective_pos.append((left_token.lemma_, left_token.pos_))
        left_adjectives = "".join(left_adjectives)
        left_adjectives_lemma = "".join(left_adjectives_lemma)

        # Find adjectives to the right of the noun (or token) and join them together.
        right_adjectives = []
        right_adjectives_lemma = []
        for right_token in token_.rights:
            if right_token.pos_.lower() == "adj":
                right_adjectives.append(f"{right_token.text} ")
                right_adjectives_lemma.append(f"{right_token.lemma_} ")
                if right_token.ent_type_:
                    adjective_ners.append((right_token.text, right_token.ent_type_))
                adjective_pos.append((right_token.lemma_, right_token.pos_))
        right_adjectives = "".join(right_adjectives)
        right_adjectives_lemma = "".join(right_adjectives_lemma)

        # Return left adjectives, noun, right adjectives, their lemmas, ners and pos.
        return (
            f"{left_adjectives.strip()} {token_.text} {right_adjectives.strip()}".strip(),
            f"{left_adjectives_lemma.strip()} {token_.lemma_} {right_adjectives_lemma.strip()}".strip(),
            adjective_ners,
            adjective_pos,
        )

    def _get_noun_adpositions(
        self, token_: spacy.tokens.token.Token, include_adjectives: Optional[bool] = True
    ) -> Tuple[
        List[str],
        List[str],
        List[str],
        List[str],
        List[spacy.tokens.token.Token],
        List[spacy.tokens.token.Token],
        List[Tuple[str, str]],
        List[Tuple[str, str]],
        List[Tuple[str, str]],
        List[Tuple[str, str]],
    ]:
        """
        For a noun token, return respective adposition.

        Example: 'Can I verify your date of birth.'

        Here for noun token of 'date', we have an adposition 'of' followed by noun 'birth'.

        This function identifies such nouns connected by adpositions and returns them.

        Parameters
        ----------
        token_ : spacy.tokens.token.Token
            Noun token whose adposition needs to be returned

        include_adjectives : bool, optional, default-True
            If adjectives are to be added for nouns in noun adpositions

        Returns
        -------
        List[str]
            List of left adposition noun texts

        List[str]
            List of right adpostion noun texts

        List[str]
            List of left adposition noun lemmas

        List[str]
            List of right adpostion noun lemmas

        List[spacy.tokens.token.Token]
            List of left adposition noun tokens

        List[spacy.tokens.token.Token]
            List of right adpostion noun tokens

        List[Tuple[str, str]]
            List of left adposition noun entities

        List[Tuple[str, str]]
            List of right adposition noun entities

        List[Tuple[str, str]]
            List of left adposition noun pos tags

        List[Tuple[str, str]]
            List of right adposition noun pos tags

        Examples
        --------
        >>> aopGenerate = AOPGenerate(merge_compound_nouns=True)
        >>> text = "Can I verify your date of birth."
        >>> doc = aopGenerate.nlp_model(text)
        >>> aopGenerate._get_noun_adpositions(doc[3])
            (
                [],
                ['of birth'],
                [],
                ['of birth'],
                [],
                [birth],
                [],
                [[]],
                [],
                [[('of', 'ADP'), ('birth', 'NOUN')]]
            )
        """

        left_adp_nouns = []  # Holds texts of left adposition nouns
        left_adp_nouns_lemma = []  # Holds lemma of left adposition nouns
        left_adp_ners, left_adp_pos = [], []  # Holds left adposition noun entities and pos tags
        left_adp_noun_tokens = (
            []
        )  # Holds left adposition noun tokens required for further conjunction
        # Note that lemma of adposition nouns will not contain adp

        for left_token in token_.lefts:  # For each token in lefts of noun
            if left_token.pos_.lower() == "adp":  # If token is adposition
                for tok1 in left_token.lefts:
                    if tok1.pos_.lower() in ["noun", "propn"]:
                        current_ners, current_pos = [], []

                        # For each token on its lefts, if it is noun or proper noun then adjectivise it and add to text list
                        if include_adjectives:
                            (
                                adjective_tok1,
                                adjective_tok1_lemma,
                                adjective_ners,
                                adjective_pos,
                            ) = self._adjectivise_noun(tok1)

                            left_adp_nouns.append(f"{adjective_tok1} {left_token.text}")

                            left_adp_nouns_lemma.append(f"{adjective_tok1_lemma}")

                            current_ners.extend(list(set(adjective_ners)))
                            current_pos.extend(list(set(adjective_pos)))

                        else:
                            left_adp_nouns.append(f"{tok1.text} {left_token.text}")
                            left_adp_nouns_lemma.append(f"{tok1.lemma_}")

                        if tok1.ent_type_:
                            current_ners.append((tok1.text, tok1.ent_type_))
                        if left_token.ent_type_:
                            current_ners.append((left_token.text, left_token.ent_type_))

                        current_pos.extend(
                            ((tok1.lemma_, tok1.pos_), (left_token.lemma_, left_token.pos_))
                        )

                        left_adp_ners.append(current_ners)
                        left_adp_pos.append(current_pos)

                        # For each token on its lefts, if it is noun or proper noun then add to adposition noun tokens list
                        left_adp_noun_tokens.append(tok1)

                for tok1 in left_token.rights:
                    if tok1.pos_.lower() in ["noun", "propn"]:
                        current_ners, current_pos = [], []

                        # For each token on its rights, if it is noun or proper noun then adjectivise it and add to text list
                        if include_adjectives:
                            (
                                adjective_tok1,
                                adjective_tok1_lemma,
                                adjective_ners,
                                adjective_pos,
                            ) = self._adjectivise_noun(tok1)

                            left_adp_nouns.append(f"{left_token.text} {adjective_tok1}")
                            left_adp_nouns_lemma.append(f"{adjective_tok1_lemma}")

                        else:
                            # This is so we can preserve order of ners and pos
                            adjective_ners, adjective_pos = None, None
                            left_adp_nouns.append(f"{left_token.text} {tok1.text}")
                            left_adp_nouns_lemma.append(f"{tok1.lemma_}")

                        if left_token.ent_type_:
                            current_ners.append((left_token.text, left_token.ent_type_))
                        if adjective_ners:
                            current_ners.extend(list(set(adjective_ners)))
                        if tok1.ent_type_:
                            current_ners.append((tok1.text, tok1.ent_type_))

                        current_pos.append((left_token.lemma_, left_token.pos_))
                        if adjective_pos:
                            current_pos.extend(list(set(adjective_pos)))
                        current_pos.append((tok1.lemma_, tok1.pos_))

                        left_adp_ners.append(current_ners)
                        left_adp_pos.append(current_pos)

                        # For each token on its rights, if it is noun or proper noun then add to adposition noun tokens list
                        left_adp_noun_tokens.append(tok1)

        right_adp_nouns = []  # Holds text of right adposition nouns
        right_adp_nouns_lemma = []  # Holds text of right adposition nouns lemma
        right_adp_ners, right_adp_pos = [], []  # Holds right adposition noun entities and pos tags
        right_adp_noun_tokens = (
            []
        )  # Holds right adposition noun tokens required for further conjunction
        # Note that lemma of adposition nouns will not contain adp

        for right_token in token_.rights:  # For each token in rights of noun
            if right_token.pos_.lower() == "adp":  # If token is adposition
                for tok1 in right_token.lefts:
                    if tok1.pos_.lower() in ["noun", "propn"]:
                        current_ners, current_pos = [], []

                        # For each token on its lefts, if it is noun or proper noun then adjectivise it and add to text list
                        if include_adjectives:
                            (
                                adjective_tok1,
                                adjective_tok1_lemma,
                                adjective_ners,
                                adjective_pos,
                            ) = self._adjectivise_noun(tok1)

                            right_adp_nouns.append(f"{adjective_tok1} {right_token.text}")
                            right_adp_nouns_lemma.append(f"{adjective_tok1_lemma}")
                            current_ners.extend(list(set(adjective_ners)))
                            current_pos.extend(list(set(adjective_pos)))

                        else:
                            right_adp_nouns.append(f"{tok1.text} {right_token.text}")
                            right_adp_nouns_lemma.append(f"{tok1.lemma_}")

                        if tok1.ent_type_:
                            current_ners.append((tok1.text, tok1.ent_type_))
                        if right_token.ent_type_:
                            current_ners.append((right_token.text, right_token.ent_type_))

                        current_pos.extend(
                            ((tok1.lemma_, tok1.pos_), (right_token.lemma_, right_token.pos_))
                        )

                        right_adp_ners.append(current_ners)
                        right_adp_pos.append(current_pos)

                        # For each token on its lefts, if it is noun or proper noun then add to adposition noun tokens list
                        right_adp_noun_tokens.append(tok1)

                for tok1 in right_token.rights:
                    if tok1.pos_.lower() in ["noun", "propn"]:
                        current_ners, current_pos = [], []

                        # For each token on its rights, if it is noun or proper noun then adjectivise it and add to text list
                        if include_adjectives:
                            (
                                adjective_tok1,
                                adjective_tok1_lemma,
                                adjective_ners,
                                adjective_pos,
                            ) = self._adjectivise_noun(tok1)

                            right_adp_nouns.append(f"{right_token.text} {adjective_tok1}")
                            right_adp_nouns_lemma.append(f"{adjective_tok1_lemma}")

                        else:
                            adjective_ners, adjective_pos = None, None
                            right_adp_nouns.append(f"{right_token.text} {tok1.text}")
                            right_adp_nouns_lemma.append(f"{tok1.lemma_}")

                        if right_token.ent_type_:
                            current_ners.append((right_token.text, right_token.ent_type_))
                        if adjective_ners:
                            current_ners.extend(list(set(adjective_ners)))
                        if tok1.ent_type_:
                            current_ners.append((tok1.text, tok1.ent_type_))

                        current_pos.append((right_token.lemma_, right_token.pos_))
                        if adjective_pos:
                            current_pos.extend(list(set(adjective_pos)))
                        current_pos.append((tok1.lemma_, tok1.pos_))

                        right_adp_ners.append(current_ners)
                        right_adp_pos.append(current_pos)

                        # For each token on its rights, if it is noun or proper noun then add to adposition noun tokens list
                        right_adp_noun_tokens.append(tok1)

        return (
            left_adp_nouns,
            right_adp_nouns,
            left_adp_nouns_lemma,
            right_adp_nouns_lemma,
            left_adp_noun_tokens,
            right_adp_noun_tokens,
            left_adp_ners,
            right_adp_ners,
            left_adp_pos,
            right_adp_pos,
        )

    def _find_conjunction(
        self, noun_to_process: spacy.tokens.token.Token, **kwargs
    ) -> List[spacy.tokens.token.Token]:
        """
        Process a noun token and recursively return a list of all conjugated nouns.

        Conjugated nouns are skipped if they are already used by another verb.

        This skip condition is controlled by skip_conjunctions list which tracks used conjunctions.

        The above list is passed as kwargs to this function.

        Parameters
        ----------
        noun_to_process : spacy.tokens.token.Token

        Returns
        -------
        list
            List of all conjugated noun tokens

        Examples
        -------
        >>> aopGenerate = AOPGenerate(merge_compound_nouns=True)
        >>> text = "Can I verify your date of birth, address and gender."
        >>> doc = aopGenerate.nlp_model(text)
        >>> aopGenerate._find_conjunction(doc[5])
            [
                address,
                gender
            ]
        """

        # If conjunctions list if not present, create it
        if "conjunctions" not in kwargs:
            kwargs["conjunctions"] = []

        if "skip_conjunctions" not in kwargs:
            kwargs["skip_conjunctions"] = []

        # Rather than progressing through the recursive function to check for conjunctions
        # Identify at the start itself if the root noun is in skip conjunction
        # If it is in skip conjunction, then it and its conjunctions are already used in other verbs elsewhere
        # Hence skip the find conjunctions function for this noun token
        if noun_to_process.i in kwargs["skip_conjunctions"]:
            return kwargs["conjunctions"], kwargs["conjunction_ners"], kwargs["conjunction_pos"]

        # For each token in lefts of noun_to_process
        for tok1 in noun_to_process.lefts:
            # If token is a noun or proper noun having a dependency of conj
            # And its not already present in skip conjunctions list,
            # Or in other words, its already used by an earlier verb
            if (
                tok1.dep_.lower() in ["conj", "appos"]
                and tok1.pos_.lower() in ["noun", "propn"]
                and tok1.i not in kwargs["skip_conjunctions"]
            ):
                kwargs["conjunctions"].append(tok1)  # Append the token to conjunctions list
                # Recursively find further conjunctions for this token.
                kwargs["conjunctions"] = self._find_conjunction(tok1, **kwargs)

        # For each token in rights of noun_to_process
        for tok1 in noun_to_process.rights:
            # If token is a noun or proper noun having a dependency of conj
            # And its not already present in skip conjunctions list,
            # Or in other words, its already used by an earlier verb
            if (
                tok1.dep_.lower() in ["conj", "appos"]
                and tok1.pos_.lower() in ["noun", "propn"]
                and tok1.i not in kwargs["skip_conjunctions"]
            ):
                kwargs["conjunctions"].append(tok1)  # Append the token to conjunctions list
                # Recursively find further conjunctions for this token.
                kwargs["conjunctions"] = self._find_conjunction(tok1, **kwargs)
        return kwargs["conjunctions"]

    def _update_skip_conjunctions(
        self, tokens: List[spacy.tokens.token.Token], **kwargs
    ) -> List[int]:
        """
        Internal function to update skip_conjunctions list.

        Skip conjunctions is a list containing ids of conjugated nouns already used for a verb and should not be used for further conjunction of other verbs.

        Parameters
        ----------
        tokens : List[spacy.tokens.token.Token]
            Noun tokens whose conjunction is to be skipped

        Returns
        -------
        List[int]
            skip conjunctions list

        Raises
        ------
        ValueError
            tokens is not a list

        Examples
        --------
        >>> aopGenerate = AOPGenerate(merge_compound_nouns=True)
        >>> text = "Can I verify your date of birth, address and gender."
        >>> doc = aopGenerate.nlp_model(text)
        >>> aopGenerate._update_skip_conjunctions([doc[2], doc[3]])
            [2, 3]
        """

        # Add skip_conjunctions list to kwargs
        if "skip_conjunctions" not in kwargs:
            kwargs["skip_conjunctions"] = []

        if not isinstance(tokens, list):
            raise ValueError("Tokens must be a list")

        kwargs["skip_conjunctions"].extend(token.i for token in tokens)
        return kwargs["skip_conjunctions"]

    def _process_noun(
        self,
        token_: spacy.tokens.token.Token,
        include_adjectives: Optional[bool] = True,
        include_noun_adpositions: Optional[bool] = True,
        include_conjunctions: Optional[bool] = True,
        **kwargs,
    ) -> Tuple[List[str], List[str], List[int], List[Tuple[str, str]], List[Tuple[str, str]]]:
        """
        For a single noun there are 3 possible noun pairs available:

        1. Adjective + Noun (Red Door)
        2. Noun + Adposition + Noun (Date of Birth)
        3. For a verb -> noun1 -> noun2, since there is no direct connection between verb and noun2,
           if there is a conjunction dependency between noun1 and noun2, then we return both noun1 and noun2.
           Example: 'Can I verify your date of birth and address' returns both 'date of birth' and 'address'.

        All the above 3 types of nouns are returned as a list.

        Takes a single noun token as input and adds adjectives to it.

        It also finds adposition noun pairs and adds corresponding adj to them as well.

        Conjunction nouns found recursively are also added to the list.

        Parameters
        ----------
        token_ : spacy.tokens.token.Token
            Spacy noun token

        include_adjectives : bool, optional, default-True
            If nouns need to be adjectivised

        include_noun_adpositions : bool, optional, default-True
            If noun adpositions need to be included

        include_conjunctions : bool, optional, default-True
            If conjunction nouns need to be included

        Returns
        -------
        List[str]
            List of all possible nouns

        List[str]
            List of all possible noun lemmas

        List[int]
            Spacy document id for skip conjunctions

        List[Tuple[str, str]]
            List of noun entities

        List[Tuple[str, str]]
            List of their pos tags

        Raises
        ------
        ValueError
            Token is not a noun or proper noun

        Examples
        --------
        >>> aopGenerate = AOPGenerate(merge_compound_nouns=True)
        >>> text = "Can I verify your date of birth, address and gender."
        >>> doc = aopGenerate.nlp_model(text)
        >>> aopGenerate._process_noun(doc[3])
            (
                ['your date of birth', 'address', 'gender'],
                ['your date of birth', 'address', 'gender'],
                [7, 9],
                [[], [], []],
                [
                    [('your date', 'NOUN'), ('of', 'ADP'), ('birth', 'NOUN')],
                    [('address', 'NOUN')],
                    [('gender', 'NOUN')]
                ]
            )
        """

        # During recursion conjunction is False as we already extract all the possible conjunctions before hand.
        # Making it true would result in duplicate nouns.
        # The recursion is run only to identify adjectives and adpositions.

        # Make sure the token is a noun or proper noun
        if token_.pos_.lower() not in ["noun", "propn"]:
            raise ValueError("Token needs to be either noun or proper noun.")

        # Add all_nouns list to kwargs
        if "all_nouns" not in kwargs:
            kwargs["all_nouns"] = []

        # Add all_nouns_lemma list to kwargs
        if "all_nouns_lemma" not in kwargs:
            kwargs["all_nouns_lemma"] = []

        # Add all_ners list to kwargs
        if "all_ners" not in kwargs:
            kwargs["all_ners"] = []

        # Add all_pos list to kwargs
        if "all_pos" not in kwargs:
            kwargs["all_pos"] = []

        # Add skip_conjunctions list to kwargs
        if "skip_conjunctions" not in kwargs:
            kwargs["skip_conjunctions"] = []

        # Set noun string to text version of token
        noun = token_.text
        noun_lemma = token_.lemma_

        # Declare noun adjective ners and pos so if adjectives are False it wouldn't raise an error
        token_noun_adjective_ners, token_noun_adjective_pos = None, None
        # If adjectives are to be considered
        if include_adjectives:
            # Get all adjectives for the noun and add to noun string defined above
            (
                noun,
                noun_lemma,
                token_noun_adjective_ners,
                token_noun_adjective_pos,
            ) = self._adjectivise_noun(token_)

        # If noun positions are to be included
        if include_noun_adpositions:
            # Extract noun adpositions and their respective tokens
            # Tokens are noun postions are extracted to check for conjunctions
            # Left and right entities and pos are extracted
            (
                left_adposition_nouns,
                right_adposition_nouns,
                left_adposition_nouns_lemma,
                right_adposition_nouns_lemma,
                left_adp_noun_tokens,
                right_adp_noun_tokens,
                left_adp_ners,
                right_adp_ners,
                left_adp_pos,
                right_adp_pos,
            ) = self._get_noun_adpositions(token_, include_adjectives=include_adjectives)
            # Left adposition nouns or right adposition nouns exist
            if left_adposition_nouns or right_adposition_nouns:
                # Add left adposition noun string to noun string declared above and add to nouns list
                # Add left adposition entities and pos to their respective lists
                for (
                    left_adposition_noun,
                    left_adposition_noun_lemma,
                    left_adposition_ner,
                    left_adposition_pos,
                ) in zip(
                    left_adposition_nouns, left_adposition_nouns_lemma, left_adp_ners, left_adp_pos
                ):
                    kwargs["all_nouns"].append(f"{left_adposition_noun} {noun}".strip())
                    kwargs["all_nouns_lemma"].append(
                        f"{left_adposition_noun_lemma} {noun_lemma}".strip()
                    )
                    if token_noun_adjective_ners:
                        left_adposition_ner.extend(token_noun_adjective_ners)
                    if token_.ent_type_:
                        left_adposition_ner.append((token_.text, token_.ent_type_))
                    kwargs["all_ners"].append(left_adposition_ner)
                    if token_noun_adjective_pos:
                        left_adposition_pos.extend(token_noun_adjective_pos)
                    left_adposition_pos.append((token_.lemma_, token_.pos_))
                    kwargs["all_pos"].append(left_adposition_pos)

                # Add right adposition noun string to noun string declared above and add to nouns list
                # Add right adposition entities and pos to their respective lists
                # Also ordering of noun adposition is preserved
                for (
                    right_adposition_noun,
                    right_adposition_noun_lemma,
                    right_adposition_ner,
                    right_adposition_pos,
                ) in zip(
                    right_adposition_nouns,
                    right_adposition_nouns_lemma,
                    right_adp_ners,
                    right_adp_pos,
                ):
                    kwargs["all_nouns"].append(f"{noun} {right_adposition_noun}".strip())
                    kwargs["all_nouns_lemma"].append(
                        f"{noun_lemma} {right_adposition_noun_lemma}".strip()
                    )
                    if token_.ent_type_:
                        right_adposition_ner = [
                            (token_.text, token_.ent_type_)
                        ] + right_adposition_ner
                    if token_noun_adjective_ners:
                        right_adposition_ner = token_noun_adjective_ners + right_adposition_ner
                    kwargs["all_ners"].append(right_adposition_ner)
                    right_adposition_pos = [(token_.lemma_, token_.pos_)] + right_adposition_pos
                    if token_noun_adjective_pos:
                        right_adposition_pos = token_noun_adjective_pos + right_adposition_pos
                    kwargs["all_pos"].append(right_adposition_pos)

                # If conjunctions need to be extracted
                if include_conjunctions:
                    # For token in left adposition noun tokens
                    for left_tok in left_adp_noun_tokens:
                        # Find all the respective conjunctions
                        conjugated_nouns = self._find_conjunction(left_tok, **kwargs)
                        # Since these conjunctions will be used with the verb in question
                        # Add these conjunctions to skip conjunctions list so they will not be used for other verbs.
                        kwargs["skip_conjunctions"] = self._update_skip_conjunctions(
                            conjugated_nouns, **kwargs
                        )
                        for conjugated_noun in conjugated_nouns:
                            # For each of these conjunction nouns, adjectivise and add adpositions
                            (
                                kwargs["all_nouns"],
                                kwargs["all_nouns_lemma"],
                                _,
                                kwargs["all_ners"],
                                kwargs["all_pos"],
                            ) = self._process_noun(
                                conjugated_noun,
                                include_adjectives=include_adjectives,
                                include_noun_adpositions=include_noun_adpositions,
                                include_conjunctions=False,
                                **kwargs,
                            )
                    # For token in right adposition noun tokens
                    for right_tok in right_adp_noun_tokens:
                        # Find all the respective conjunctions
                        conjugated_nouns = self._find_conjunction(right_tok, **kwargs)
                        # Since these conjunctions will be used with the verb in question
                        # Add these conjunctions to skip conjunctions list so they will not be used for other verbs.
                        kwargs["skip_conjunctions"] = self._update_skip_conjunctions(
                            conjugated_nouns, **kwargs
                        )
                        for conjugated_noun in conjugated_nouns:
                            # For each of these conjunction nouns, adjectivise and add adpositions
                            (
                                kwargs["all_nouns"],
                                kwargs["all_nouns_lemma"],
                                _,
                                kwargs["all_ners"],
                                kwargs["all_pos"],
                            ) = self._process_noun(
                                conjugated_noun,
                                include_adjectives=include_adjectives,
                                include_noun_adpositions=include_noun_adpositions,
                                include_conjunctions=False,
                                **kwargs,
                            )
            else:
                # If there are no left or right adpositions, directly append noun string to list of nouns
                kwargs["all_nouns"].append(noun)
                kwargs["all_nouns_lemma"].append(noun_lemma)
                ners = token_noun_adjective_ners or []
                if token_.ent_type_:
                    ners.append((token_.text, token_.ent_type_))
                kwargs["all_ners"].append(ners)
                pos = token_noun_adjective_pos or []
                pos.append((token_.lemma_, token_.pos_))
                kwargs["all_pos"].append(pos)
        else:
            # If adpositions are not to be included, directly append noun string to list of nouns
            kwargs["all_nouns"].append(noun)
            kwargs["all_nouns_lemma"].append(noun_lemma)
            ners = token_noun_adjective_ners or []
            if token_.ent_type_:
                ners.append((token_.text, token_.ent_type_))
            kwargs["all_ners"].append(ners)
            pos = token_noun_adjective_pos or []
            pos.append((token_.lemma_, token_.pos_))
            kwargs["all_pos"].append(pos)

        # If conjunctions need to be extracted
        if include_conjunctions:
            # Find all the respective conjunctions
            conjugated_nouns = self._find_conjunction(token_, **kwargs)
            # Since these conjunctions will be used with the verb in question
            # Add these conjunctions to skip conjunctions list so they will not be used for other verbs.
            kwargs["skip_conjunctions"] = self._update_skip_conjunctions(
                conjugated_nouns, **kwargs
            )
            for conjugated_noun in conjugated_nouns:
                # For each of these conjunction nouns, adjectivise and add adpositions
                (
                    kwargs["all_nouns"],
                    kwargs["all_nouns_lemma"],
                    _,
                    kwargs["all_ners"],
                    kwargs["all_pos"],
                ) = self._process_noun(
                    conjugated_noun,
                    include_adjectives=include_adjectives,
                    include_noun_adpositions=include_noun_adpositions,
                    include_conjunctions=False,
                    **kwargs,
                )

        return (
            kwargs["all_nouns"],
            kwargs["all_nouns_lemma"],
            kwargs["skip_conjunctions"],
            kwargs["all_ners"],
            kwargs["all_pos"],
        )

    def _return_text_lemma_entity_pos_from_token(
        self, token
    ) -> Tuple[str, str, Union[List, List[Tuple[str, str]]], List[Tuple[str, str]]]:
        """
        Return text, lemma, entity and pos associated with given token

        Parameters
        ----------
        token : spacy.tokens.token.Token
            Spacy token for text, lemma, entity and pos generation

        Returns
        -------
        str
            Text associated with given token

        str
            Lemma text associated with given token

        Union[List, List[Tuple[str, str]]]
            Empty List in case no entitiy is found else list of tuples containing text and entity

        List[Tuple[str, str]]
            List of tuples containing text and pos tags

        Examples
        --------
        >>> aopGenerate = AOPGenerate(merge_compound_nouns=True)
        >>> text = "Can I verify your date of birth, address and gender."
        >>> doc = aopGenerate.nlp_model(text)
        >>> aopGenerate._return_text_lemma_entity_pos_from_token(doc[2])
            (
                'verify',
                'verify',
                [],
                [('verify', 'VERB')]
            )
        """

        text = token.text
        lemma = token.lemma_
        ent = [(token.text, token.ent_type_)] if token.ent_type_ else []
        pos = [(token.lemma_, token.pos_)]
        return text, lemma, ent, pos

    def _remove_duplicates_from_list(
        self, list_of_tuples: List[Tuple[str, str]]
    ) -> List[Tuple[str, str]]:
        """Given a list of tuples, remove duplicates efficiently by keeping ordering

        Parameters
        ----------
        list_of_tuples : List[Tuple[str, str]]
            List of tuples to remove duplicates from

        Returns
        -------
        List[Tuple[str, str]]
            List of unique tuples with ordering intact

        Examples
        --------
        >>> aopGenerate = AOPGenerate(merge_compound_nouns=True)
        >>> aopGenerate._remove_duplicates_from_list([('orange', 'apple'),
                                                      ('apple', 'pears'),
                                                      ('orange', 'apple'),
                                                      ('mango', 'banana'),
                                                      ('apple', 'orange')])
            [
                ('orange', 'apple'),
                ('apple', 'pears'),
                ('mango', 'banana'),
                ('apple', 'orange')
            ]
        """
        seen = set()
        unique_data = []
        for tup in list_of_tuples:
            if tup not in seen:
                unique_data.append(tup)
                seen.add(tup)
        return unique_data

    def process(
        self,
        text: str,
        include_core_dependencies: Optional[bool] = True,
        include_adjectives: Optional[bool] = True,
        include_verb_adpositions: Optional[bool] = True,
        include_noun_adpositions: Optional[bool] = True,
        include_noun_conjunctions: Optional[bool] = True,
        additional_noun_verb_deps: Optional[List[str]] = None,
        **kwargs,
    ) -> List[Dict[str, Union[Tuple, List]]]:
        """Process the given text to generate list of consecutive verb noun pairs

        Parameters
        ----------
        text : str
            Text to be processed

        include_core_dependencies: bool, optional, default-True
            If core dependencies between noun and verb i.e. "nsubj", "nsubjpass", "dobj" need to be included

        include_adjectives : bool, optional, default-True
            If adjectives need to be included for the noun.

        include_verb_adpositions : bool, optional, default-True
            If adpositions need to be included for the verb noun pair.

            For example if we had a sentence containing 'made with apples'

            Here 'made' is a verb, 'with' is an adposition and 'apples' is a noun.

            Initially as there would be no direct connection between made and apples, this pair would be ignored.

            If this parameter is set to True, then the pair of ('made with', 'apples') would be included.

        include_noun_adpositions : bool, optional, default-True
            If adpositions need to be included for the noun.

            For example if we had a sentence containing 'date of birth'

            Here 'date' is a noun, 'of' is an adposition and 'birth' is a noun.

            If this parameter is set to True, the whole of 'date of birth' will be considered as a single noun

        include_noun_conjunctions : bool, optional, default-True
            If conjunctions need to be included for the noun.

            For a verb -> noun1 -> noun2, since there is no direct connection between verb and noun2,

            if there is a conjunction dependency between noun1 and noun2,

            then we use both noun1 and noun2 as (verb, noun1), (verb, noun2).

            Example: 'Can I verify your date of birth and address'

            Returns both ('verify', 'date of birth') and ('verify', 'address').

        additional_noun_verb_deps : List[str], optional, default-None
            Any other additional dependencies from https://universaldependencies.org/docs/en/dep/ are supported.
            They can be passed as a list of strings and all the verb noun connections having said dependency will be extracted as part of output.

        Returns
        -------
        List[Dict[str, Union[Tuple, List]]]
            List of dictionaries for each action object pair

        Raises
        ------
        ValueError
            If text is not a string

        Examples
        -----
        >>> from tigernlp.action_object_pairs.api import AOPGenerate
        >>> aopGenerate = AOPGenerate(merge_compound_nouns=True)
        >>> aopGenerate.process('Can I verify your date of birth and address')
            [
                {
                    'pairs': ('verify', 'your date of birth'),
                    'named_entities': [],
                    'pairs_pos_lemma': [
                        ('verify', 'VERB'),
                        ('your date', 'NOUN'),
                        ('of', 'ADP'),
                        ('birth', 'NOUN')],
                    'pairs_lemma': ('verify', 'your date birth')
                },
                {
                    'pairs': ('verify', 'address'),
                    'named_entities': [],
                    'pairs_pos_lemma': [
                        ('verify', 'VERB'),
                        ('address', 'NOUN')],
                    'pairs_lemma': ('verify', 'address')
                }
            ]
        """

        if not isinstance(text, str):
            raise ValueError("Text must be in string format")

        # Add skip conjunctions list to kwargs
        if "skip_conjunctions" not in kwargs:
            kwargs["skip_conjunctions"] = []

        # Add additional_noun_verb_deps list to kwargs
        if additional_noun_verb_deps is None:
            additional_noun_verb_deps = []
        elif not isinstance(additional_noun_verb_deps, list):
            raise ValueError(
                f"additional_noun_verb_deps must be a list. Received {type(additional_noun_verb_deps)}."
            )

        additional_noun_verb_deps = [str(dep).lower() for dep in additional_noun_verb_deps]

        # If doc exists in kwargs, if its not a spacy Doc object, set it to None
        if "doc" in kwargs and not isinstance(kwargs["doc"], spacy.tokens.doc.Doc):
            kwargs["doc"] = None

        # Generate doc if its standalone text
        # Otherwise take doc from kwargs especially when batch processing on pandas dataframe
        doc = self.nlp_model(text) if "doc" not in kwargs or not kwargs["doc"] else kwargs["doc"]

        pairs = []
        for token_ in doc:  # For each phrase or token in the document
            # If pos of the token is either a noun or a proper noun
            if token_.pos_.lower() in [
                "noun",
                "propn",
            ]:
                if (
                    token_.dep_.lower() in ["nsubj", "nsubjpass"]
                    and token_.head.pos_.lower() == "verb"
                    and include_core_dependencies
                ):  # If the dependency of the token is nsubj and the pos of the head is a verb
                    # And if base noun dependencies (nsubj, nsubjpass, dobj) are to be included
                    # Get all possible nouns, lemma and their respective ners and pos
                    (
                        all_nouns,
                        all_nouns_lemma,
                        kwargs["skip_conjunctions"],
                        all_ners,
                        all_pos,
                    ) = self._process_noun(
                        token_,
                        include_adjectives=include_adjectives,
                        include_noun_adpositions=include_noun_adpositions,
                        include_conjunctions=include_noun_conjunctions,
                        **kwargs,
                    )

                    # For each noun, noun lemma, entity and pos
                    for noun, noun_lemma, ner, pos in zip(
                        all_nouns, all_nouns_lemma, all_ners, all_pos
                    ):
                        # Get verb text, verb lemma entity and pos from token id
                        (
                            verb_text,
                            verb_lemma,
                            verb_ner,
                            verb_pos,
                        ) = self._return_text_lemma_entity_pos_from_token(token_.head)
                        pairs.append(
                            {
                                # We add noun first followed by verb
                                "pairs": (
                                    noun,
                                    verb_text,
                                ),  # Add verb noun pair to list of subject verb pairs
                                "named_entities": self._remove_duplicates_from_list(
                                    ner + verb_ner
                                ),  # Adds entities of verb and noun and removes duplicate tuples
                                "pairs_pos_lemma": self._remove_duplicates_from_list(
                                    pos + verb_pos
                                ),
                                # Adds pos of verb and noun and removes duplicate tuples
                                "pairs_lemma": (verb_lemma, noun_lemma),
                                # Add verb noun lemma pair to list of subject verb pairs
                            }
                        )

                elif (
                    token_.dep_.lower() == "dobj"
                    and token_.head.pos_.lower() == "verb"
                    and include_core_dependencies
                ):  # If the dependency of the token is dobj and the pos of the head is a verb
                    # And if base noun dependencies (nsubj, nsubjpass, dobj) are to be included
                    # Get all possible nouns and their respective ners and pos
                    (
                        all_nouns,
                        all_nouns_lemma,
                        kwargs["skip_conjunctions"],
                        all_ners,
                        all_pos,
                    ) = self._process_noun(
                        token_,
                        include_adjectives=include_adjectives,
                        include_noun_adpositions=include_noun_adpositions,
                        include_conjunctions=include_noun_conjunctions,
                        **kwargs,
                    )

                    # For each noun, entity and pos
                    for noun, noun_lemma, ner, pos in zip(
                        all_nouns, all_nouns_lemma, all_ners, all_pos
                    ):
                        # Get verb text, verb lemma entity and pos from token id
                        (
                            verb_text,
                            verb_lemma,
                            verb_ner,
                            verb_pos,
                        ) = self._return_text_lemma_entity_pos_from_token(token_.head)
                        pairs.append(
                            {
                                # We add verb first followed by noun
                                "pairs": (
                                    verb_text,
                                    noun,
                                ),  # Add verb noun pair to list of subject verb pairs
                                "named_entities": self._remove_duplicates_from_list(
                                    verb_ner + ner
                                ),  # Adds entities of verb and noun and removes duplicate tuples
                                "pairs_pos_lemma": self._remove_duplicates_from_list(
                                    verb_pos + pos
                                ),
                                # Adds pos of verb and noun and removes duplicate tuples
                                "pairs_lemma": (verb_lemma, noun_lemma),
                                # Add verb noun lemma pair to list of subject verb pairs
                            }
                        )

                elif (
                    token_.dep_.lower() in additional_noun_verb_deps
                    and token_.head.pos_.lower() == "verb"
                ):  # If the pos of the head is a verb and dependency exists in additional_noun_verb_deps
                    # Get all possible nouns and their respective ners and pos
                    (
                        all_nouns,
                        all_nouns_lemma,
                        kwargs["skip_conjunctions"],
                        all_ners,
                        all_pos,
                    ) = self._process_noun(
                        token_,
                        include_adjectives=include_adjectives,
                        include_noun_adpositions=include_noun_adpositions,
                        include_conjunctions=include_noun_conjunctions,
                        **kwargs,
                    )

                    # For each noun, entity and pos
                    for noun, noun_lemma, ner, pos in zip(
                        all_nouns, all_nouns_lemma, all_ners, all_pos
                    ):
                        # Get verb text, verb lemma entity and pos from token id
                        (
                            verb_text,
                            verb_lemma,
                            verb_ner,
                            verb_pos,
                        ) = self._return_text_lemma_entity_pos_from_token(token_.head)
                        pairs.append(
                            {  # We add verb first followed by noun
                                "pairs": (
                                    verb_text,
                                    noun,
                                ),  # Add verb noun pair to list of subject verb pairs
                                "named_entities": self._remove_duplicates_from_list(
                                    verb_ner + ner
                                ),  # Adds entities of verb and noun and removes duplicate tuples
                                "pairs_pos_lemma": self._remove_duplicates_from_list(
                                    verb_pos + pos
                                ),
                                # Adds pos of verb and noun and removes duplicate tuples
                                "pairs_lemma": (verb_lemma, noun_lemma),
                                # Add verb noun lemma pair to list of subject verb pairs
                            }
                        )

            elif token_.pos_.lower() == "verb":  # If pos is a verb
                if (
                    token_.dep_.lower() in additional_noun_verb_deps
                    and token_.head.pos_.lower() in ["noun", "propn"]
                ):
                    # If the dependency of the token is in additional_noun_verb_deps
                    # and the pos of the head is either a noun or a proper noun
                    # Get all possible nouns and their respective ners and pos
                    (
                        all_nouns,
                        all_nouns_lemma,
                        kwargs["skip_conjunctions"],
                        all_ners,
                        all_pos,
                    ) = self._process_noun(
                        token_.head,
                        include_adjectives=include_adjectives,
                        include_noun_adpositions=include_noun_adpositions,
                        include_conjunctions=include_noun_conjunctions,
                        **kwargs,
                    )

                    # For each noun, entity and pos
                    for noun, noun_lemma, ner, pos in zip(
                        all_nouns, all_nouns_lemma, all_ners, all_pos
                    ):
                        # Get verb text, verb lemma entity and pos from token id
                        (
                            verb_text,
                            verb_lemma,
                            verb_ner,
                            verb_pos,
                        ) = self._return_text_lemma_entity_pos_from_token(token_)

                        pairs.append(
                            {  # We add noun first followed by verb
                                "pairs": (
                                    noun,
                                    verb_text,
                                ),  # Add verb noun pair to list of subject verb pairs
                                "named_entities": self._remove_duplicates_from_list(
                                    ner + verb_ner
                                ),  # Adds entities of verb and noun and removes duplicate tuples
                                "pairs_pos_lemma": self._remove_duplicates_from_list(
                                    pos + verb_pos
                                ),
                                # Adds pos of verb and noun and removes duplicate tuples
                                "pairs_lemma": (verb_lemma, noun_lemma),
                                # Add verb noun lemma pair to list of subject verb pairs
                            }
                        )

                # If verb adpositions are to be included
                if include_verb_adpositions:
                    # For token in left of the main token
                    for left_token in token_.lefts:
                        # If the pos of the left token is an adposition
                        if left_token.pos_.lower() == "adp":
                            for tok1 in left_token.lefts:  # For all tokens on lefts of left token
                                if tok1.pos_.lower() in [
                                    "noun",
                                    "propn",
                                ]:  # If token is a noun or proper noun
                                    # Get all possible nouns, lemmas and their respective ners and pos
                                    (
                                        all_nouns,
                                        all_nouns_lemma,
                                        kwargs["skip_conjunctions"],
                                        all_ners,
                                        all_pos,
                                    ) = self._process_noun(
                                        tok1,
                                        include_adjectives=include_adjectives,
                                        include_noun_adpositions=include_noun_adpositions,
                                        include_conjunctions=include_noun_conjunctions,
                                        **kwargs,
                                    )

                                    # For each noun, lemma, entity and pos
                                    for noun, noun_lemma, ner, pos in zip(
                                        all_nouns, all_nouns_lemma, all_ners, all_pos
                                    ):
                                        # Get adp + verb text and lemma
                                        adp_verb_text = f"{left_token.text} {token_.text}"
                                        adp_verb_lemma = f"{token_.lemma_}"

                                        # Get adp entitiy and pos from token id
                                        (
                                            _,
                                            _,
                                            adp_ner,
                                            adp_pos,
                                        ) = self._return_text_lemma_entity_pos_from_token(
                                            left_token
                                        )

                                        # Get verb entitiy and pos from token id
                                        (
                                            _,
                                            _,
                                            verb_ner,
                                            verb_pos,
                                        ) = self._return_text_lemma_entity_pos_from_token(token_)

                                        pairs.append(
                                            {  # We add noun first followed by verb
                                                "pairs": (
                                                    noun,
                                                    adp_verb_text,
                                                ),  # Add verb noun pair to list of subject verb pairs
                                                "named_entities": self._remove_duplicates_from_list(
                                                    ner + adp_ner + verb_ner
                                                ),  # Adds entities of verb and noun and removes duplicate tuples
                                                "pairs_pos_lemma": self._remove_duplicates_from_list(
                                                    pos + adp_pos + verb_pos
                                                ),
                                                # Adds pos of verb and noun and removes duplicate tuples
                                                "pairs_lemma": (adp_verb_lemma, noun_lemma),
                                                # Add verb noun lemma pair to list of subject verb pairs
                                            }
                                        )

                            for (
                                tok1
                            ) in left_token.rights:  # For all tokens on rights of left token
                                if tok1.pos_.lower() in [
                                    "noun",
                                    "propn",
                                ]:  # If token is a noun or proper noun
                                    # Get all possible nouns and their respective ners and pos
                                    (
                                        all_nouns,
                                        all_nouns_lemma,
                                        kwargs["skip_conjunctions"],
                                        all_ners,
                                        all_pos,
                                    ) = self._process_noun(
                                        tok1,
                                        include_adjectives=include_adjectives,
                                        include_noun_adpositions=include_noun_adpositions,
                                        include_conjunctions=include_noun_conjunctions,
                                        **kwargs,
                                    )

                                    # For each noun, entity and pos
                                    for noun, noun_lemma, ner, pos in zip(
                                        all_nouns, all_nouns_lemma, all_ners, all_pos
                                    ):
                                        # Get adp + verb text
                                        adp_verb_text = f"{left_token.text} {token_.text}"
                                        adp_verb_lemma = f"{token_.lemma_}"

                                        # Get adp entitiy and pos from token id
                                        (
                                            _,
                                            _,
                                            adp_ner,
                                            adp_pos,
                                        ) = self._return_text_lemma_entity_pos_from_token(
                                            left_token
                                        )

                                        # Get verb entitiy and pos from token id
                                        (
                                            _,
                                            _,
                                            verb_ner,
                                            verb_pos,
                                        ) = self._return_text_lemma_entity_pos_from_token(token_)

                                        pairs.append(
                                            {  # We add noun first followed by verb
                                                "pairs": (
                                                    noun,
                                                    adp_verb_text,
                                                ),  # Add verb noun pair to list of subject verb pairs
                                                "named_entities": self._remove_duplicates_from_list(
                                                    ner + adp_ner + verb_ner
                                                ),  # Adds entities of verb and noun and removes duplicate tuples
                                                "pairs_pos_lemma": self._remove_duplicates_from_list(
                                                    pos + adp_pos + verb_pos
                                                ),
                                                # Adds pos of verb and noun and removes duplicate tuples
                                                "pairs_lemma": (adp_verb_lemma, noun_lemma),
                                                # Add verb noun lemma pair to list of subject verb pairs
                                            }
                                        )

                    # For token in right of the main token
                    for right_token in token_.rights:
                        # If the pos of the right token is an adposition
                        if right_token.pos_.lower() == "adp":
                            for (
                                tok1
                            ) in right_token.lefts:  # For all tokens on lefts of right token
                                if tok1.pos_.lower() in [
                                    "noun",
                                    "propn",
                                ]:  # If token is a noun or proper noun
                                    # Get all possible nouns and their respective ners and pos
                                    (
                                        all_nouns,
                                        all_nouns_lemma,
                                        kwargs["skip_conjunctions"],
                                        all_ners,
                                        all_pos,
                                    ) = self._process_noun(
                                        tok1,
                                        include_adjectives=include_adjectives,
                                        include_noun_adpositions=include_noun_adpositions,
                                        include_conjunctions=include_noun_conjunctions,
                                        **kwargs,
                                    )

                                    # For each noun, entity and pos
                                    for noun, noun_lemma, ner, pos in zip(
                                        all_nouns, all_nouns_lemma, all_ners, all_pos
                                    ):
                                        # Get adp + verb text and lemma
                                        adp_verb_text = f"{token_.text} {right_token.text}"
                                        adp_verb_lemma = f"{token_.lemma_}"

                                        # Get adp entitiy and pos from token id
                                        (
                                            _,
                                            _,
                                            adp_ner,
                                            adp_pos,
                                        ) = self._return_text_lemma_entity_pos_from_token(
                                            right_token
                                        )

                                        # Get verb entitiy and pos from token id
                                        (
                                            _,
                                            _,
                                            verb_ner,
                                            verb_pos,
                                        ) = self._return_text_lemma_entity_pos_from_token(token_)

                                        pairs.append(
                                            {  # We add verb first followed by noun
                                                "pairs": (
                                                    adp_verb_text,
                                                    noun,
                                                ),  # Add verb noun pair to list of subject verb pairs
                                                "named_entities": self._remove_duplicates_from_list(
                                                    verb_ner + adp_ner + ner
                                                ),  # Adds entities of verb and noun and removes duplicate tuples
                                                "pairs_pos_lemma": self._remove_duplicates_from_list(
                                                    verb_pos + adp_pos + pos
                                                ),
                                                # Adds pos of verb and noun and removes duplicate tuples
                                                "pairs_lemma": (adp_verb_lemma, noun_lemma),
                                                # Add verb noun lemma pair to list of subject verb pairs
                                            }
                                        )

                            for (
                                tok1
                            ) in right_token.rights:  # For all tokens on rights of right token
                                if tok1.pos_.lower() in [
                                    "noun",
                                    "propn",
                                ]:  # If token is a noun or proper noun
                                    # Get all possible nouns and their respective ners and pos
                                    (
                                        all_nouns,
                                        all_nouns_lemma,
                                        kwargs["skip_conjunctions"],
                                        all_ners,
                                        all_pos,
                                    ) = self._process_noun(
                                        tok1,
                                        include_adjectives=include_adjectives,
                                        include_noun_adpositions=include_noun_adpositions,
                                        include_conjunctions=include_noun_conjunctions,
                                        **kwargs,
                                    )

                                    # For each noun, entity and pos
                                    for noun, noun_lemma, ner, pos in zip(
                                        all_nouns, all_nouns_lemma, all_ners, all_pos
                                    ):
                                        # Get adp + verb text
                                        adp_verb_text = f"{token_.text} {right_token.text}"
                                        adp_verb_lemma = f"{token_.lemma_}"

                                        # Get adp entitiy and pos from token id
                                        (
                                            _,
                                            _,
                                            adp_ner,
                                            adp_pos,
                                        ) = self._return_text_lemma_entity_pos_from_token(
                                            right_token
                                        )

                                        # Get verb entitiy and pos from token id
                                        (
                                            _,
                                            _,
                                            verb_ner,
                                            verb_pos,
                                        ) = self._return_text_lemma_entity_pos_from_token(token_)
                                        pairs.append(
                                            {  # We add verb first followed by noun
                                                "pairs": (
                                                    adp_verb_text,
                                                    noun,
                                                ),  # Add verb noun pair to list of subject verb pairs
                                                "named_entities": self._remove_duplicates_from_list(
                                                    verb_ner + adp_ner + ner
                                                ),  # Adds entities of verb and noun and removes duplicate tuples
                                                "pairs_pos_lemma": self._remove_duplicates_from_list(
                                                    verb_pos + adp_pos + pos
                                                ),
                                                # Adds pos of verb and noun and removes duplicate tuples
                                                "pairs_lemma": (adp_verb_lemma, noun_lemma),
                                                # Add verb noun lemma pair to list of subject verb pairs
                                            }
                                        )

        return pairs

    @contextlib.contextmanager
    def _tqdm_joblib(self, tqdm_object):
        """
        https://stackoverflow.com/a/58936697
        Context manager to patch joblib to report into tqdm progress bar given as argument
        """

        class TqdmBatchCompletionCallback(joblib.parallel.BatchCompletionCallBack):
            def __call__(self, *args, **kwargs):
                tqdm_object.update(n=self.batch_size)
                return super().__call__(*args, **kwargs)

        old_batch_callback = joblib.parallel.BatchCompletionCallBack
        joblib.parallel.BatchCompletionCallBack = TqdmBatchCompletionCallback
        try:
            yield tqdm_object
        finally:
            joblib.parallel.BatchCompletionCallBack = old_batch_callback
            tqdm_object.close()

    def _chunker(self, iterable, total_length: int, chunksize: int):
        """Returns a chunk of data from given length and chunksize"""
        return (iterable[pos : pos + chunksize] for pos in range(0, total_length, chunksize))

    def _flatten(self, list_of_lists):
        """Flatten a list of lists to a combined list"""
        return [item for sublist in list_of_lists for item in sublist]

    def _process_function(
        self,
        texts: pd.Series,
        nlp_pipe_batch_size: Optional[int] = 10,
        include_core_dependencies: Optional[bool] = True,
        include_adjectives: Optional[bool] = True,
        include_verb_adpositions: Optional[bool] = True,
        include_noun_adpositions: Optional[bool] = True,
        include_noun_conjunctions: Optional[bool] = True,
        additional_noun_verb_deps: Optional[List[str]] = None,
        **kwargs,
    ) -> List[List[Dict[str, Union[Tuple, List]]]]:
        """
        This function will be run parallely by joblib for multiple pandas series objects

        Parameters
        ----------
        texts : pd.Series
            Series object of the cleaned text column

        nlp_pipe_batch_size: int, optional, default-10
            How many rows to be batch processed by spacy nlp pipeline

        include_core_dependencies: bool, optional, default-True
            If core dependencies between noun and verb i.e. "nsubj", "nsubjpass", "dobj" need to be included

        include_adjectives : bool, optional, default-True
            If adjectives need to be included for the noun.

        include_verb_adpositions : bool, optional, default-True
            If adpositions need to be included for the verb noun pair.

            For example if we had a sentence containing 'made with apples'

            Here 'made' is a verb, 'with' is an adposition and 'apples' is a noun.

            Initially as there would be no direct connection between made and apples, this pair would be ignored.

            If this parameter is set to True, then the pair of ('made with', 'apples') would be included.

        include_noun_adpositions : bool, optional, default-True
            If adpositions need to be included for the noun.

            For example if we had a sentence containing 'date of birth'

            Here 'date' is a noun, 'of' is an adposition and 'birth' is a noun.

            If this parameter is set to True, the whole of 'date of birth' will be considered as a single noun

        include_noun_conjunctions : bool, optional, default-True
            If conjunctions need to be included for the noun.

            For a verb -> noun1 -> noun2, since there is no direct connection between verb and noun2,

            if there is a conjunction dependency between noun1 and noun2,

            then we use both noun1 and noun2 as (verb, noun1), (verb, noun2).

            Example: 'Can I verify your date of birth and address'

            Returns both ('verify', 'date of birth') and ('verify', 'address').

        additional_noun_verb_deps : List[str], optional, default-None
            Any other additional dependencies from https://universaldependencies.org/docs/en/dep/ are supported.
            They can be passed as a list of strings and all the verb noun connections having said dependency will be extracted as part of output.

        Returns
        -------
        List[List[Dict[str, Union[Tuple, List]]]]
            List of lists containing one dictionary for each subject verb pair found in each row of pandas series
        """
        process_pipe = []
        for doc, text in zip(
            self.nlp_model.pipe(texts, batch_size=nlp_pipe_batch_size), texts.values
        ):
            kwargs["doc"] = doc
            process_pipe.append(
                self.process(
                    text,
                    include_core_dependencies=include_core_dependencies,
                    include_adjectives=include_adjectives,
                    include_verb_adpositions=include_verb_adpositions,
                    include_noun_adpositions=include_noun_adpositions,
                    include_noun_conjunctions=include_noun_conjunctions,
                    additional_noun_verb_deps=additional_noun_verb_deps,
                    **kwargs,
                )
            )
        return process_pipe

    def _joblib_parallel_process(
        self,
        texts: pd.Series,
        backend: Optional[str] = "multiprocessing",
        prefer: Optional[str] = "processes",
        chunksize: Optional[int] = 100,
        n_jobs: Optional[int] = -1,
        nlp_pipe_batch_size: Optional[int] = 10,
        show_progress: Optional[bool] = True,
        include_core_dependencies: Optional[bool] = True,
        include_adjectives: Optional[bool] = True,
        include_verb_adpositions: Optional[bool] = True,
        include_noun_adpositions: Optional[bool] = True,
        include_noun_conjunctions: Optional[bool] = True,
        additional_noun_verb_deps: Optional[List[str]] = None,
    ) -> pd.Series:
        """Uses joblib to parallel process action object pair generation

        Parameters
        ----------
        texts : pd.Series
            Series object of the cleaned text column

        backend :str, optional, default-"multiprocessing"
            Which backend to use for joblib. Valid options are "loky", "multiprocessing", "threading"

        prefer: str, optional, default-"processes"
            If backend is to be thread based or process based. Valid options are "thread", "processes"

        chunksize: int, optional, default-1000
            How many rows need to be processed at once.

        n_jobs: int, optional, default--1
            Max number of concurrently running jobs. Default is -1 or use all available

        nlp_pipe_batch_size: int, optional, default-10
            How many rows to be batch processed by spacy nlp pipeline

        show_progress: bool, optional, default-False
            If tqdm progress bar is to be shown or not

        include_core_dependencies: bool, optional, default-True
            If core dependencies between noun and verb i.e. "nsubj", "nsubjpass", "dobj" need to be included

        include_adjectives : bool, optional, default-True
            If adjectives need to be included for the noun.

        include_verb_adpositions : bool, optional, default-True
            If adpositions need to be included for the verb noun pair.

            For example if we had a sentence containing 'made with apples'

            Here 'made' is a verb, 'with' is an adposition and 'apples' is a noun.

            Initially as there would be no direct connection between made and apples, this pair would be ignored.

            If this parameter is set to True, then the pair of ('made with', 'apples') would be included.

        include_noun_adpositions : bool, optional, default-True
            If adpositions need to be included for the noun.

            For example if we had a sentence containing 'date of birth'

            Here 'date' is a noun, 'of' is an adposition and 'birth' is a noun.

            If this parameter is set to True, the whole of 'date of birth' will be considered as a single noun

        include_noun_conjunctions : bool, optional, default-True
            If conjunctions need to be included for the noun.

            For a verb -> noun1 -> noun2, since there is no direct connection between verb and noun2,

            if there is a conjunction dependency between noun1 and noun2,

            then we use both noun1 and noun2 as (verb, noun1), (verb, noun2).

            Example: 'Can I verify your date of birth and address'

            Returns both ('verify', 'date of birth') and ('verify', 'address').

        additional_noun_verb_deps : List[str], optional, default-None
            Any other additional dependencies from https://universaldependencies.org/docs/en/dep/ are supported.
            They can be passed as a list of strings and all the verb noun connections having said dependency will be extracted as part of output.

        Returns
        -------
        pd.Series
            Series object containing action object pairs

        Examples
        -----
        >>> from tigernlp.action_object_pairs.api import AOPGenerate
        >>> aopGenerate = AOPGenerate(merge_compound_nouns=True)
        >>> aopGenerate.process('Can I verify your date of birth and address')
        >>> df['action_object_pairs'] = aopGenerate._joblib_parallel_process(df['processed_text'])
        """

        executor = joblib.Parallel(n_jobs=n_jobs, backend=backend, prefer=prefer)
        do = joblib.delayed(self._process_function)
        tasks = (
            do(
                chunk,
                nlp_pipe_batch_size=nlp_pipe_batch_size,
                include_core_dependencies=include_core_dependencies,
                include_adjectives=include_adjectives,
                include_verb_adpositions=include_verb_adpositions,
                include_noun_adpositions=include_noun_adpositions,
                include_noun_conjunctions=include_noun_conjunctions,
                additional_noun_verb_deps=additional_noun_verb_deps,
            )
            for chunk in self._chunker(texts, len(texts), chunksize=chunksize)
        )
        if show_progress:
            with self._tqdm_joblib(tqdm(total=math.ceil(len(texts) / chunksize))) as _:
                result = executor(tasks)
        else:
            result = executor(tasks)
        return self._flatten(result)

    def process_df(
        self,
        dataframe: pd.DataFrame,
        processed_text_column: Optional[str] = "processed_text",
        action_object_pair_column: Optional[str] = "action_object_pairs",
        n_jobs: Optional[int] = 1,
        show_progress: Optional[bool] = False,
        include_core_dependencies: Optional[bool] = True,
        include_adjectives: Optional[bool] = True,
        include_verb_adpositions: Optional[bool] = True,
        include_noun_adpositions: Optional[bool] = True,
        include_noun_conjunctions: Optional[bool] = True,
        additional_noun_verb_deps: Optional[List[str]] = None,
        **kwargs,
    ) -> pd.DataFrame:
        """
        Process the given dataframe to generate list of verb noun pairs for each row

        Parameters
        ----------
        dataframe : pd.DataFrame
            Dataframe to process action object pairs on

        processed_text_column : str, optional, default-'processed_text'
            Column name where cleaned text is present, by default 'processed_text'

        action_object_pair_column : str, optional, default-'action_object_pairs'
            Column name where action object pairs result should be stored, by default 'action_object_pairs'

        n_jobs: int, optional, default-1
            Max number of concurrently running jobs. Default is 1 or run sequentially.
            If it is set to any other number, parallel process will be used

        show_progress: bool, optional, default-False
            If True show tqdm progress bar

        include_core_dependencies: bool, optional, default-True
            If core dependencies between noun and verb i.e. "nsubj", "nsubjpass", "dobj" need to be included

        include_adjectives : bool, optional, default-True
            If adjectives need to be included for the noun.

        include_verb_adpositions : bool, optional, default-True
            If adpositions need to be included for the verb noun pair.

            For example if we had a sentence containing 'made with apples'

            Here 'made' is a verb, 'with' is an adposition and 'apples' is a noun.

            Initially as there would be no direct connection between made and apples, this pair would be ignored.

            If this parameter is set to True, then the pair of ('made with', 'apples') would be included.

        include_noun_adpositions : bool, optional, default-True
            If adpositions need to be included for the noun.

            For example if we had a sentence containing 'date of birth'

            Here 'date' is a noun, 'of' is an adposition and 'birth' is a noun.

            If this parameter is set to True, the whole of 'date of birth' will be considered as a single noun

        include_noun_conjunctions : bool, optional, default-True
            If conjunctions need to be included for the noun.

            For a verb -> noun1 -> noun2, since there is no direct connection between verb and noun2,

            if there is a conjunction dependency between noun1 and noun2,

            then we use both noun1 and noun2 as (verb, noun1), (verb, noun2).

            Example: 'Can I verify your date of birth and address'

            Returns both ('verify', 'date of birth') and ('verify', 'address').

        additional_noun_verb_deps : List[str], optional, default-None
            Any other additional dependencies from https://universaldependencies.org/docs/en/dep/ are supported.
            They can be passed as a list of strings and all the verb noun connections having said dependency will be extracted as part of output.

        Other Parameters
        ----------------
        backend: str, optional, default-"multiprocessing"
            Which backend to use for joblib. Valid options are "loky", "multiprocessing", "threading".

        prefer: str, optional, default-"processes"
            If backend is to be thread based or process based. Valid options are "threads", "processes", None.

        chunksize: int, optional, default-1000
            How many rows need to be processed at once.
            In case of large datasets and high memory, one can increase this parameter for improved processing speeds.
            Similarly this parameter can be reduced in cases of limited memory.

        nlp_pipe_batch_size: int, optional, default-10
            How many rows to be batch processed by spacy nlp pipeline containing en_core_web model.

        Returns
        -------
        pd.DataFrame
            Dataframe containing action object pairs in column specified under action_object_pair_column parameter

        Examples
        --------
        >>> from tigernlp.action_object_pairs.api import AOPGenerate
        >>> aopGenerate = AOPGenerate(merge_compound_nouns=True)

        >>> # Run on a dataframe by applying parallel processing
        >>> df = aopGenerate.process_df(dataframe = df,
                                        n_jobs = 4)

        >>> # Run on a dataframe without parallel processing
        >>> df = aopGenerate.process_df(dataframe = df,
                                        n_jobs = 1)
        """

        # Which backend to use for joblib. Valid options are "loky", "multiprocessing", "threading"
        if "backend" not in kwargs:
            kwargs["backend"] = "multiprocessing"
        elif not isinstance(kwargs["backend"], str):
            self.logger.warning(
                f'"backend" parameter must be a string. Received {type(kwargs["backend"])}'
            )
            self.logger.warning('Defaulting backend to "multiprocessing"')
            kwargs["backend"] = "multiprocessing"
        elif kwargs["backend"] not in ["loky", "multiprocessing", "threading"]:
            self.logger.warning(
                f'Received invalid input for backend - {kwargs["backend"]}. Valid inputs are "loky", "multiprocessing", "threading"'
            )
            self.logger.warning('Defaulting backend to "multiprocessing"')
            kwargs["backend"] = "multiprocessing"

        # If backend is to be thread based or process based. Valid options are "threads", "processes", None
        if "prefer" not in kwargs:
            kwargs["prefer"] = "processes"
        elif not isinstance(kwargs["prefer"], str) and kwargs["prefer"] is not None:
            self.logger.warning(
                f'"prefer" parameter must be a string or None. Received {type(kwargs["prefer"])}'
            )
            self.logger.warning('Defaulting prefer to "processes"')
            kwargs["prefer"] = "processes"
        elif kwargs["prefer"] not in ["threads", "processes", None]:
            self.logger.warning(
                f'Received invalid input for prefer - {kwargs["prefer"]}. Valid inputs are "threads", "processes", None'
            )
            self.logger.warning('Defaulting prefer to "processes"')
            kwargs["prefer"] = "processes"

        # How many rows need to be processed at once. Default is 1000.
        if "chunksize" not in kwargs:
            kwargs["chunksize"] = 1000
        elif not isinstance(kwargs["chunksize"], int):
            self.logger.warning(
                f'"chunksize" parameter must be an integer. Received {type(kwargs["chunksize"])}'
            )
            self.logger.warning("Defaulting chunksize to 1000")
            kwargs["chunksize"] = 1000

        # How many rows to be batch processed by spacy nlp pipeline
        if "nlp_pipe_batch_size" not in kwargs:
            kwargs["nlp_pipe_batch_size"] = 10
        elif not isinstance(kwargs["nlp_pipe_batch_size"], int):
            self.logger.warning(
                f'"nlp_pipe_batch_size" parameter must be an integer. Received {type(kwargs["nlp_pipe_batch_size"])}'
            )
            self.logger.warning("Defaulting nlp_pipe_batch_size to 10")
            kwargs["nlp_pipe_batch_size"] = 10

        if not isinstance(dataframe, pd.DataFrame):
            raise ValueError("Please provide a valid dataframe")

        if processed_text_column not in dataframe.columns:
            raise ValueError(f"Clean text column {processed_text_column} not found in dataframe")

        if n_jobs != 1:
            self.logger.info(
                f'The following configuration is selected for parallel processing: backend="{kwargs["backend"]}", prefer="{kwargs["prefer"]}", chunksize={kwargs["chunksize"]}, nlp_pipe_batch_size={kwargs["nlp_pipe_batch_size"]}'
            )

            dataframe[action_object_pair_column] = self._joblib_parallel_process(
                dataframe[processed_text_column],
                backend=kwargs["backend"],
                prefer=kwargs["prefer"],
                chunksize=kwargs["chunksize"],
                n_jobs=n_jobs,
                nlp_pipe_batch_size=kwargs["nlp_pipe_batch_size"],
                show_progress=show_progress,
                include_core_dependencies=include_core_dependencies,
                include_adjectives=include_adjectives,
                include_verb_adpositions=include_verb_adpositions,
                include_noun_adpositions=include_noun_adpositions,
                include_noun_conjunctions=include_noun_conjunctions,
                additional_noun_verb_deps=additional_noun_verb_deps,
            )
            return dataframe

        if show_progress:
            dataframe[action_object_pair_column] = dataframe[processed_text_column].progress_apply(
                lambda x: self.process(
                    x,
                    include_core_dependencies=include_core_dependencies,
                    include_adjectives=include_adjectives,
                    include_verb_adpositions=include_verb_adpositions,
                    include_noun_adpositions=include_noun_adpositions,
                    include_noun_conjunctions=include_noun_conjunctions,
                    additional_noun_verb_deps=additional_noun_verb_deps,
                )
            )
        else:
            dataframe[action_object_pair_column] = dataframe[processed_text_column].apply(
                lambda x: self.process(
                    x,
                    include_core_dependencies=include_core_dependencies,
                    include_adjectives=include_adjectives,
                    include_verb_adpositions=include_verb_adpositions,
                    include_noun_adpositions=include_noun_adpositions,
                    include_noun_conjunctions=include_noun_conjunctions,
                    additional_noun_verb_deps=additional_noun_verb_deps,
                )
            )

        return dataframe
