"""Utiltiies around ``Text Matching``.

This module provides custom ``Text Matching`` algorithms.
"""
from .deepER.deepER_model import DeepER
from .deepER.utils import save_glove_embedding
from .ensemble import Ensemble
from .fuzzy_wuzzy_matching import FuzzyWuzzyMatching
from .lsh import LSH
from .semantic_matching import SemanticTextMatching
from .siamese import find_top_n_closest
from .siamese_finetune.data_prep import SiameseSetup
from .siamese_finetune.inference import SiameseInference
from .siamese_finetune.model_setup import SiameseModelSetup
from .utils import EuclideanDistance, JaccardSimilarity
from .zero_shot_classification import ZeroShotClassification
