import numpy as np
import pandas as pd
import torch
from sentence_transformers import InputExample
from sentence_transformers.evaluation import BinaryClassificationEvaluator
from tqdm import tqdm

from tigernlp.core.utils import MyLogger
from tigernlp.text_matching.semantic_matching import SemanticTextMatching


class SiameseSetup:
    """Wrapper class to prepare data for training.

    Parameters
    ----------
    model_name: str, optional
        Name of the sentence transformer model that will be finetuned.

    batch_size: int
        Batch size for training

    logging_level: str, optional
        Level or severity of the events they are used to track. Acceptable values are ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]

    log_file_path: str, optional
        File path to save the logs, by default None

    verbose: bool,
        If `True` logs will be printed to console, by default True

    seed: int
        Enter a random number that will be used for seeding in random module for reproducible results. by default, 42

    Examples
    -------
    >>> ss = SiameseSetup(model_name=modelname,
    batch_size=32,
    logging_level="DEBUG")

    """

    def __init__(
        self,
        model_name: str = "bert-base-uncased",
        batch_size: int = 32,
        logging_level: str = "WARNING",
        log_file_path: str = None,
        verbose: bool = True,
        seed: int = 42,
    ) -> None:
        self.logger = MyLogger(
            level=logging_level, log_file_path=log_file_path, verbose=verbose
        ).logger
        self.stm = SemanticTextMatching(
            log_level=logging_level, log_file_path=log_file_path, verbose=verbose
        )
        np.random.seed(seed)
        self.seed = seed
        self.MODEL_NAME = model_name
        self.BATCH_SIZE = batch_size
        self.related_class_name = 1
        self.unrelated_class_name = 0
        self.logger.info(
            f"As this is a Binary classification setup, Related label will be labelled as {self.related_class_name} whereas unrelated label will be {self.unrelated_class_name}"
        )

    def _form_unrelated_labels(self, label_list: list) -> dict:
        self.logger.debug(
            f"Total there are {len(label_list)} labels for which we are finding most dissimilar labels."
        )
        # Returns dict which gives most unrelated label for each label.
        df_scores = self.stm.cosine_similarity(
            text_doc1=label_list,
            text_doc2=label_list,
            embeddings="sentence_transformers",
            cross_match=True,
            return_df=True,
        )

        df_scores = df_scores.loc[df_scores.groupby("text_doc1")["scores"].idxmin()]
        df_scores = df_scores[["text_doc1", "text_doc2"]]
        return dict(df_scores.values)

    def create_data(
        self, input_data: pd.DataFrame, text_col: str, label_col: str, method: str = "random"
    ) -> pd.DataFrame:
        """Creates a new dataframe by taking the input ``input_data`` that contains ``text_col`` and ``label_col`` and assigning that as rows in the new dataframe with "related" gold_label and add one row by choosing unrelated label via ``method`` for each original row in the ``input_data`` and assigning that as "unrelated" gold_label.

        Parameters
        ----------
        input_data : pd.DataFrame
            Input dataframe

        text_col : str
            Column name containing the text

        label_col : str
            Column name containing the labels

        method : str, optional
            Method in which unrelated label will be found. Available options are "random" and "similar". If "similar", similarity scores will be used., by default "random"

        Returns
        -------
        pd.DataFrame
            Dataframe which is of the below format::

                text_col | label_col | gold_label

        """
        if text_col not in input_data.columns or label_col not in input_data.columns:
            raise ValueError(f"{text_col} and {label_col} is not present in input_data.")
        elif method not in ["random", "similar"]:
            raise ValueError("method values must be either random or similar")

        self.text_col = text_col
        self.label_col = label_col
        # Acceptable values in method are "random", "similar"
        labels_list = input_data[label_col].unique().tolist()
        if method == "similar":
            dissimilar_labels = self._form_unrelated_labels(label_list=labels_list)

        # Form related labels
        # Related label = 1, Unrelated = 0
        input_data["gold_label"] = self.related_class_name

        # form unrelated labels
        for _, row in tqdm(input_data.iterrows(), total=input_data.shape[0]):
            unrelated_labels_list = [lbl for lbl in labels_list if lbl != row[label_col]]
            if method == "similar":
                unrelated_label = dissimilar_labels[row[label_col]]
            else:
                unrelated_label = np.random.choice(unrelated_labels_list)
            current_input_data = pd.DataFrame(
                data={
                    text_col: [row[text_col]],
                    label_col: [unrelated_label],
                    "gold_label": [self.unrelated_class_name],
                }
            )

            input_data = pd.concat([input_data, current_input_data], axis=0, ignore_index=True)

        input_data = input_data.sample(frac=1, random_state=self.seed)

        return input_data

    def prepare_training_data_for_sbert(
        self, input_data: pd.DataFrame, text_col: str, label_col: str, gold_label_col: str = None
    ) -> torch.utils.data.DataLoader:
        """Converts the input dataframe into pytorch dataloader in the format required for Sentence transformer fine tuning. Training data can be in two formats given below.

        Case 1::

            Training data consists of positive/similar pairs of sentences without labels. For example, each row in the dataframe will be of the format.

            (sentence1, sentence2)

        Case 2::

            Training data consists of pairs of sentences with integer labeling. 0 - unrelated; 1 = related. For example, each row in the dataframe will be of the format.

            (sentence1, sentence2, 0),  # Unrelated sentences
            (sentence1, sentence2, 1)   # Related sentences

        Parameters
        ----------
        input_data : pd.DataFrame
            Input dataframe

        text_col : str
            Column name containing the text

        label_col : str
            Column name containing the labels

        gold_label_col : str, optional
            Column name containing the gold label. if its None, each data point would be positive pairs of sentences, by default None

        Returns
        -------
        torch.utils.data.DataLoader
            Final dataloader which will be passed into Sentence transformer training.
        """
        examples = []
        for _, row in tqdm(input_data.iterrows(), total=input_data.shape[0]):
            if gold_label_col is None:  # Approach 5.2
                current_ex = InputExample(texts=[row[text_col], row[label_col]])
            else:  # Approach 5.1
                current_ex = InputExample(
                    texts=[row[text_col], row[label_col]], label=row[gold_label_col]
                )

            examples.append(current_ex)

        processed_dataloader = torch.utils.data.DataLoader(
            examples, shuffle=True, batch_size=self.BATCH_SIZE
        )

        return processed_dataloader

    def build_evaluator(
        self,
        validation_set : pd.DataFrame,
        text_col : str,
        label_col : str,
        name : str,
        gold_label_col : str = None,
        show_progress_bar : bool = False,
        write_csv : bool = True
    ):
        """Validates the trained model.

        Parameters
        ----------
        validation_set : pd.DataFrame
            Validation dataset for evaluating the training model
        text_col : str
            Text column in validation dataframe
        label_col : str
            Label column in validation dataframe
        name : str
            Name of the folder to save model results
        gold_label_col : str, optional
            Column name containing the gold label. if its None, each data point would be positive pairs of sentences, by default None
        show_progress_bar : bool, optional
            If true prints a progress bar
        write_csv : bool, optional
            If true a csv file containg results will be saved in path given

        """
        if text_col not in validation_set.columns or label_col not in validation_set.columns:
            raise ValueError(f"{text_col} and {label_col} is not present in validation_set.")

        self.name = name
        self.show_progress_bar = show_progress_bar
        self.write_csv = write_csv

        text1 = validation_set[text_col].to_list()
        text2 = validation_set[label_col].to_list()

        if gold_label_col is None:
            labels = [self.related_class_name] * validation_set.shape[0]
        else:
            labels = validation_set[gold_label_col].to_list()

        return BinaryClassificationEvaluator(
            sentences1=text1,
            sentences2=text2,
            labels=labels,
            name=self.name,
            batch_size=self.BATCH_SIZE,
            show_progress_bar=self.show_progress_bar,
            write_csv=self.write_csv
        )
