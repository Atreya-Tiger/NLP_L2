import errno
import numpy as np
import os
import pandas as pd
import torch
from sentence_transformers import util
from typing import Union

from tigernlp.core.utils import MyLogger
from tigernlp.embeddings.api import SentenceEmbedding, WordEmbedding

se = SentenceEmbedding()
we = WordEmbedding()


class SemanticTextMatching:

    """Semantic text matching algorithm to find similarity between text documents by computing cosine scores between the embedding vectors.

    There are two options for the type of embeddings user can select:

    *Option 1*: sentence embedding
     - converts sentences and labels into sentence embedding vectors using sentence transformers
    *Option 2*: word embedding
     - converts sentences and labels into word embedding vectors using a pre-trained word embedding model provided by the user, For example - glove-wiki-gigaword-50

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> from tigernlp.text_matching.api import SemanticTextMatching
    >>> sequence = ['made from all-natural free-range chicken and all-natural free-range venison raised without added hormones or antibiotics no artificial preservatives, antibiotics, fillers, coloring, or added hormones', 'grain free']
    >>> labels = ['Made in the USA', 'Grain Free', 'No Artificial Preservatives']
    >>> model_object = SemanticTextMatching()
    >>> #Option 1
    >>> df_theme = df_theme = (
    >>>    model_object
    >>>     .cosine_similarity(text_doc1=sequence, text_doc2=labels, embeddings="sentence_transformers")
    >>> )
    >>> #Option 2
    >>> df_theme = df_theme = (
    >>>     model_object
    >>>     .cosine_similarity(text_doc1=sequence, text_doc2=labels, embeddings="word2vec")
    >>> )
    >>> #Option 3
    >>> df_theme = df_theme = (
    >>>     model_object
    >>>     .cosine_similarity(text_doc1=sequence, text_doc2=labels, embeddings="fasttext")
    >>> )
    >>> #Option 4
    >>> df_theme = df_theme = (
    >>>     model_object
    >>>     .cosine_similarity(text_doc1=sequence, text_doc2=labels, embeddings="glove")
    >>> )
    >>> #Option 5
    >>> df_theme = df_theme = (
    >>>     model_object
    >>>     .cosine_similarity(text_doc1=sequence, text_doc2=labels, embeddings="elmo")
    >>> )
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """SemanticTextMatching class initialization"""

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def _text_doc_embeddings(self, sequence, label):
        """Converts the text documents into embedding vectors using sentence or word embedding model"""

        if self.embeddings == "sentence_transformers":
            if self.embedding_model is None:
                default_model = "all-MiniLM-L6-v2"
                self.logger.info(f"Loading default sentence embedding model: {default_model}")
                self.embedding_model = default_model

            mini_lm_model = se.sentence_transformer_model(self.embedding_model)

            self.logger.info("text_doc1 sentence embedding started")
            sequence_embedding = se.embedding_vector(model_object=mini_lm_model, sentences=sequence)
            # self.logger.info("Sequence sentence embedding complete")

            self.logger.info("text_doc2 sentence embedding started")
            label_embedding = se.embedding_vector(model_object=mini_lm_model, sentences=label)
            # self.logger.info("Label sentence embedding complete")

        elif self.embeddings == "bog":
            sequence_labels = []
            sequence_labels.extend(sequence)
            sequence_labels.extend(label)

            self.logger.info("bag of word embedding started")
            sequence_labels_embedding = np.array(we.bog(sequence_labels))

            sequence_embedding = sequence_labels_embedding[: len(sequence)]
            label_embedding = sequence_labels_embedding[len(sequence) :]

        elif self.embeddings == "word2vec":
            self.logger.info("text_doc1 word embedding started")
            sequence_embedding = np.array(we.Word2Vec(sequence))

            self.logger.info("text_doc2 word embedding started")
            label_embedding = np.array(we.Word2Vec(label))

        elif self.embeddings == "fasttext":
            self.logger.info("text_doc1 word embedding started")
            sequence_embedding = np.array(we.fast_text(sequence))

            self.logger.info("text_doc2 word embedding started")
            label_embedding = np.array(we.fast_text(label))
        elif self.embeddings == "glove":

            try:
                self.logger.info("text_doc1 glove word embedding started")
                sequence_embedding = np.array(we.glove(sequence, glove_model_path=self.embedding_model))

                self.logger.info("text_doc2 glove word embedding started")
                label_embedding = np.array(we.glove(label, glove_model_path=self.embedding_model))
            except Exception as e:
                self.logger.error(
                    f"Please provide correct path to glove model .text file. You can download glove models from `https://nlp.stanford.edu/projects/glove/`. Download model, unzip it and provide the path of .text file {e}"
                )
                raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), self.embedding_model)

        elif self.embeddings == "elmo":
            self.logger.info("text_doc1 word embedding started")
            sequence_embedding = np.array(we.elmo(sequence))

            self.logger.info("text_doc2 word embedding started")
            label_embedding = np.array(we.elmo(label))

        else:
            raise Exception(
                "Invalid embedding type parameter. Please pass embedding type parameter as '\"sentence_transformers/bog/word2vec/fasttext/glove/elmo\"'"
            )

        return (sequence_embedding, label_embedding)

    def _get_cos_score(self, sequence_embedding, label_embedding):
        """computes cosine score between two sentence embedding vectors

        Returns
        -------
        list
            cosine score between embedding vectors
        """

        if self.cross_match:
            scores = util.cos_sim(sequence_embedding, label_embedding)
        else:
            scores = torch.diag(util.cos_sim(sequence_embedding, label_embedding))

        scores = scores.detach().cpu().numpy()
        return scores

    def cosine_similarity(
        self,
        text_doc1: Union[str, list, pd.DataFrame] = list(),
        text_doc2: Union[str, list] = None,
        column_dict={"col_doc1": None, "col_doc2": None},
        embeddings="sentence_transformers",
        embedding_model=None,
        cross_match=True,
        return_df=True,
    ):
        """Generates final model output using semantic similarity

        Parameters
        ----------
        text_doc1 : Union[str, list, pd.DataFrame], optional
            string or list of text documents or dataframe to match with text_doc2, by default list()
        text_doc2 : Union[str, list], optional
            string or list of text documents to match with text_doc1, by default None
        column_dict : dict, optional
            col_doc1 is the column name required to match the text documents with column name col_doc2 or text documents in text_doc2, by degault column_dict={"col_doc1": None, "col_doc2": None}
        embeddings : str, optional
            embeddings to be used for cosine similarity sentence_transformers/word2vec/fasttext/glove/elmo, by default "sentence_transformers"
        embedding_model : str, optional
            the model name or model path that will be used by the pipeline for sentence_transformers/Glove embeddings, by default None

            Example - if embeddings = "sentence_transformers", embedding_model: should be supported by sentence transfoermes, "all-MiniLM-L6-v2".
            Refer https://huggingface.co/sentence-transformers for the list of supported models

            if embeddings = "glove", embedding_model: should be path to the glove embedding .text file. Example: ./data/nlp_models/glove/glove.6B/glove.6B.100d.txt. User can download models from `https://nlp.stanford.edu/projects/glove/`
        cross_match : bool, optional
            if True, computes similarity between all combinations of text_doc1 and text_doc2 documents. Output shape will be equal to len(text_doc1) x len(text_doc2)

            if False, computes similarity between the i(th) elemenet of text_doc1 and i(th) element of text_doc2. Ouput share will be equal to the len(text_doc1)
        return_df : bool, optional
            if True, return output of text matching as dataframe else return list of scores

        Returns
        -------
        pd.DataFrame or list
            if return_df is True, dataframe with cosine score as column "scores" between text_doc1 and text_doc2. Output dataframe shape will be equal to len(text_doc1) x len(text_doc2)

            if return_df is False, list of lists with cosine score between text_doc1 and text_doc2 where list[0][1] is the score between text_doc1[0] and text_doc2[1]
            Example - [[0, 1.3651, 1.3632], [1.3651, 0, 1.3862]]

        Raises
        ------
        Exception
            raise error if embedding type is not provided as "sentence_transformers/bog/word2vec/fasttext/glove/elmo"
        """

        """
        Example : sequence = ["dolphin safe", "grain free"], labels = ["Grain Free", "Made in the USA"]
        Output dataframe:

             sequence	    |   labels	           | scores	  | predicted
            ----------------|----------------------|----------|-----------
             dolphin safe	|   Made in the USA	   | 0.076612 |	    0
             dolphin safe	|   Grain Free	       | 0.066746 |	    0
             grain free	    |   Grain Free	       | 1.000000 |	    1
             grain free	    |   Made in the USA	   | 0.148995 |	    0
        """

        try:
            self.logger.info(f"Text matching using {embeddings} semantic matching started")
            self.embeddings = embeddings
            self.embedding_model = embedding_model
            self.cross_match = cross_match

            if not isinstance(text_doc1, pd.DataFrame) and not isinstance(text_doc1, str) and not isinstance(text_doc1, list):
                self.logger.error("Invalid data type provided for text_doc1. Please pass a dataframe, list or string to compute similarity")
                raise ValueError("Invalid data type provided for text_doc1. Please pass a dataframe, list or string to compute similarity")

            if isinstance(text_doc1, pd.DataFrame):

                if "scores" in text_doc1.columns:
                    del text_doc1["scores"]

                if not column_dict["col_doc1"]:
                    self.logger.error(
                        "Input column name is not provided, " "set parameter column_dict['col_doc1'] for the input column name."
                    )
                    raise ValueError("Set input column name to parameter: column_dict['col_doc1']")

                if column_dict["col_doc1"] not in text_doc1.columns:
                    self.logger.error("Input column name column_dict['col_doc1'] is either incorrect or not present in the dataframe.")
                    raise ValueError("Provide correct input column name column_dict['col_doc1'].")

                col_doc1 = column_dict["col_doc1"]

                text_doc1.reset_index(inplace=True, drop=True)

                if isinstance(text_doc2, str):
                    self.cross_match = True
                    text_doc1["text_doc2"] = text_doc2
                    sequence_embedding, label_embedding = self._text_doc_embeddings(text_doc1[col_doc1], [text_doc2])
                    score = self._get_cos_score(sequence_embedding, label_embedding)
                    score = list(np.concatenate(np.array(score)))
                    text_doc1["scores"] = score

                elif isinstance(text_doc2, list):

                    if len(text_doc2) == 0:
                        self.logger.error("Empty list can not be used for matching documents")
                        raise ValueError("Provide list with text documents")

                    if not cross_match:
                        if len(text_doc1) != len(text_doc2):
                            self.logger.error(
                                f"Mismatch found in number of rows of text_doc1 {len(text_doc1)} and length of text_doc2 {len(text_doc2)}"
                            )
                            raise ValueError("Number of rows of text_doc1 and lenght of text_doc2 is different")

                        else:
                            text_doc1["text_doc2"] = text_doc2
                            sequence_embedding, label_embedding = self._text_doc_embeddings(text_doc1[col_doc1], text_doc1["text_doc2"])
                            score = self._get_cos_score(sequence_embedding, label_embedding)
                            text_doc1["scores"] = score

                    else:
                        sequence_embedding, label_embedding = self._text_doc_embeddings(text_doc1[col_doc1], text_doc2)
                        score = self._get_cos_score(sequence_embedding, label_embedding)
                        score = list(np.concatenate(np.array(score.T)))
                        count = 0
                        out = pd.DataFrame()
                        for text in text_doc2:
                            temp = text_doc1.copy()
                            temp["text_doc2"] = text
                            temp["scores"] = score[(len(temp) * count) : (len(temp) * (count + 1))]
                            out = pd.concat([out, temp], ignore_index=True)
                            count += 1

                        text_doc1 = out.copy()

                else:
                    if not column_dict["col_doc2"]:
                        self.logger.error(
                            "Input column name is not provided, " "set parameter column_dict['col_doc2'] for the input column name."
                        )
                        raise ValueError("Set input column name to parameter: column_dict['col_doc2']")

                    if column_dict["col_doc2"] not in text_doc1.columns:
                        self.logger.error("Input column name column_dict['col_doc2'] is either incorrect or not present in the dataframe.")
                        raise ValueError("Provide correct input column name column_dict['col_doc2'].")

                    if cross_match:
                        self.logger.error(
                            "Cross matching is not possible within dataframe. Provide text documents as a list for cross match option."
                        )
                        raise ValueError("Provide text documents as a list for cross match option.")

                    else:
                        col_doc2 = column_dict["col_doc2"]
                        sequence_embedding, label_embedding = self._text_doc_embeddings(text_doc1[col_doc1], text_doc1[col_doc2])
                        score = self._get_cos_score(sequence_embedding, label_embedding)
                        text_doc1["scores"] = score

                text_doc1["scores"] = text_doc1["scores"].astype(float)
                text_doc1["scores"] = np.round(text_doc1["scores"], 5)
                self.logger.info(f"Text matching using {self.embeddings} semantic matching completed")
                return text_doc1

            else:

                if not isinstance(text_doc2, str) and not isinstance(text_doc2, list):
                    self.logger.error("Invalid data type provided for text_doc2. Please pass a list or string to compute similarity")
                    raise ValueError("Invalid data type provided for text_doc2. Please pass a list or string to compute similarity")

                if (len(text_doc1) != len(np.unique(text_doc1)) and isinstance(text_doc1, list)) or (
                    len(text_doc2) != len(np.unique(text_doc2)) and isinstance(text_doc2, list)
                ):
                    self.logger.error(
                        "Duplicate values observed in text_doc1 or text_doc2. Please remove duplicate values to compute similarity"
                    )
                    raise ValueError(
                        "Duplicate values observed in text_doc1 or text_doc2. Please remove duplicate values to compute similarity"
                    )

                if len(text_doc1) == 0 or len(text_doc2) == 0:
                    self.logger.error("Empty list/string can not be used for matching documents")
                    raise ValueError("Provide list/string with text documents")

                if isinstance(text_doc1, str) and isinstance(text_doc2, str):
                    text_doc1 = [text_doc1]
                    text_doc2 = [text_doc2]

                elif isinstance(text_doc1, str) and isinstance(text_doc2, list):
                    self.cross_match = True
                    text_doc1 = [text_doc1]

                elif isinstance(text_doc1, list) and isinstance(text_doc2, str):
                    self.cross_match = True
                    text_doc2 = [text_doc2]

                elif isinstance(text_doc1, list) and isinstance(text_doc2, list):

                    if not cross_match:
                        if len(text_doc1) != len(text_doc2):
                            self.logger.error(
                                f"Mismatch found in length of text_doc1 {len(text_doc1)} against length of text_doc2 {len(text_doc2)}"
                            )
                            raise ValueError("Length of text_doc1 and text_doc2 is different")

                sequence_embedding, label_embedding = self._text_doc_embeddings(text_doc1, text_doc2)
                score = self._get_cos_score(sequence_embedding, label_embedding)

                if return_df:
                    if self.cross_match:
                        df = pd.DataFrame(score)
                        df.columns = text_doc2
                        df["sequence"] = text_doc1
                        df = df.melt(id_vars="sequence")
                        df.rename(columns={"variable": "labels", "value": "scores"}, inplace=True)

                    else:
                        df = pd.DataFrame()
                        df["sequence"] = text_doc1
                        df["labels"] = text_doc2
                        df["scores"] = score

                    self.logger.info(f"Text matching using {self.embeddings} semantic matching completed")
                    df["scores"] = df["scores"].astype(float)
                    df["scores"] = np.round(df["scores"], 5)
                    df.reset_index(inplace=True, drop=True)
                    df.rename(columns={"sequence": "text_doc1", "labels": "text_doc2"}, inplace=True)

                    return df

                else:
                    score = np.round(score, 5)
                    self.logger.info(f"Text matching using {self.embeddings} semantic matching completed")
                    return score

        except Exception as e:
            self.logger.error(f"Error occurred during semantic text matching {e}")
