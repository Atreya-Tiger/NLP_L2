import numpy as np
import os
import pandas as pd
import pickle as pkl
import string
from collections import defaultdict
from gensim.models import KeyedVectors
from gensim.scripts.glove2word2vec import glove2word2vec
from transformers import AutoTokenizer

from tigernlp.core.utils import MyLogger


# DATA HANDLING
def is_str_list(x):
    """given a pd.Series of strings, return True if all elements begin and end with square brackets

    Parameters
    ----------
    x : pd.Series
        series of strings

    Returns
    -------
    bool
        return True if all elements begin and end with square brackets
    """
    return np.all(x.astype(str).str.startswith("[") & x.astype(str).str.endswith("]"))


def str_to_list(x):
    """convert a string reprentation of list to actual list

    Parameters
    ----------
    x : str
        string representation of list to be converted to actual list

    Returns
    -------
    list
        list representation of the given string list
    """
    x = x[1:-1]
    return [int(i) for i in x]


def get_document_frequencies(set1: pd.DataFrame, set2: pd.DataFrame, mapping, embedding_type: str):
    """
    Computes the freaquency of each word in set1 and set2

    Parameters
    ----------
    set1 : pd.DataFrame
        dataframe containing first set of data to be matched
    set2 : pd.DataFrame
        dataframe containing first set of data to be matched
    mapping : word to index mapping
        word to index mapping file
    embedding_type: str
        type of embedding to be used. available options include 'mpnet', 'bert', 'glove'

    Returns
    -------
    np.array
        array containing frequency for each word
    """
    # select only columns whose values are lists embedded as strings
    mask1 = set1.apply(is_str_list, axis="rows")
    mask2 = set2.apply(is_str_list, axis="rows")

    # convert strings back into lists
    set1 = set1.loc[:, mask1].applymap(str_to_list)
    set2 = set2.loc[:, mask2].applymap(str_to_list)

    # concatenate columns so all relevant attributes become a single list
    def concat_columns(x):
        idx_list = list()
        for lst in x.values:
            idx_list += lst
        return idx_list

    set1 = set1.apply(concat_columns, axis="columns")
    set2 = set2.apply(concat_columns, axis="columns")

    # +1 because default value of DefaultDict not counted
    if embedding_type == "glove":
        doc_freqs_1 = np.zeros(len(mapping["idx2word"]) + 1)
        doc_freqs_2 = np.zeros(len(mapping["idx2word"]) + 1)
    else:
        doc_freqs_1 = np.zeros(len(mapping) + 1)
        doc_freqs_2 = np.zeros(len(mapping) + 1)

    for index, item in set1.iteritems():
        uniq_indices = set(item)
        for idx in uniq_indices:
            doc_freqs_1[idx] += 1

    for index, item in set2.iteritems():
        uniq_indices = set(item)
        for idx in uniq_indices:
            doc_freqs_2[idx] += 1

    return doc_freqs_1, doc_freqs_2


def record2idx(x: str, mapping, embedding_type: str):
    """maps the text to the embedded text using the embedding map

    Parameters
    ----------
    x : str
        the text that needs to be converted to the embedding
    mapping : word to index map
        word to index map containing mapping between index to text
    embedding_type: str
        type of embedding to be used. available options include 'mpnet', 'bert', 'glove'

    Returns
    -------
    list
        list containing the embedded words
    """
    if embedding_type == "glove":
        x = x.split()
    for i, token in enumerate(x):
        if embedding_type == "glove":
            idx = mapping["word2idx"][token]
            if idx == 0:
                idx = mapping["word2idx"][token.lower()]
            if idx == 0:
                idx = mapping["word2idx"][string.capwords(token)]
            if idx == 0:
                idx = mapping["word2idx"][token.upper()]
        else:
            if token in mapping.keys():
                idx = mapping[token]
                if idx == 0:
                    idx = mapping[token.lower()]
                if idx == 0:
                    idx = mapping[string.capwords(token)]
                if idx == 0:
                    idx = mapping[token.upper()]
            else:
                idx = 104

        x[i] = idx
    return x


def idx_to_word(x: list, mapping):

    """maps the embedded text to the original text using the embedding map

    Parameters
    ----------
    x : list
        list of word embeddings
    mapping : word to index map
        word to index map containing mapping between index to text

    Returns
    -------
    str
        final string after concatinating the converted embedding to the words
    """
    string = ""
    for idx in x:
        string += " " + mapping["idx2word"][idx]
    return string


def generate_data_dict(df_dict: dict = dict(), df_dict_values: list = None, df_dict_keys: list = []):

    """creates data loader for DeepER model in the dictionary format. Load the data in the format required for the deepER Model

    Parameters
    ----------
    df_dict : dict
        a dictionary of datasets with their respective sources and targets. filenames serve as keys.
    df_dict_values : list
        list containing the two dataframes to be matched and the corresponding labels(in case of train and validation)
    df_dict_keys : list
        list containing the keys for the files to be stored in the data dict

    Returns
    -------
    dict
        a dictionary of datasets with their respective sources and targets. filenames serve as keys.
    """

    for df, filename in zip(df_dict_values, df_dict_keys):
        df_dict[filename] = df

    return df_dict


def convert_text(
    mapping,
    df1: pd.DataFrame,
    df2: pd.DataFrame,
    features: list,
    embedding_type: str,
    embedding_model: str,
    log_level: str = "INFO",
    log_file_path: str = None,
    verbose: bool = True,
):
    """
    Converts the strings in the dataframe to embeddings

    Parameters
    -----------
    mapping: .map file
        map file(.map file) containing mapping from each word to index

    df1: pd.Dataframe
        dataframe containing the first set of text to be matched

    df2: pd.Dataframe
        dataframe containing the second set of text to be matched with first set

    features: list
        the list of columns to be used as features for the training
    embedding_type: str
        type of embedding to be used. available options include 'mpnet', 'bert', 'glove'

    Returns
    --------
    pd.Dataframe
        dataframe containing the text converted to the embedding for first set of text

    pd.Dataframe
        dataframe containing the text converted to the embedding for second set of text

    """
    # Extracting the column indexs of the given features
    column_idxs = []
    for col in features:
        column_idxs.append(df1.columns.get_loc(col))

    logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger
    # make column names the same
    assert df1.columns[0] == "id1"
    assert df2.columns[0] == "id2"
    df2.columns = [df2.columns[0]] + list(df1.columns[1:])

    logger.info("Converting tokens to indices.")
    if embedding_type == "glove":

        df1.iloc[:, column_idxs] = df1.iloc[:, column_idxs].applymap(record2idx, mapping=mapping, embedding_type=embedding_type)
        df2.iloc[:, column_idxs] = df2.iloc[:, column_idxs].applymap(record2idx, mapping=mapping, embedding_type=embedding_type)
    else:
        tokenizer = AutoTokenizer.from_pretrained(embedding_model)

        df1.iloc[:, column_idxs] = df1.iloc[:, column_idxs].applymap(tokenizer.tokenize)
        df2.iloc[:, column_idxs] = df2.iloc[:, column_idxs].applymap(tokenizer.tokenize)
        df1.iloc[:, column_idxs] = df1.iloc[:, column_idxs].applymap(record2idx, mapping=mapping, embedding_type=embedding_type)
        df2.iloc[:, column_idxs] = df2.iloc[:, column_idxs].applymap(record2idx, mapping=mapping, embedding_type=embedding_type)

    return df1, df2


def data_frame_split(
    text_doc1: pd.DataFrame,
    features: list = [],
):
    """
    This function splits the given dataframe into two individual dataframes df1 and df2.
    After dropping the duplicates in the splited dataframes,
    it is added with an unique id column for referring to the individual entries in the future

    Parameters
    ----------
    text_doc1 : pd.DataFrame
        The dataframe to be splited to df1 and df2
    features : list, optional
        Columns in text_doc1 to be splitted to each of df1 and df2, by default []

    Returns
    -------
    pd.DataFrame, pd.DataFrame
        The two unique set of dataframes created by splitting the text_doc1
    """

    doc1_cols = [col + "_1" for col in features]
    doc2_cols = [col + "_2" for col in features]

    df1 = text_doc1[doc1_cols]
    df2 = text_doc1[doc2_cols]

    df1.drop_duplicates(inplace=True)
    df2.drop_duplicates(inplace=True)
    df1.dropna(inplace=True)
    df2.dropna(inplace=True)

    df1.reset_index(drop=True, inplace=True)
    df2.reset_index(drop=True, inplace=True)
    df1.reset_index(inplace=True)
    df2.reset_index(inplace=True)

    df1.columns = ["id1"] + [col + "_1" for col in features]
    df2.columns = ["id2"] + [col + "_2" for col in features]

    return df1, df2


def save_glove_embedding(
    embedding_filepath: str = None,
    embedding_save_path: str = None,
):
    """
    Function to generate word to index mapping and index to embedding file for Glove embeddings

    Parameters
    ----------
    embedding_filepath : str, optional
        path to the source file containing the txt file for Glove embeddings, by default None
        The txt file for glove can be downloaded from https://nlp.stanford.edu/projects/glove/
    embedding_save_path : str, optional
        path to the folder to save the word to index mapping(.map) and index to embedding file(.npy), by default None

    """
    embedding_name = "glove"
    if embedding_name == "glove":
        glove2word2vec(
            glove_input_file=embedding_filepath,
            word2vec_output_file=os.path.join(embedding_save_path, "gensim_glove_vectors.txt"),
        )
        model = KeyedVectors.load_word2vec_format(os.path.join(embedding_save_path, "gensim_glove_vectors.txt"), binary=False)

        # create and save numpy embedding matrix with initial row of zeros
        logger = MyLogger()
        logger.info("creating embedding matrix")
        embedding_matrix = model.vectors
        emb_dim = len(embedding_matrix[0])
        embedding_matrix = np.vstack([np.zeros(emb_dim), embedding_matrix])

        model.save(embedding_save_path + "\\{}-{}.gensim".format(embedding_name, str(emb_dim)))
        np.save(
            file=embedding_save_path + "\\{}-{}.matrix".format(embedding_name, str(emb_dim)),
            arr=embedding_matrix,
        )

        # create and save two maps of corpus vocabulary
        logger.info("creating maps")
        vocab = ["<unk>"] + list(model.index_to_key)
        word2idx = defaultdict(int, zip(vocab, range(len(vocab))))
        idx2word = dict(zip(range(len(vocab)), vocab))

        # manually encode NaN's as unknown
        for nan in ["NaN", "NAN", "nan", "Nan"]:
            word2idx[nan] = 0

        map = dict()
        map["word2idx"] = word2idx
        map["idx2word"] = idx2word

        with open(embedding_save_path + "\\{}-{}.map".format(embedding_name, str(emb_dim)), "wb") as f:
            pkl.dump(map, f)
