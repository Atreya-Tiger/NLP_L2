import json
import keras
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd
import pickle as pkl
from sklearn.metrics import classification_report, confusion_matrix, f1_score
from transformers import AutoTokenizer
from typing import Union

from tigernlp.core.utils import MyLogger
from tigernlp.text_matching.deepER.data_prep import (
    create_combinations,
    generate_non_matches_train,
)
from tigernlp.text_matching.deepER.model_generator import (
    deep_er_data_transformer,
    deep_er_model_generator,
    deep_er_pred_data_transformer,
)
from tigernlp.text_matching.deepER.utils import (
    convert_text,
    data_frame_split,
    generate_data_dict,
    get_document_frequencies,
)


class DeepER:

    r"""DeepER text matching algorithm to classify text documents using a training dataset.

    Performs the Deep Entity Resolution using the deepER model defined in https://github.com/zhao1701/extending-deep-ER

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> import pandas as pd
    >>> from tigernlp.text_matching.api import DeepER
    >>> input_df = pd.read_csv(r"labelled_data.csv")
    >>> input_df.dropna(inplace=True)
    >>> train_df = input_df.copy()
    >>> pred_df = pd.read_csv(r"unlabelled_data.csv")

    >>> #train the model
    >>> matcher=DeepER()
    >>> matcher.train(
            train_df = train_df,
            val_df = val_df,
            label_col = 'match',
            features = ['website','title'],
            embedding_dict = {
                'embedding_type': 'glove',
                "embedding_model": None,
                'word_to_index_mapping': os.path.join(embedding_path, "glove-300.map"),
                'index_to_embedding_weights': os.path.join(embedding_path, "glove-300.matrix.npy")
            },
            model_save_path = model_path,
            model_parameters={
                'epochs': 20,
                'batch_size': 512,
                'non_matches_ratio': 100,
                'text_features': [],
                'num_features': [],
                'text_sim_metrics': ['cosine'],
                'text_compositions': ['average'],
                'numeric_sim_metrics': ['unscaled_inverse_lp'],
                'dense_nodes': [24],
                'idf_smoothing': 2,
                'make_isna': True,
                'embedding_trainable': False,
                'padding_limit': 100,
                'batch_norm': True,
                'dropout': 0.75,
                'shared_lstm': True,
                'lstm_args': {'units': 25}
            }
        )
    >>> # generating inference
    >>> matches,result_df = matcher.inference(
            text_doc1=test_df,
            model_save_path = model_path
        )
    >>> # The returned dataframe contains matching texts from columns from pred_df

    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """DeepER Model class initialization"""

        self.log_file_path = log_file_path
        self.log_level = log_level
        self.verbose = verbose

        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

    def _get_model_instance(
        self,
    ):
        """
        Create an instance of the deepER model using the model parameters.

        Returns
        --------
        model object
            deepER model based on the model parameters provided

        """

        self.doc_freqs_1, self.doc_freqs_2 = get_document_frequencies(
            set1=self.df1,
            set2=self.df2,
            mapping=self.map,
            embedding_type=self.embedding_type,
        )
        # self.doc_freqs_1, self.doc_freqs_2 = None, None
        if self.index_to_embedding_weights is None and self.embedding_type == "glove":
            self.logger.error(
                "index_to_embedding_weights path is not provided, "
                "set parameter index_to_embedding_weights for the path to the numpy matrix containing word vector embeddings (.npy file)."
            )
            raise ValueError(
                "path to the numpy matrix containing word vector embeddings (.npy file): index_to_embedding_weights"
            )

        self.model = deep_er_model_generator(
            embedding_file=self.index_to_embedding_weights,
            text_columns=self.model_parameters["text_features"],
            numeric_columns=self.model_parameters["num_features"],
            text_sim_metrics=self.model_parameters["text_sim_metrics"],
            text_compositions=self.model_parameters["text_compositions"],
            numeric_sim_metrics=self.model_parameters["numeric_sim_metrics"],
            dense_nodes=self.model_parameters["dense_nodes"],
            document_frequencies=(self.doc_freqs_1, self.doc_freqs_2),
            idf_smoothing=self.model_parameters["idf_smoothing"],
            make_isna=self.model_parameters["make_isna"],
            embedding_trainable=self.model_parameters["embedding_trainable"],
            padding_limit=self.model_parameters["padding_limit"],
            batch_norm=self.model_parameters["batch_norm"],
            dropout=self.model_parameters["dropout"],
            shared_lstm=self.model_parameters["shared_lstm"],
            lstm_args=self.model_parameters["lstm_args"],
            embedding_type=self.embedding_type,
            embedding_model=self.embedding_model,
        )

        return self.model

    def train(
        self,
        train_df: pd.DataFrame,
        val_df: pd.DataFrame,
        label_col: str = "match",
        features: list = [],
        embedding_dict: dict = {
            "embedding_type": "bert",
            "embedding_model": "bert-base-uncased",
            "word_to_index_mapping": None,
            "index_to_embedding_weights": None,
        },
        model_save_path: str = None,
        model_parameters={
            "epochs": 20,
            "batch_size": 128,
            "non_matches_ratio": 100,
            "text_features": [],
            "num_features": [],
            "text_sim_metrics": ["cosine"],
            "text_compositions": ["average"],
            "numeric_sim_metrics": ["unscaled_inverse_lp"],
            "dense_nodes": [24],
            "idf_smoothing": 2,
            "make_isna": True,
            "embedding_trainable": False,
            "padding_limit": 100,
            "batch_norm": True,
            "dropout": 0.75,
            "shared_lstm": True,
            "lstm_args": dict(units=25),
        },
    ):
        """
        Function to train the deepER model on the given training dataset. It returns the trained model and training vs loss plot.
        Saves the model weight and the model parameters in the path provided

        Parameters
        ----------
        train_df : pd.DataFrame
            a dataframe containing matching and non-matching(optional) samples for training.
            The dataframe should contain columns with a suffix of '_1' and '_2' for each of the feature and column indicating labels(match or non-match).
            For example : if features are ['category','title'], the data columns should contain ['category_1','title_1','category_2','title_2','match']
        val_df : pd.DataFrame
            a dataframe containing matching and non-matching(optional) samples for validation.
            The dataframe should contain columns with a suffix of '_1' and '_2' for each of the feature and column indicating labels(match or non-match).
            For example : if features are ['category','title'], the data columns should contain ['category_1','title_1','category_2','title_2','match']
        label_col : str, required
            column name in train_df and val_df indicating whether the given sample is matching or non-matching, by default 'match'
        features : list, required
            list of features that need to be used for training. The training data must contain columns with suffix '_1','_2' for each feature given in the list, by default []

        embedding_dict : dict, required
            Dictionary containing the details related to the embedding to be used,
            by default { 'embedding_type': 'bert', "embedding_model": "bert-base-uncased", 'word_to_index_mapping': None, 'index_to_embedding_weights': None }

                * embedding_type: type of the embedding to be used. options are ('sentence-transformers','bert','glove')
                * embedding_model: name of the embedding model to be used. For example: while using bert, specify the model to be used like 'bert-base-uncased'. When using sentence transformers specify the model name like 'all-mpnet-base-v2'
                * word_to_index_mapping: path to the file containing the mapping from each word to the index for embedding. only required for GloVe. by default None
                * index_to_embedding_weights: path to the file containing the embedding vector for each index. only required for GloVe. by default None

        model_save_path : str, required
            path to the folder to save the model parameters, model weights and model training metrics, by default None
        model_parameters: dict, optional

            dict containing the different model parameters
                epochs:int, optional,
                    number of epochs for the training
                batch_size: int, optional,
                    batch size fo the training
                non_matches_ratio:int, optional
                    number of negative samples to be created for each positive samples from the given matches in training data (train_df). By default 100.
                text_features:list,
                    list of text features. Need to be a subset of features
                num_features: list,
                    list of numeric features
                text_sim_metrics : list of strings, optional
                    List of similarity metrics to be computed for each text-based attribute. Valid options are :
                        - cosine
                        - inverse_l1 : e^-[l1_distance]
                        - inverse_l2 : e^-[l2_distance]
                text_compositions : list of strings, optional
                    List of composition methods to be applied to embedded text attributes.
                    Valid options are :

                        - average : a simple average of all embedded vectors
                        - idf : an average of all embedded vectors weighted by normalized inverse document frequency

                numeric_sim_metrics : list of strings, optional
                    List of similarity metrics to be computed for each numeric attribute. Valid options are :

                        - scaled_inverse_lp : e^[-2(abs_diff)/sum]
                        - unscaled_inverse_lp : e^[-abs_diff]
                        - min_max_ratio : min / max

                dense_nodes : list of ints, optional
                    Specifies topology of hidden dense layers
                idf_smoothing : int, optional
                    un-normalized idf = 1 / df ^ (1 / idf_smoothing)
                    Higher values means that high document frequency words are penalized less.
                make_isna: bool, optional
                    Whether to create new attributes indicating the presence of null values for each original attribute.
                embedding_trainable: bool, optional
                    Whether to allow the embedding layer to be fine tuned.
                padding_limit:int, optional
                    The maximum length of any text sequence.
                    For any text attribute whose max length is below padding_limit, the max length will be used.
                    Otherwise, padding_limit will be used to both pad and truncuate text sequences for that attribute.
                batch_norm:bool, optional
                    whether to use a batch nomalization. by default True,
                dropout:float , optional
                    rate of dropout between 0 and 1. By default 0.75
                shared_lstm:bool,optional
                    whether to compose embedding tensor using shared LSTM. by default True,
                lstm_args = dict, optional
                    Keyword arguments for LSTM layer

        Returns
        --------
        model object
            Returns the trained text matching object

        matplotlib.figure
            Figure showing the training and validation loss vs epochs.
        """

        self.embedding_type = embedding_dict["embedding_type"]
        self.embedding_model = embedding_dict["embedding_model"]
        self.model_save_path = model_save_path
        self.index_to_embedding_weights = None
        self.word_to_index_mapping = None

        if self.embedding_type == "glove":
            self.word_to_index_mapping = embedding_dict["word_to_index_mapping"]
            self.index_to_embedding_weights = embedding_dict[
                "index_to_embedding_weights"
            ]

            if self.word_to_index_mapping is not None:
                with open(self.word_to_index_mapping, "rb") as f:
                    self.map = pkl.load(f)
            else:
                self.logger.error(
                    "word_to_index_mapping path is not provided, "
                    "set parameter word_to_index_mapping for the path to the embedding map file."
                )
                raise ValueError(
                    "path to the embedding map file: word_to_index_mapping"
                )
            self.nan_idx = self.map["word2idx"]["NaN"]
        elif self.embedding_type == "bert":
            tokenizer = AutoTokenizer.from_pretrained(self.embedding_model)
            self.map = dict(tokenizer.vocab)
            self.nan_idx = None
        elif self.embedding_type == "sentence-transformers":
            self.embedding_model = (
                "sentence-transformers/" + embedding_dict["embedding_model"]
            )
            tokenizer = AutoTokenizer.from_pretrained(self.embedding_model)
            self.map = dict(tokenizer.vocab)
            self.nan_idx = None
        else:
            self.logger.error(
                "embedding_type is not provided, "
                "set parameter embedding_dict['embedding_type'] for the type of the embedding to be used.Choose one of 'bert', 'mpnet','glove' "
            )
            raise ValueError("embedding_type is not provided")

        features = [x.lower() for x in features]
        model_parameters["text_features"] = features
        self.model_parameters = model_parameters

        train_df.columns = [col.lower() for col in train_df.columns]
        train_df.rename(columns={label_col: "match"}, inplace=True)
        df1, df2 = data_frame_split(text_doc1=train_df, features=features)
        train_df = pd.merge(
            train_df, df1, on=[col + "_1" for col in features], how="inner"
        )
        train_df = pd.merge(
            train_df, df2, on=[col + "_2" for col in features], how="inner"
        )

        if model_parameters["non_matches_ratio"] != 0:
            train_df = generate_non_matches_train(
                text_doc1=train_df,
                df1=df1,
                df2=df2,
                non_matches_ratio=model_parameters["non_matches_ratio"],
                log_level=self.log_level,
                log_file_path=self.log_file_path,
                verbose=self.verbose,
            )

        df1.columns = ["id1"] + features
        df2.columns = ["id2"] + features

        self.df1, self.df2 = convert_text(
            self.map,
            df1,
            df2,
            features,
            embedding_type=self.embedding_type,
            embedding_model=self.embedding_model,
        )

        self.df1["id1"] = self.df1["id1"].astype(str)
        self.df2["id2"] = self.df2["id2"].astype(str)
        train_df = train_df.sample(len(train_df), replace=False)
        train_df = train_df[["id1", "id2", "match"]]
        train_df["id1"] = train_df["id1"].astype(str)
        train_df["id2"] = train_df["id2"].astype(str)

        df_train_1 = pd.merge(train_df, self.df1, how="left", on=["id1"])
        self.train_1 = df_train_1.drop(["id2", "match"], axis="columns")
        df_train_2 = pd.merge(train_df, self.df2, how="left", on=["id2"])
        self.train_2 = df_train_2.drop(["id1", "match"], axis="columns")
        df_train_y = train_df["match"]

        assert np.all(self.train_1["id1"].values == train_df["id1"].values)
        assert np.all(self.train_2["id2"].values == train_df["id2"].values)
        self.logger.info("Training set contains {} instances".format(len(df_train_y)))
        self.train_y = pd.DataFrame(df_train_y)

        self.data = dict()

        self.data = generate_data_dict(
            df_dict=self.data,
            df_dict_values=[self.train_1, self.train_2, self.train_y],
            df_dict_keys=["train_1", "train_2", "train_y"],
        )

        val_df.columns = [col.lower() for col in val_df.columns]
        val_df.rename(columns={label_col: "match"}, inplace=True)
        df1, df2 = data_frame_split(text_doc1=val_df, features=features)
        val_df = pd.merge(val_df, df1, on=[col + "_1" for col in features], how="inner")
        val_df = pd.merge(val_df, df2, on=[col + "_2" for col in features], how="inner")

        if model_parameters["non_matches_ratio"] != 0:

            val_df = generate_non_matches_train(
                text_doc1=val_df,
                df1=df1,
                df2=df2,
                non_matches_ratio=model_parameters["non_matches_ratio"],
                log_level=self.log_level,
                log_file_path=self.log_file_path,
                verbose=self.verbose,
            )

        df1.columns = ["id1"] + features
        df2.columns = ["id2"] + features

        self.df1, self.df2 = convert_text(
            self.map,
            df1,
            df2,
            features,
            embedding_type=self.embedding_type,
            embedding_model=self.embedding_model,
        )

        self.df1["id1"] = self.df1["id1"].astype(str)
        self.df2["id2"] = self.df2["id2"].astype(str)
        val_df = val_df.sample(len(val_df), replace=False)
        val_df = val_df[["id1", "id2", "match"]]
        val_df["id1"] = val_df["id1"].astype(str)
        val_df["id2"] = val_df["id2"].astype(str)
        df_val_1 = pd.merge(val_df, self.df1, how="left", on=["id1"])
        self.val_1 = df_val_1.drop(["id2", "match"], axis="columns")
        df_val_2 = pd.merge(val_df, self.df2, how="left", on=["id2"])
        self.val_2 = df_val_2.drop(["id1", "match"], axis="columns")
        df_val_y = val_df["match"]

        assert np.all(self.val_1["id1"].values == val_df["id1"].values)
        assert np.all(self.val_2["id2"].values == val_df["id2"].values)

        self.logger.info("Validation set contains {} instances".format(len(df_val_y)))

        self.val_y = pd.DataFrame(df_val_y)

        self.data = generate_data_dict(
            df_dict=self.data,
            df_dict_values=[self.val_1, self.val_2, self.val_y],
            df_dict_keys=["val_1", "val_2", "val_y"],
        )

        X_train, X_val, y_train, y_val = deep_er_data_transformer(
            data_dict=self.data,
            padding_limit=model_parameters["padding_limit"],
            text_columns=features,
            numeric_columns=[],
            text_nan_idx=self.nan_idx,
            num_nan_val=0,
        )

        histories = dict(f1=list(), val_f1=list(), loss=list(), val_loss=list())
        METRICS = [
            keras.metrics.BinaryAccuracy(name="accuracy"),
            keras.metrics.Precision(name="precision"),
            keras.metrics.Recall(name="recall"),
        ]

        self._get_model_instance()

        self.model.compile(
            optimizer="adam", loss="binary_crossentropy", metrics=METRICS
        )

        history = self.model.fit(
            X_train,
            y_train,
            epochs=model_parameters["epochs"],
            batch_size=model_parameters["batch_size"],
            validation_data=(X_val, y_val),
            shuffle=True,
        )

        precision = history.history["precision"]
        recall = history.history["recall"]
        f1 = []
        for p, r in zip(precision, recall):
            if p + r == 0:
                f1.append(0)
            else:
                f1.append(2 * p * r / (p + r))

        val_precision = history.history["val_precision"]
        val_recall = history.history["val_recall"]
        val_f1 = []
        for p, r in zip(val_precision, val_recall):
            if p + r == 0:
                val_f1.append(0)
            else:
                val_f1.append(2 * p * r / (p + r))

        histories["f1"] = []
        histories["f1"].extend(f1)
        histories["val_f1"] = []
        histories["val_f1"].extend(val_f1)
        histories["loss"].extend(history.history["loss"])
        histories["val_loss"].extend(history.history["val_loss"])

        fig, axes = plt.subplots(1, 2, figsize=(16, 6))
        axes[0].plot(histories["loss"], label="loss")
        axes[0].plot(histories["val_loss"], label="val_loss")
        axes[1].plot(histories["f1"], label="f1")
        axes[1].plot(histories["val_f1"], label="val_f1")

        for ax in axes:
            ax.legend()
            ax.grid(True)
            ax.set(xlabel="epoch")

        y_val_pred = self.model.predict(X_val)[:, 1]
        y_val_ = self.data["val_y"].values.squeeze()
        print("Validation metrics")
        max_f1 = 0
        max_threshold = 0.5
        for threshold in np.linspace(0.05, 1, 20):
            f1 = f1_score(y_val_, y_val_pred >= threshold)
            if f1 > max_f1:
                max_f1 = f1
                max_threshold = threshold

        print(classification_report(y_val_, y_val_pred >= max_threshold))
        print(confusion_matrix(y_val_, y_val_pred >= max_threshold))
        print(
            " The highest f1 score of ",
            max_f1,
            " was recorded for a threshold of ",
            max_threshold,
        )

        self.model_parameters["threshold"] = max_threshold
        self.model_parameters["embedding_dict"] = {
            "embedding_type": self.embedding_type,
            "embedding_model": self.embedding_model,
            "word_to_index_mapping": self.word_to_index_mapping,
            "index_to_embedding_weights": self.index_to_embedding_weights,
        }
        try:

            if model_save_path is not None:

                pd.DataFrame(histories).to_csv(
                    os.path.join(model_save_path, "histories.csv"), index=False
                )

                self.model.save_weights(os.path.join(model_save_path, "model_weight"))
                print(
                    "model weights saved at:",
                    os.path.join(model_save_path, "model_weight"),
                )

                json.dump(
                    self.model_parameters,
                    open(os.path.join(model_save_path, "model_parameter.json"), "w"),
                )
                print(
                    "model parameters saved at:",
                    os.path.join(model_save_path, "model_parameter.json"),
                )

        except Exception as e:
            self.logger.error(
                f"Error occurred while saving the model weights and parameters, error: {e}"
            )
            raise ValueError("please provide the correct model_save_path")

        return self.model, fig

    def inference(
        self,
        text_doc1: Union[str, list, pd.DataFrame] = None,
        text_doc2: Union[str, list, pd.DataFrame] = None,
        model_save_path: str = None,
        threshold: float = None,
    ):

        """
        Function to predict the matching texts using the trained deepER model. It returns two dataframes,
        one containing the matching texts for the optimal threshold and another containing all the possible combinations with a matching score for each pair.

        Parameters
        ----------
        text_doc1 : Union[str, list, pd.DataFrame], optional
            string or list of text documents or dataframe to predict probability with text_doc2, by default None

        text_doc2 : Union[str, list, pd.DataFrame], optional
            string or list of text documents to get probabilities for against text_doc1, by default None

        model_save_path : str, required
            path to the folder to load the model parameters, model weights and model training metrics.
            The folder should contain files with names model_parameters.json, model_weight.index, model_weight.data-00000-of-00001, by default None
        threshold : float, optional
            threshold score to be considered while filtering for the final matches, data points with matching score greater than threshold will be considered a match.
            if threshold is None, the threshold obtained from model parameters will be used

        Returns
        --------
        pd.Dataframe
            dataframe containing the matching texts

        pd.Dataframe
            dataframe containing the all the possible combinations given for inference with a matching score from 0 to 1.
        """

        self.model_save_path = model_save_path
        if self.model_save_path is not None:
            model_param_path = os.path.join(
                self.model_save_path, "model_parameter.json"
            )
            with open(model_param_path, "r") as j:
                self.model_parameters = json.loads(j.read())
        else:
            self.logger.error(
                "model_save_path is not provided, "
                "set parameter model_save_path for the path to the pre trained model folder."
            )
            raise ValueError("model_save_path is not provided")

        embedding_dict = self.model_parameters["embedding_dict"]

        self.embedding_type = embedding_dict["embedding_type"]
        self.embedding_model = embedding_dict["embedding_model"]
        self.word_to_index_mapping = embedding_dict["word_to_index_mapping"]
        self.index_to_embedding_weights = embedding_dict["index_to_embedding_weights"]

        if self.embedding_type == "glove":

            self.logger.info(
                f"embedding used is {self.embedding_type} and embedding path is {self.word_to_index_mapping}"
            )

            if self.word_to_index_mapping is not None:
                with open(self.word_to_index_mapping, "rb") as f:
                    self.map = pkl.load(f)
            else:
                self.logger.error(
                    "word_to_index_mapping path is not provided, "
                    "set parameter word_to_index_mapping for the path to the embedding map file."
                )
                raise ValueError(
                    "path to the embedding map file: word_to_index_mapping"
                )
            self.nan_idx = self.map["word2idx"]["NaN"]
        elif (self.embedding_type == "bert") or (
            self.embedding_type == "sentence-transformers"
        ):
            self.logger.info(
                f"embedding used is {self.embedding_type} and embedding model is {self.embedding_model}"
            )

            tokenizer = AutoTokenizer.from_pretrained(self.embedding_model)
            self.map = dict(tokenizer.vocab)
            self.nan_idx = None
        else:
            self.logger.error(
                "embedding_type is not provided in the model parameters, "
                "set parameter embedding_dict['embedding_type'] for the type of the embedding to be used in model parameters.json.Choose one of 'bert', 'mpnet','glove' "
            )
            raise ValueError(
                "embedding_type is not provided in the model parameters(json file)"
            )

        features = (
            self.model_parameters["text_features"]
            + self.model_parameters["num_features"]
        )
        features = [x.lower() for x in features]

        if isinstance(text_doc1, pd.DataFrame):
            text_doc1.columns = [col.lower() for col in text_doc1.columns]
            if isinstance(text_doc2, pd.DataFrame):
                self.logger.info(
                    " It is recommended to run the two dataframes through LSH before loading to the inference for better and faster results. Load the result from LSH as text_doc1"
                )
                if not (
                    all(
                        x in text_doc1.columns for x in [col + "_1" for col in features]
                    )
                ):
                    self.logger.error(
                        "Rename the dataframe columns or check the given features. Column names should be with '_1' for text_doc1"
                    )
                    raise ValueError(
                        "Given features and text_doc1 column names doesn't match"
                    )
                if not (
                    all(
                        x in text_doc2.columns for x in [col + "_2" for col in features]
                    )
                ):
                    self.logger.error(
                        "Rename the dataframe columns or check the given features. Column names should be with '_2' for text_doc2"
                    )
                    raise ValueError(
                        "Given features and text_doc2 column names doesn't match"
                    )

                df1, df2 = data_frame_split(
                    text_doc1=pd.concat([text_doc1, text_doc2]), features=features
                )

                combos = create_combinations(df1, df2)

            elif text_doc2 is None:

                df1, df2 = data_frame_split(text_doc1=text_doc1, features=features)
                combos = pd.merge(
                    text_doc1, df1, on=[col + "_1" for col in features], how="inner"
                )
                combos = pd.merge(
                    combos, df2, on=[col + "_2" for col in features], how="inner"
                )

            elif isinstance(text_doc2, list):

                self.logger.info(
                    " It is recommended to run the two dataframes through LSH before loading to the inference for better and faster results. Load the result from LSH as text_doc1"
                )
                features = ["feature"]
                text_doc1["feature_1"] = text_doc1.apply(
                    lambda x: " ".join(x.values.astype(str)), axis=1
                )
                text_doc2 = pd.DataFrame({"feature_2": text_doc2})
                df1, df2 = data_frame_split(
                    text_doc1=pd.concat([text_doc1, text_doc2]), features=["feature"]
                )
                combos = create_combinations(df1, df2)

            elif isinstance(text_doc2, str):

                self.logger.info(
                    " It is recommended to run the two dataframes through LSH before loading to the inference for better and faster results. Load the result from LSH as text_doc1"
                )
                features = ["feature"]
                text_doc1["feature_1"] = text_doc1.apply(
                    lambda x: " ".join(x.values.astype(str)), axis=1
                )
                text_doc1["feature_2"] = text_doc2
                df1, df2 = data_frame_split(text_doc1=text_doc1, features=["feature"])
                combos = pd.merge(
                    text_doc1, df1, on=[col + "_1" for col in features], how="inner"
                )
                combos = pd.merge(
                    combos, df2, on=[col + "_2" for col in features], how="inner"
                )

            else:
                raise ValueError(
                    "Given features and text_doc1 column names doesn't match"
                )

        elif isinstance(text_doc1, list):

            self.logger.info(
                " It is recommended to run the lists through LSH before loading to the inference for better and faster results. Load the result from LSH as text_doc1 and keep text_doc2 as None"
            )
            text_doc1 = pd.DataFrame({"feature_1": text_doc1})
            features = ["feature"]
            if isinstance(text_doc2, list):
                text_doc2 = pd.DataFrame({"feature_2": text_doc2})
                df1, df2 = data_frame_split(
                    text_doc1=pd.concat([text_doc1, text_doc2]), features=["feature"]
                )
                combos = create_combinations(df1, df2)

            elif isinstance(text_doc2, str):
                text_doc1["feature_2"] = text_doc2
                df1, df2 = data_frame_split(text_doc1=text_doc1, features=["feature"])
                combos = pd.merge(text_doc1, df1, on=["feature_1"], how="inner")
                combos = pd.merge(combos, df2, on=["feature_2"], how="inner")
            else:
                raise ValueError(
                    "Given features and text_doc1 column names doesn't match"
                )

        elif isinstance(text_doc1, str):

            features = ["feature"]
            if isinstance(text_doc2, str):
                text_doc1 = pd.DataFrame()
                text_doc1["feature_1"] = text_doc1
                text_doc1["feature_2"] = text_doc2
                df1, df2 = data_frame_split(text_doc1=text_doc1, features=["feature"])
                combos = pd.merge(text_doc1, df1, on=["feature_1"], how="inner")
                combos = pd.merge(combos, df2, on=["feature_2"], how="inner")
            else:
                raise ValueError(
                    "Given features and text_doc1 column names doesn't match"
                )
        df_1, df_2 = df1.copy(), df2.copy()
        df1.columns = ["id1"] + features
        df2.columns = ["id2"] + features
        self.df1, self.df2 = convert_text(
            self.map,
            df1,
            df2,
            features,
            embedding_type=self.embedding_type,
            embedding_model=self.embedding_model,
        )

        self.pred_1 = pd.merge(combos[["id1"]], self.df1, how="left", on=["id1"])
        self.pred_2 = pd.merge(combos[["id2"]], self.df2, how="left", on=["id2"])

        self.data = dict()
        self.data = generate_data_dict(
            df_dict=self.data,
            df_dict_values=[self.pred_1, self.pred_2],
            df_dict_keys=["pred_1", "pred_2"],
        )

        try:
            X_test = deep_er_pred_data_transformer(
                self.data,
                padding_limit=self.model_parameters["padding_limit"],
                text_columns=features,
                numeric_columns=[],
                text_nan_idx=self.nan_idx,
                num_nan_val=0,
            )
        except Exception as e:
            self.logger.error(
                f"Error occurred during deepER prediction data transforming {e}"
            )
            raise ValueError("inference data transformation error")

        self._get_model_instance()

        if self.model_save_path is not None:
            model_weight_path = os.path.join(self.model_save_path, "model_weight")
            self.logger.info("Loading model weights")
            self.model.load_weights(model_weight_path)
        else:
            self.logger.error(
                "model_save_path to weight is not provided, "
                "set parameter model_save_path for the path to the folder conatining pre trained model weight."
            )
            raise ValueError("path to the pre trained model weight: model_save_path")

        self.logger.info("Predicting....")
        y_pred = self.model.predict(X_test)[:, 1]

        df1 = self.data["pred_1"]
        df2 = self.data["pred_2"]

        final_df = pd.concat([df1, df2], axis=1)
        final_df["score"] = y_pred

        temp_df = pd.merge(
            final_df[["id1", "id2", "score"]], df_1, on=["id1"], how="inner"
        )
        result_df = pd.merge(
            temp_df, df_2, on=["id2"], how="inner", suffixes=("_1", "_2")
        )
        if threshold is not None:
            matches = result_df.loc[result_df["score"] >= threshold]
        else:
            self.logger.info(
                f'Using model default threshold - {self.model_parameters["threshold"]}'
            )
            matches = result_df.loc[
                result_df["score"] >= self.model_parameters["threshold"]
            ]

        return matches, result_df
