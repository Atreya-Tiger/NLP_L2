import pandas as pd
from itertools import product

from tigernlp.core.utils import MyLogger
from tigernlp.text_matching.deepER.utils import data_frame_split


def generate_non_matches_train(
    text_doc1: pd.DataFrame,
    df1: pd.DataFrame,
    df2: pd.DataFrame,
    non_matches_ratio: int = 100,
    log_level: str = "INFO",
    log_file_path: str = None,
    verbose: bool = True,
):
    """
    This function generates non matches from the given set of matching data based on the non_matches_ration parameters
    If text_doc1 contains 500 matches and non_matches_ratio=100, a training data combination containing 50500(500 matches and 50000 non-matches) will be generated
    Parameters
    ----------
    text_doc1 : pd.DataFrame
        dataframe containing the matching data between df1 and df2.
    label_col : str, optional
        column in the text_doc1 indicating the matching label( whether a given datapoint is matching or not), by default 'match'
    non_matches_ratio : int, optional
        number of non-matches to be generated for each matching data point in text_doc1. , by default 100

    Return
    -------
    pd.DataFrame
        dataframe containing the combinations created using df1 and df2.
    """

    matches_df = text_doc1[text_doc1["match"] == 1]
    non_matches_df = text_doc1[text_doc1["match"] == 0]

    combos = create_combinations(df1, df2)

    all_comb = pd.merge(
        combos, matches_df[["id1", "id2", "match"]], on=["id1", "id2"], how="outer"
    )

    all_comb.match.fillna(0, inplace=True)
    all_comb.columns = all_comb.columns.str.lower()
    all_comb.match = all_comb.match.astype(int)
    all_comb.id1 = all_comb.id1.astype(str)
    all_comb.id2 = all_comb.id2.astype(str)

    match_df = all_comb[all_comb.match == 1]
    non_match_df = all_comb[all_comb.match == 0]

    if non_matches_ratio is None:
        logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger
        logger.warning(
            "non_matches_ratio is set to None, this will result in using all the negative samples. Could lead to highly unbalanced distribution"
        )

        non_match_frac = 1
    else:
        non_match_frac = (match_df.shape[0] * non_matches_ratio) / non_match_df.shape[0]

    if non_match_frac > 1:
        non_match_frac = 1

    # if non matches already present, some of the genrated non matches will be dropped
    non_match_df = non_match_df.sample(frac=non_match_frac)
    non_match_df_size = non_match_df.shape[0]
    non_match_df = pd.concat([non_matches_df, non_match_df])
    non_match_df.drop_duplicates(inplace=True)
    non_match_df = non_match_df.iloc[:non_match_df_size]

    combinations = pd.concat([match_df, non_match_df])

    return combinations


def create_combinations(df1: pd.DataFrame, df2: pd.DataFrame):
    """
    Function creates all the possible combinations between the two dataframes df1 and df2

    Parameters
    ----------
    df1 : pd.DataFrame
        dataframe containing first set of data to be matched
    df2 : pd.DataFrame
        dataframe containing second set of data to be matched

    Returns
    -------
    pd.DataFrame
        dataframe containing all the possible combinations between the two dataframes df1 and df2

    """

    prod_list = []
    prod_list = list(product(df1["id1"].unique(), df2["id2"].unique()))

    mix_ids = pd.DataFrame(data=prod_list, columns=["id1", "id2"])
    combos = pd.merge(mix_ids, df1, on=["id1"], how="inner")
    combos = pd.merge(combos, df2, on=["id2"], how="inner")

    combos.drop_duplicates(inplace=True)

    return combos
