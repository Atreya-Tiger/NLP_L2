import networkx as nx
import pandas as pd
from datasketch.lsh import MinHashLSH
from datasketch.minhash import MinHash
from itertools import chain, combinations

from tigernlp.core.utils import MyLogger


class LSH:
    """LSH algorithm helps you to generate all the similar candidates based on the Jaccard Similarity.
    This reduces the time complexity for contextual based similarity by reducing the number of candidates.

    There are two ways in which this class can be used

    *Option 1*: Generating Minhash separately to create candidates
     - get the minhash for all the text documents and experiment for different thresholds to reduce the experimentation time
    *Opttion 2*: Generating candidates directly
     - generate the minhash within the function, this can be used when you want to run this module only once with fixed threshold

    Parameters
    ----------
    log_level : str, optional
        Level or severity of the events needed to be tracked, by default "INFO"
    log_file_path: str, optional
        File path to save the logs, by default None
    verbose: bool,
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> from tigernlp.text_matching.api import LSH
    >>> sequence = ['made from all-natural free-range chicken and all-natural free-range venison raised without added hormones or antibiotics no artificial preservatives, antibiotics, fillers, coloring, or added hormones', 'grain free']
    >>> labels = ['Made in the USA', 'Grain Free', 'No Artificial Preservatives']
    >>> model_object = LSH()
    >>> #Option 1
    >>> # Generate the minhash and the sentence indentifier dictionary
    >>> min_dict1, norm_dict1 = model_object.get_minhash(sequence, prefix='m')
    >>> min_dict2, norm_dict2 = model_object.get_minhash(labels, prefix='n')
    >>> # Query for candidate pairs
    >>> df, _, _ = model_object.get_candidate_pairs(min_dict1=min_dict1, min_dict2=min_dict2)
    >>> df_sentence_pair = model_object.candidate_pair_key_to_sentence_mapping(df=df, norm_dict1=norm_dict1, norm_dict2=norm_dict2)
    >>> #Option 2
    >>> df, norm_dict1, norm_dict2 = model_object.get_candidate_pairs(text_doc1=sequence, text_doc2=labels)
    >>> df_sentence_pair = model_object.candidate_pair_key_to_sentence_mapping(df=df, norm_dict1=norm_dict1, norm_dict2=norm_dict2)
    """

    def __init__(self, log_level="INFO", log_file_path=None, verbose=True):
        """LSH class initialization"""
        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def _generate_set(self, text_doc=list(), prefix="m"):
        """Convert sentences to the unique tokenized set of words and creates a unique identifier for each sentence using the prefix parameter

        Example - ["This is the example for the LSH matching"],
        Output - {"This", "is", "the", "example", "for", "LSH", "matching"}

        Parameters
        ----------
        text_doc : str, optional
            list of sentences, by default list()
        prefix : str, optional
            prefix of unique identifier for each sentence, by default "m"

        Returns
        -------
        set_dict
            dict, dictionary with key as sentence identifier and value as set(sentence),
            Example - {'m1' : {"This", "is", "the", "example", "for", "LSH", "matching"}}
        norm_dict
            dict, dictiory with key as sentence indentifier and value as actual sentence,
            Example - {'m1' : "This is the example for the LSH matching"}
        """
        set_dict = {}
        norm_dict = {}
        count = 1
        for doc in text_doc:
            temp_list = []
            for shingle in doc.split(" "):
                temp_list.append(shingle.lower())
            set_dict["{0}{1}".format(prefix, count)] = set(temp_list)
            norm_dict["{0}{1}".format(prefix, count)] = doc
            count += 1
        return (set_dict, norm_dict)

    def get_minhash(self, text_doc=list(), set_dict={}, prefix="m", num_perm=128, seed=1):
        """Generate minhash for the input sentence or set dictinary values

        Parameters
        ----------
        text_doc : str, optional
            list of sentences, by default list()
        set_dict : dict, optional
            dict, dictionary with key as sentence identifier and value as set(sentence), by default {}
            Example - {'m1' : {"This", "is", "the", "example", "for", "LSH", "matching"}
            if empty, dictionaty will be created using the text_doc column
        prefix : str, optional
            unique identifier for the text_doc, by default "m"
            if len(set_dict)>0, prefix parameter will not be used
        num_perm : int, optional
            number of random permutation functions, by default 128
        seed : int, optional
            the random seed controls the set of random permutation functions generated for this MinHash, by default 1

        Returns
        -------
        min_dict
            dict, dictionary with key as set_dict key and value as minhash for the respective sentence,
            Example - {'m1' : minhash object}
        norm_dict
            {}, if set_dict is not empty else dictiory with key as sentence indentifier and value as actual sentence,
            Example - {'m1' : "This is the example for the LSH matching"}

        Raises
        ------
        ValueError
            if both text_doc and set_dict is provided as an input OR if both text_doc and set_dict are empty
        """

        norm_dict = {}

        if len(text_doc) > 0 and len(set_dict) > 0:
            self.logger.error("Both text document and set dictionary can not be given as an input. Please pass only one parameter")
            raise ValueError("Both text document and set dictionary can not be given as an input. Please pass only one parameter")
        elif len(text_doc) == 0 and len(set_dict) == 0:
            self.logger.error("Both text document and set dictionary patameter is empty. Please pass values in one of the parameter")
            raise ValueError("Both text document and set dictionary parameter is empty. Please pass values in one of the parameter")

        if len(text_doc) > 0 and len(set_dict) == 0:
            set_dict, norm_dict = self._generate_set(text_doc, prefix=prefix)

        min_dict = {}
        count = 1
        for val in set_dict.values():
            m = MinHash(num_perm=num_perm, seed=seed)
            for shingle in val:
                m.update(shingle.encode("utf8"))
            min_dict["{0}{1}".format(prefix, count)] = m
            count += 1
        return (min_dict, norm_dict)

    def _add_minhash(self, lsh_model=None, min_dict={}):
        """Add minhash to the LSH model for query

        Parameters
        ----------
        lsh_model : LSH model object, optional
            LSH model object, by default None
            if None, will generate the default LSH model
        min_dict : dict, optional
            min_dict for minhash generated using get_minhash function, by default {}

        Returns
        -------
        LSH model object
            LSH model object with all the keys of min_dict added in the model for query

        Raises
        ------
        ValueError
            if Minhash dictionary min_dict is empty
        """

        if len(min_dict) == 0:
            self.logger.error(
                "Minhash dictionary is empty and can not be used to add minhash to the lsh model. Please pass minhash dictionary"
            )
            raise ValueError(
                "Minhash dictionary is empty and can not be used to add minhash to the lsh model. Please pass minhash dictionary"
            )

        if lsh_model is None:
            self.logger.info("Generating default lsh model")
            lsh_model = self._get_lsh_model()

        self.logger.info("Adding minhash keys to the lsh model")

        with lsh_model.insertion_session() as session:
            for key in min_dict.keys():
                session.insert(key, min_dict[key])

        # for key in min_dict.keys():
        #     lsh_model.insert(key, min_dict[key])

        return lsh_model

    def _get_lsh_model(self, threshold=0.3, num_perm=128):
        """Generate LSH model object

        Parameters
        ----------
        threshold : float, optional
            the Jaccard similarity threshold between 0.0 and 1.0. The initialized LSH will be optimized for the threshold by minizing the false positive and false negative, by default 0.3
        num_perm : int, optional
            the number of permutation functions used by the MinHash to be indexed, by default 128

        Returns
        -------
        LSH model object
            LSH model object created using the threshold and num_perm
        """
        lsh = MinHashLSH(threshold=threshold, num_perm=num_perm)
        return lsh

    def candidate_pair_key_to_sentence_mapping(self, df=pd.DataFrame, norm_dict1={}, norm_dict2={}):
        """Function to map the candidate pairs in the dataframe to the actual sentences using norm_dict1 and norm_dict2 dictionaries

        Parameters
        ----------
        df : pd.DataFrame, optional
            candidate pair output dataframe using function get_candidate_pairs, by default pd.DataFrame
        norm_dict1 : dict, optional
            used for column "candidate_pair_1" or "candidate_pair_2" to map keys to actual sentences using dictionary generated from get_candidate_pairs or get_minhash function, by default {}
        norm_dict2 : dict, optional
            used for column "candidate_pair_1" or "candidate_pair_2" to map keys to actual sentences using dictionary generated from get_candidate_pairs or get_minhash function, by default {}
            if empty, all mappings will be done using norm_dict1
        """

        if df.shape[0] <= 0:
            self.logger.error("Input dataframe of candidate pair is empty")
            raise ValueError("Input dataframe of candidate pair is empty")

        if len(norm_dict1) == 0:
            self.logger.error("Mapping dictionary norm_dict1 is empty")
            raise ValueError("Mapping dictionary norm_dict1 is empty")

        df_mapping_1 = pd.DataFrame.from_dict(norm_dict1, orient="index").reset_index()
        df_mapping_1.columns = ["key", "sentence"]

        if len(norm_dict2) > 0:
            temp = pd.DataFrame.from_dict(norm_dict2, orient="index").reset_index()
            temp.columns = ["key", "sentence"]
            df_mapping_1 = pd.concat([df_mapping_1, temp], ignore_index=True)

        output = pd.merge(df, df_mapping_1, left_on="candidate_pair_1", right_on="key")
        output.drop(columns=["key"], inplace=True)
        output.rename(columns={"sentence": "candidate_pair_1_sentence"}, inplace=True)

        output = pd.merge(output, df_mapping_1, left_on="candidate_pair_2", right_on="key")
        output.drop(columns=["key"], inplace=True)
        output.rename(columns={"sentence": "candidate_pair_2_sentence"}, inplace=True)

        return output

    def get_candidate_pairs(
        self,
        text_doc1=list(),
        text_doc2=list(),
        min_dict1={},
        min_dict2={},
        num_perm=128,
        seed=1,
        threshold=0.3,
        generate_pairs_within_same_list=False,
    ):
        """Generates candidate pairs for all sentences within a list or between two list

        Parameters
        ----------
        text_doc1 : str, optional
            list of text documents, by default list()
        text_doc2 : str, optional
            list of text documents, by default list()
        min_dict1 : dict, optional
            minhash dict generated using the get_minhash function for text_doc1, by default {}
            if empty, will be generated for text_doc1 using the get_minhash function
        min_dict2 : dict, optional
            minhash dict generated using the get_minhash function for text_doc2, by default {}
            if empty, will be generated for text_doc2 using the get_minhash function
        num_perm : int, optional
            number of random permutation functions used by the MinHash, by default 128
        seed : int, optional
            the random seed controls the set of random permutation functions generated for the MinHash, by default 1
        threshold : float, optional
            the Jaccard similarity threshold between 0.0 and 1.0. The initialized LSH will be optimized for the threshold by minizing the false positive and false negative, by default 0.3
        generate_pairs_within_same_list : bool, optional
            option to get the candidate pair within the text_doc1 and text_doc2 sentences when both list are non-empty, by default False

            Example - sentences identifier in text_doc1 : [m1, m2, m3], sentences identifier in text_doc2 : [n1, n2, n3]
            if True, candidate pairs will be [('n1', 'n2'), ('m3', 'n1'), ('m2', 'n3'), ('m3', 'n2')]

            if False, candidate pairs will be [('m3', 'n1'), ('m2', 'n3'), ('m3', 'n2')]

        Returns
        -------
        df
            pd.DataFrame, dataframe with all candidate pairs as column "candidate_pair_1" and "candidate_pair_2"

        Raises
        ------
        ValueError
            if all the input parameters text_doc1, text_doc2, min_dict1 and min_dict2 is empty OR if both text_doc and min_dict are provided as an input OR if text_doc1 or min_dict1 is empty but text_doc2 or min_dict2 is non-empty

        """
        try:

            if not isinstance(text_doc1, list) or not isinstance(text_doc2, list):
                self.logger.error("Please provide the text documents as list. Other data formats are not supported")
                raise ValueError("Please provide the text documents as list. Other data formats are not supported")

            if len(text_doc1) == 0 and len(text_doc2) == 0 and len(min_dict1) == 0 and len(min_dict2) == 0:
                self.logger.error("Both text document and set dictionary patameter is empty. Please pass values in one of the parameter")
                raise ValueError("Both text document and set dictionary parameter is empty. Please pass values in one of the parameter")

            if (len(text_doc1) > 0 and len(min_dict1) > 0) or (len(text_doc2) > 0 and len(min_dict2) > 0):
                self.logger.error("Both text document and set dictionary can not be given as an input. Please pass only one parameter")
                raise ValueError("Both text document and set dictionary can not be given as an input. Please pass only one parameter")

            if (len(text_doc1) == 0 and len(text_doc2) > 0) or (len(min_dict1) == 0 and len(min_dict2) > 0):
                self.logger.error(
                    "First input paramter text_doc1 or set_dict1 empty but second input parameter text_doc2 or set_dict2 non-empty. Please provide values to first input paramters"
                )
                raise ValueError(
                    "First input paramter text_doc1 or set_dict1 empty but second input parameter text_doc2 or set_dict2 non-empty. Please provide values to first input paramters"
                )

            if min_dict1.keys():
                if set(min_dict1.keys()).intersection(set(min_dict2.keys())):
                    self.logger.error("Common key between min_dict1 and min_dict2. Please insert a different prefix for both dictionaries")
                    raise ValueError("Common key between min_dict1 and min_dict2. Please insert a different prefix for both dictionaries")

            if min_dict2.keys():
                if set(min_dict1.keys()).intersection(set(min_dict2.keys())):
                    self.logger.error("Common key between min_dict1 and min_dict2. Please insert a different prefix for both dictionaries")
                    raise ValueError("Common key between min_dict1 and min_dict2. Please insert a different prefix for both dictionaries")

            norm_dict1 = {}
            norm_dict2 = {}
            if len(text_doc1) > 0:
                self.logger.info("Generating minhash for text_doc1")
                min_dict1, norm_dict1 = self.get_minhash(text_doc=text_doc1, prefix="m", num_perm=num_perm, seed=seed)

            if len(text_doc2) > 0:
                self.logger.info("Generating minhash for text_doc2")
                min_dict2, norm_dict2 = self.get_minhash(text_doc=text_doc2, prefix="n", num_perm=num_perm, seed=seed)

            if len(min_dict1) > 0 and len(min_dict2) > 0:
                self.logger.info("Adding minhash for text_doc1 in the LSH model")

                lsh = self._get_lsh_model(threshold=threshold, num_perm=num_perm)
                lsh = self._add_minhash(lsh_model=lsh, min_dict=min_dict1)

                self.logger.info("Generating candidate pair between text_doc1 and text_doc2")
                candidate_pair = {}
                for key in min_dict2.keys():
                    candidate_pair[key] = lsh.query(min_dict2[key])

            elif len(min_dict1) > 0 and len(min_dict2) == 0:
                self.logger.info("Adding minhash for text_doc1 in the LSH model")

                lsh = self._get_lsh_model(threshold=threshold, num_perm=num_perm)
                lsh = self._add_minhash(lsh_model=lsh, min_dict=min_dict1)

                self.logger.info("Generating candidate pair within the text_doc1")
                candidate_pair = {}
                for key in min_dict1.keys():
                    candidate_pair[key] = lsh.query(min_dict1[key])

            if generate_pairs_within_same_list or len(min_dict2) == 0:
                if generate_pairs_within_same_list:
                    self.logger.info("Including canidate pairs within the text_doc1 and text_doc2 documents")
                G = nx.Graph(candidate_pair)
                candidate_pair_all = [sorted(c) for c in nx.connected_components(G)]
                all_pairs = [list(combinations(candidate, 2)) for candidate in candidate_pair_all]
                all_pairs = list(chain(*all_pairs))
                df = pd.DataFrame(all_pairs)
                if df.shape[0] > 0:
                    df.columns = ["candidate_pair_1", "candidate_pair_2"]
                else:
                    df = pd.DataFrame(columns=["candidate_pair_1", "candidate_pair_2"])

            else:
                df = pd.DataFrame.from_dict(candidate_pair, orient="index")
                df = df.reset_index().rename(columns={"index": "candidate_pair_2"})
                df = pd.melt(df, id_vars="candidate_pair_2")
                df = df[df["value"].notna()].drop(columns=["variable"])
                df.rename(columns={"value": "candidate_pair_1"}, inplace=True)
                df = df[["candidate_pair_1", "candidate_pair_2"]]

            return df, norm_dict1, norm_dict2
        except Exception as e:
            self.logger.error(f"Error occurred during LSH candidate generation {e}")
