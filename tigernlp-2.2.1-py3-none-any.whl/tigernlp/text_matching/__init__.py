"""This module contains text matching techniques like fuzzy wuzzy, semantic match, zero shot classification.
This can be used to compute similarity between two sentences/words.
"""
