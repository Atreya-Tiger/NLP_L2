"""
This module provides functionality for Span categorization including data preparation, training, and inferencing.
"""
