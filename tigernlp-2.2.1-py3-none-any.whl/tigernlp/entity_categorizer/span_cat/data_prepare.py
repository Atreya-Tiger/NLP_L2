import ast
import os
import pandas as pd
import spacy
from spacy.tokens import DocBin

from tigernlp.core.utils import MyLogger
from tigernlp.custom_spacy.api import generate_index_labels


class SpanCatSpacyDataPrep:
    """The SpanCatSpacyDataPrep class is a utility class that provides functionalities for preparing data in the spacy format for span categorization.
    It has the following methods:

    1. get_span_cat_index: For a given text, this helper function adds the tuple of (start_index, end_index, span_label) for the span present in the text.

    2. generate_corpus: Generates a corpus in spacy format from a dataframe.

    Parameters
    ----------
    log_file_path : str
        Full path of the log file to save data prepare logs at, by default None.
    log_level : str, optional
        Logging level to write logs, by default "INFO"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True.

    Examples
    ---------
    >>> import pandas as pd
    >>> from tigernlp.entity_categorizer.span_cat.api import SpanCatSpacyDataPrep
    >>> span_cat_data_prep = SpanCatSpacyDataPrep()
    >>> df = pd.DataFrame({
    >>>                    'text': ['This is a sentence about apples.', 'This is a sentence about cellphone'],
    >>>                    'fruit': ['apples', []],
    >>>                    'device': [[], 'cellphone']
    >>>                   })
    >>> lst = [
    >>>        {'col_name': 'fruit', 'entity_label': 'FRUIT'},
    >>>        {'col_name': 'device', 'entity_label': 'DEVICE'}
    >>>        ]
    >>> df_with_index = span_cat_data_prep.get_span_cat_index(df, 'text', span_category_details=lst)
    >>> df_with_index['text']
    >>> ['This is a sentence about apples.', 'This is a sentence about cellphone']
    >>> df_with_index['fruit']
    >>> [['apples'], []]
    >>> df_with_index['device']
    >>> [[], ['cellphone']]
    >>> df_with_index['entity_index']
    >>> [[(26, 31, 'FRUIT')], [(26, 34, 'DEVICE')]]
    >>> nlp = spacy.load("en_core_web_sm")
    >>> span_cat_data_prep.generate_corpus(dataframe = df_with_index,
    >>>                                     textcol = 'text',
    >>>                                     span_index_col = 'spans_index',
    >>>                                     basename = 'train',
    >>>                                     nlp = nlp,
    >>>                                     corpus_path = 'project_folder/data/corpus/')

    """

    def __init__(self, log_file_path: str = None, log_level: str = "INFO", verbose: bool = True):
        """SpanCatSpacyDataPrep class initialization.

        Parameters
        ----------
        log_file_path : str
            Full path of the log file to save training logs at
        log_level : str, optional
            Logging level to write logs, by default "INFO"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True

        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def get_span_cat_index(self, dataframe: pd.DataFrame, textcol: str, span_category_details: list):
        """This function adds a column to the dataframe containing a list of tuples, with each tuple containing the start index, end index, and label associated with an span.

        Parameters
        ----------
        dataframe : pd.DataFrame
            Dataframe containing the text, entity and label column.
        textcol : str
            Column name of the text column in the dataframe.
        span_category_details : list
            list of dictionary with column name of the span category as key and the category name in the value.

        Returns
        -------
        dataframe : pd.DataFrame
            Dataframe with additional column 'span_index' which contains the tuple of start_index, end_index and label of an span.

        Raises
        ------
        TypeError
            raises type error if dataframe is not in pd.Dataframe format.
        ValueError
            raises value error when data frame is empty.
        NameError
            raises name error if textcol is not present in dataframe column.
        Exception
            raises exception if an error occurs while adding the 'span_index' column to the dataframe.

        Examples
        --------
        >>> import pandas as pd
        >>> from tigernlp.entity_categorizer.span_cat.api import SpanCatSpacyDataPrep
        >>> span_cat_data_prep = SpanCatSpacyDataPrep()
        >>> # Prepare the training data
        >>> df = pd.DataFrame({
        >>>                    'text': ['This is a sentence about apples.', 'This is a sentence about cellphone'],
        >>>                    'fruit': [['apples'], []],
        >>>                    'device': [[], ['cellphone']]
        >>>                   })
        >>> lst = [
        >>>        {'col_name': 'fruit', 'entity_label': 'FRUIT'},
        >>>        {'col_name': 'device', 'entity_label': 'DEVICE'}
        >>>        ]
        >>> df_with_index = span_cat_data_prep.get_span_cat_index(df, 'text', span_category_details=lst)
        >>> df_with_index['text']
        >>> ['This is a sentence about apples.', 'This is a sentence about cellphone']
        >>> df_with_index['fruit']
        >>> ['apples', []]
        >>> df_with_index['device']
        >>> [[], 'cellphone']
        >>> df_with_index['spans_index']
        >>> [[(26, 31, 'FRUIT')], [(26, 34, 'DEVICE')]]

        """
        if not isinstance(dataframe, pd.DataFrame):
            self.logger.error("dataframe must be a pd.DataFrame.")
            raise TypeError("dataframe must be a pd.DataFrame.")
        if not (dataframe.shape[0]) > 0:
            self.logger.error("Input dataframe is of incorrect type in generate_corpus")
            raise ValueError("Input dataframe is of incorrect type in generate_corpus")
        elif textcol not in dataframe.columns.to_list():
            self.logger.error(f"Given column is not a valid column in the dataframe - {textcol}")
            raise NameError(f"{textcol} is not present in the dataframe.")
        try:
            self.column_list = []
            for key in span_category_details:
                col_name = key["col_name"]
                self.column_list.append(col_name)
                if col_name not in dataframe.columns:
                    self.logger.error(f"Column {col_name} is either incorrect or does not exist in the dataframe")
                    raise NameError(f"Column {col_name} is either incorrect or does not exist in the dataframe")

            for col in self.column_list:
                dataframe[col] = dataframe[col].apply(lambda a: ast.literal_eval(str(a)))

            dataframe = self._check_df(dataframe.copy())
            self.logger.info(f"Generating span index for the available spans in {span_category_details}")
            self.span_index_col = "spans_index"
            cols_todrop = []
            nlp = spacy.load("en_core_web_sm")
            for key in span_category_details:
                entity_col = key["col_name"]
                span_cat = key["entity_label"]
                dataframe[self.span_index_col + entity_col] = dataframe.apply(
                    lambda row: generate_index_labels(
                        row[textcol],
                        row[entity_col],
                        [span_cat] * len(row[entity_col]),
                        nlp,
                    ),
                    axis=1,
                )
                cols_todrop.append(self.span_index_col + entity_col)

            dataframe[self.span_index_col] = dataframe[cols_todrop].sum(axis=1)
            dataframe.drop(labels=cols_todrop, axis=1, inplace=True)
            self.logger.info("Generated span index for the available spans.")

            return dataframe

        except Exception as e:
            self.logger.error(
                f"An error occurred while adding the 'spans_index' column to the dataframe. The error message is: {e}. Please check the input dataframe and provided column names for errors."
            )
            raise Exception(
                f"An error occurred while adding the 'spans_index' column to the dataframe. The error message is: {e}. Please check the input dataframe and provided column names for errors."
            )

    def generate_corpus(
        self,
        dataframe: pd.DataFrame,
        textcol: str,
        span_index_col: str,
        basename: str,
        nlp: spacy.language.Language,
        corpus_path: str,
    ):
        """This function generates a corpus in spacy format from a dataframe.

        Parameters
        ----------
        dataframe : pd.DataFrame
            Dataframe containing the text and entity_index column.
        textcol : str
            Column name of the text column in the dataframe.
        span_index_col : str
            Column name of the entity_index column in the dataframe.
        basename : str
            name for the generated corpus file. Example - "train", "test", "val"
        nlp : spacy.language.Language
            Spacy language model.
        corpus_path : str
            Path to save the generated corpus. Example - 'project_folder/data/corpus/'

        Returns
        -------
            The function does not return any value. It saves the corpus in the specified corpus_path.

        Raises
        ------
        TypeError
            raises type error if dataframe is not in pd.Dataframe format.
        ValueError
            raises value error when dataframe is empty.
        NameError
            raises name error if textcol is not present in dataframe column.
        Exception
            raises exception if an error occurs during the generation of the corpus.

        Examples
        --------
        >>> import pandas as pd
        >>> from tigernlp.entity_categorizer.span_cat.api import SpanCatSpacyDataPrep
        >>> df = pd.DataFrame({
        >>>                'text': ['This is a sentence about apples.', 'This is a sentence about cellphone'],
        >>>                'fruit': ['apples', []],
        >>>                'device': [[], 'cellphone']
        >>>                'span_index': [[(26, 31, 'FRUIT')], [(26, 34, 'DEVICE')]]
        >>>                  })
        >>> span_cat_data_prep = SpanCatSpacyDataPrep()
        >>> nlp = spacy.load("en_core_web_sm")
        >>> span_cat_data_prep.generate_corpus(dataframe = df_with_index,
        >>>                                     textcol = 'text',
        >>>                                     span_index_col = 'spans_index',
        >>>                                     basename = 'train',
        >>>                                     nlp = nlp,
        >>>                                     corpus_path = 'project_folder/data/corpus/')

        """
        if not isinstance(dataframe, pd.DataFrame):
            self.logger.error("dataframe must be a pd.DataFrame.")
            raise TypeError("dataframe must be a pd.DataFrame.")
        if not (dataframe.shape[0]) > 0:
            self.logger.error("Input dataframe is empty")
            raise ValueError("Input dataframe is empty")
        elif textcol not in dataframe.columns.to_list():
            self.logger.error(f"Given column is not a valid column in the dataframe - {textcol}")
            raise NameError(f"{textcol} is not present in the dataframe.")
        elif span_index_col not in dataframe.columns.to_list():
            self.logger.error(f"Given column is not a valid column in the dataframe - {span_index_col}")
            raise NameError(f"{span_index_col} is not present in the dataframe.")

        if not os.path.exists(corpus_path):
            os.makedirs(corpus_path)
        try:
            db = DocBin()
            for text, spans in zip(dataframe[textcol], dataframe[span_index_col]):
                doc = nlp.make_doc(text)
                span_lst = []
                if isinstance(spans, str):
                    spans = ast.literal_eval(spans)
                for start, end, label in spans:
                    span = doc.char_span(start, end, label=label)
                    if span is not None:
                        span_lst.append(span)

                if len(span_lst) == 0:
                    continue

                doc.spans["sc"] = span_lst
                db.add(doc)

            db.to_disk(os.path.join(corpus_path, f"{basename}.spacy"))

        except Exception as e:
            self.logger.error(f"An error occurred while generating the corpus in the spacy format. The error message is: {e}.")
            raise Exception(f"An error occurred while generating the corpus in the spacy format. The error message is: {e}.")

    def _check_df(self, dataframe):
        """Helper function to check and filter data for rows with no spans for any span category.

        Parameters
        ----------
        dataframe : pd.DataFrame
            dataframe to check for empty spans

        Returns
        -------
        dataframe : pd.DataFrame
            returns clean dataframe

        """
        try:
            def all_enitity_func(x, all_enitity_ls):
                s = []
                for i in all_enitity_ls:
                    s = s + x[i]
                return s

            dataframe["all_enitity"] = dataframe.apply(lambda a: all_enitity_func(a, self.column_list), axis=1)
            dataframe["temp_len"] = dataframe["all_enitity"].apply(lambda a: len(a))
            df_temp_len = dataframe[dataframe["temp_len"] <= 0]
            if len(df_temp_len) > 0:
                self.logger.info(f"Dataframe with empty spans for columns {self.column_list}")
                self.logger.info(f"Indexs - {df_temp_len.index}")
                self.logger.warning(
                    f"Removed {df_temp_len.shape[0]}, {df_temp_len.shape[0]/dataframe.shape[0]*100}% of records with empty spans for all {self.column_list}"
                )
                dataframe = dataframe[dataframe["temp_len"] > 0]
            del dataframe["temp_len"]
            del dataframe["all_enitity"]
            return dataframe
        except Exception as e:
            self.logger.error(f"Error occurred during checking dataframe for no spans for any span category.\n {e}")
            raise Exception(f"Error occurred during checking dataframe for no spans for any span category.\n {e}")
