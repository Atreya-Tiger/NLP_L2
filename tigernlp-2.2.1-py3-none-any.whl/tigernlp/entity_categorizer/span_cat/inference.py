import ast
import math
import numpy as np
import os
import pandas as pd
import random
import spacy
import tqdm
import warnings
from typing import Union

from tigernlp.core.utils import MyLogger, save_df_as_json


class SpanCatInference:
    """Span-cat inference class with utilities to infer the results for the span categorizer model.

    Parameters
    ----------
    log_file_path : str
        Full path of the log file to save training logs at
    log_level : str, optional
        Logging level to write logs, by default "INFO"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Examples
    --------
    >>> import pandas as pd
    >>> from tigernlp.entity_categorizer.span_cat.api import SpanCatInference
    >>> df_inference = pd.read_csv('sentence_processed_data_10k.csv)
    >>> model_base_path = os.path.join("data", "nlp_models", "entity_categorizer", "span_cat", "sample_model_v1")
    >>> model_path = os.path.join(model_base_path, "model-best")
    >>> config={"text_col": "processed_text_sentence", "model_path": model_path}
    >>> infer_ob = SpanCatInference()
    >>> inf_output = infer_ob.inference(df_inference.copy(), config)
    """

    def __init__(self, log_level="WARNING", log_file_path=None, verbose=True):
        """SpanCatInference class class initialization.

        Parameters
        ----------
        log_file_path : str
            Full path of the log file to save training logs at
        log_level : str, optional
            Logging level to write logs, by default "WARNING"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True
        """
        random.seed(a=2022)
        np.random.seed(seed=2022)
        self.logger = MyLogger(
            level=log_level, log_file_path=log_file_path, verbose=verbose
        ).logger

    def _func_to_get_span(self, docs: list):
        """Fuction to get the spans for the span categories.

        Parameters
        ----------
        docs : list
            list of nlp docs object for the required sentences. Example - docs = list(ner_model.pipe(sentences, batch_size=batch_size))

        Returns
        -------
        pd.DataFrame
            dataframe with the spans for each span category for the provided docs
        """
        try:
            pbar = tqdm.tqdm(total=len(docs))
            ls = []
            for doc in docs:
                try:
                    ls.append(
                        (
                            doc.text,
                            [
                                (span.text, span.label_, np.round(c, 5))
                                for span, c in zip(
                                    doc.spans["sc"], doc.spans["sc"].attrs["scores"]
                                )
                            ],
                        )
                    )

                except Exception as e:
                    self.logger.error(f"Error while getting spans:{e}")
                    warnings.warn(f"Error while getting spans:{e}")
                pbar.update(1)
            pbar.close()

            main_df = pd.DataFrame(ls, columns=[self.text_col_name, "spans"])

            for pipeline in sorted(self.ner_model.pipe_labels["spancat"]):
                main_df[pipeline] = main_df["spans"].apply(
                    lambda a: [i[0] for i in a if i[1] == pipeline]
                )
                main_df[pipeline + "_CONFIDENCE"] = main_df["spans"].apply(
                    lambda a: [i[2] for i in a if i[1] == pipeline]
                )
            main_df = main_df.drop(["spans"], axis=1)
            self.logger.info("Getting spans successful.")
            return main_df
        except Exception as e:
            self.logger.error(f"Error while getting spans:{e}")
            Exception(f"Error while getting spans:{e}")

    def inference(
        self,
        text_doc: Union[str, list, pd.DataFrame] = list(),
        config: dict = {"text_col": "processed_text_sentence", "model_path": ""},
        file_path_json: str = None,
        parallel_processing: bool = False,
        n_core: int = -1,
    ):
        """Function to get the spans associated with the span categories available in spacy span categorizer model.

        Parameters
        ----------
        text_doc : Union[str, list, pd.DataFrame], optional
            string or list of text documents or dataframe to get the span categories, by default list()
        config : dict, optional
            config details for the inference, by default {"text_col": "processed_text_sentence", "model_path": ""}

            "text_col" : str
                text column name in the text_doc dataframe, by default "processed_text_sentence"
            "model_path" : str
                path for the span categorizer model to be used for inference, Example - "data/nlp_models/entity_categorizer/span_cat/model-best"
        file_path_json : str, optional
            path to save the json output file, by default None
            if None, json file will not be created.
            Json file path should include file name, example - "data/json_file_name.json", please make sure that the provided folder strucutre exists
        parallel_processing : bool, optional
            Whether to use parallel processing, by default False
        n_core : int, optional
            number of concurrent workers, by default -1 i.e., use all available workers

        Returns
        -------
        pd.DataFrame
            dataframe with the span categories as column with list of spans associated with the category.

            Example -
            sentence = ``Try incorporating ginger, oranges, blueberries, tomatoes, salmon, dark chocolate, green tea, garlic and apples to your diet.``,
            BENEFIT = [diet],
            BRAND = [],
            FLAVOR = [],
            INGREDIENT = [ginger, oranges, blueberries, tomatoes, dark chocolate, garlic, apples],
            OCASSION = [],
            PRODUCT = [oranges, salmon, dark chocolate, green tea, apples]

        Examples
        --------
        >>> import pandas as pd
        >>> from tigernlp.entity_categorizer.span_cat.api import SpanCatInference
        >>> df_inference = pd.read_csv('sentence_processed_data_10k.csv)
        >>> model_base_path = os.path.join("data", "nlp_models", "entity_categorizer", "span_cat", "sample_model_v1")
        >>> model_path = os.path.join(model_base_path, "model-best")
        >>> config={"text_col": "processed_text_sentence", "model_path": model_path}
        >>> infer_ob = SpanCatInference()
        >>> inf_output = infer_ob.inference(df_inference.copy(), config)
        """
        # TODO - add meta column option in the config
        # TODO - return jsonl as an output
        try:
            self.config = config

            if self.config is None:
                raise ValueError(f"Bad input passed to config_obj {self.config}")

            if (text_doc is None) or (len(text_doc) <= 0):
                raise ValueError(f"Bad input passed to text_doc {text_doc}")

            if (
                not isinstance(text_doc, pd.DataFrame)
                and not isinstance(text_doc, str)
                and not isinstance(text_doc, list)
            ):
                raise ValueError(
                    f"Invalid data type {type(text_doc)} provided for text_doc. Please pass a dataframe, list or string"
                )

            self.model_path = config["model_path"]
            if not os.path.exists(self.model_path):
                raise OSError(
                    f"Model path {self.model_path} does not exist. Please provide a valid path"
                )

            if isinstance(text_doc, str):
                self.text_col_name = "text_inference"
                df_input = pd.DataFrame({self.text_col_name: [text_doc]})
                # TODO - remove with meta data option, not required for string
                # unique_id_col = "unique_id"
                # df_input[unique_id_col] = df_input.index

            if isinstance(text_doc, list):
                if not all(isinstance(x, str) for x in text_doc):
                    raise ValueError("All elements of the list should be a string")
                self.text_col_name = "text_inference"
                df_input = pd.DataFrame({self.text_col_name: text_doc})

                # TODO - remove with meta data option, not required for list
                # unique_id_col = "unique_id"
                # df_input[unique_id_col] = df_input.index

            if isinstance(text_doc, pd.DataFrame):
                self.text_col_name = config["text_col"]

                if self.text_col_name not in text_doc.columns:
                    raise ValueError(
                        f"Input column name {self.text_col_name} is either incorrect or not present in the dataframe"
                    )

                df_input = text_doc.copy()
                # TODO - uncomment with meta data
                # unique_id_col = config["unique_id_col"]

                # if unique_id_col is None:
                #     unique_id_col = "unique_id"
                #     df_input[unique_id_col] = df_input.index
                # else:
                #     if unique_id_col not in df_input.columns:
                #         raise ValueError(f"Unique ID column name {unique_id_col} is either incorrect or not present in the dataframe")

            self.ner_model = spacy.load(self.model_path)

            before_drop = df_input.shape[0]
            df_input.drop_duplicates(inplace=True)
            df_input.reset_index(drop=True, inplace=True)
            after_drop = df_input.shape[0]
            perc_drop = (1 - after_drop / before_drop) * 100
            if after_drop != before_drop:
                self.logger.info(f"Dropped {perc_drop}% of duplicate text documents")

            size = len(df_input) / 75000
            size = math.ceil(size)
            df_splits = np.array_split(df_input, size)
            entities_df_list = []
            i = 1
            for df in df_splits:
                self.logger.info(f"Batch no {i} running out of {size} batches")
                # taking unique, to reduce the computational time
                # if the sentence is same for different unique ids / meta columns, there will be duplicates
                # example, `my name is ankita` is present for `id 1` and `id 2`, it is available 2 times in the data
                # after merge, we will have 2 records for id 1 and two records for id 2
                sentences = list(df[self.text_col_name].unique())
                batch_size = math.ceil(len(sentences) / 1000)
                if parallel_processing:
                    try:
                        docs = list(
                            self.ner_model.pipe(sentences, batch_size=batch_size, n_process=n_core)
                        )
                    except Exception as e:
                        self.logger.error(f"Parallel processing not possible due to error {e}")
                        self.logger.info("Inferencing without parallel processing")
                        docs = list(self.ner_model.pipe(sentences, batch_size=batch_size))
                else:
                    docs = list(self.ner_model.pipe(sentences, batch_size=batch_size))
                result_df = self._func_to_get_span(docs)
                entities_df_list.append(result_df)
                i = i + 1
            entities_df = pd.concat(entities_df_list).reset_index(drop=True)
            # df_input = df_input[[self.text_col_name]]
            entities_df = pd.merge(entities_df, df_input, on=self.text_col_name, how="outer")
            entities_df.reset_index(inplace=True, drop=True)

            if file_path_json:
                try:
                    save_df_as_json(entities_df, file_path_json)
                except Exception as e:
                    self.logger.warning(f"Failed to save json file due to the following error {e}")

            return entities_df
        except Exception as e:
            self.logger.error(f"Following error occurred during inference of span_cat model - {e}")
            Exception(f"Following error occurred during inference of span_cat model - {e}")

    def get_span_category_mapping(self, df_inference=pd.DataFrame, span_category_cols=list()):
        """Function to generate unique spans to span category mapping file.
        It creates a value 1 for the span category col if the span is tagged to the span category.

        Example: sentence = ``Try incorporating ginger, oranges, blueberries, tomatoes, salmon, dark chocolate, green tea, garlic and apples to your diet.``

        INGREDIENT = [ginger, oranges, blueberries, tomatoes, dark chocolate, garlic, apples],

        OCASSION = [],

        PRODUCT = [oranges, salmon, dark chocolate, green tea, apples]

        for column span value `oranges`, column INGREDIENT = 1, OCCASION = 0 and PRODUCT = 1

        Raises
        ------
        NameError
            raises name error when incorrect column name is passed.
        Exception
            raises exception if error occurs while generating span to span category mapping.

        Parameters
        ----------
        df_inference : pd.DataFrame, optional
            inference dataframe from self.inference function, by default pd.DataFrame
        span_category_cols : list, optional
            list of span categories in the inference output, by default list()
            Example: ["INGREDIENT", "OCCASION", "PRODUCT"]

        Returns
        -------
        pd.DataFrame
            mapping df with unique span in "spans" column and "span_category_cols" columns with value 0 or 1 for each span
            Example - if span_category_cols = ["INGREDIENT", "OCCASION", "PRODUCT"] then mapping_df columns = ["spans", "INGREDIENT", "OCCASION", "PRODUCT"]


        """
        try:
            if len(set(span_category_cols) - set(df_inference.columns)) != 0:
                raise ValueError(
                    f"Span category columns {span_category_cols} are either incorrect or not present in the inference dataframe columns list {df_inference.columns}"
                )

            mapping_df_list = []
            temp_dict = dict()
            for col in span_category_cols:
                df_inference[col] = df_inference[col].apply(lambda a: ast.literal_eval(str(a)))
                temp_df = df_inference[[col]].explode(col)
                temp_df["flg"] = 1
                temp_df = temp_df.drop_duplicates()
                temp_df.columns = ["spans", col]
                temp_df = temp_df.dropna().reset_index(drop=True)
                mapping_df_list.append(temp_df)
                temp_dict[col] = "sum"

            mapping_df = pd.concat(mapping_df_list).reset_index(drop=True)
            mapping_df = mapping_df.groupby(["spans"]).agg(temp_dict).reset_index()

            return mapping_df
        except Exception as e:
            self.logger.error(
                f"Following error occurred while generating span to span category mapping file {e}"
            )
            raise Exception(
                f"Following error occurred while generating span to span category mapping file {e}"
            )
