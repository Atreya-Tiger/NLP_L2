import os
import pandas as pd
import spacy
from spacy.kb import KnowledgeBase
from typing import Union

from tigernlp.core.utils import MyLogger


class ELinkerKnowledgeBase:

    """The ELinkerKnowledgeBase class is a utility class that provides functionalities to create Knowledge Base for entity linker."""

    def __init__(self, log_file_path: str = None, log_level: str = "WARNING", verbose: bool = True):
        """ELinkerKnowledgeBase class initialization.

        Parameters
        ----------
        log_file_path : str, optional
            Full path of the log file to save training logs at, by default None
        log_level : str, optional
            Logging level to write logs, by default "WARNING"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True
        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def _load_entities(self, df: pd.DataFrame):

        """Helper function to read in the pre-defined entities we want to disambiguate

        Parameters
        ----------
        df : pd.DataFrame
            Dataframe containing the elinker_id, elinker_label and elinker_description column

        Returns
        -------
        names : dict
            dictionary of elinker_id and elinker_label mapping

        description : dict
            dictionary of elinker_id and elinker_description mapping

        Note
        -----
        elinker_id and elinker_label are considered same for the entities

        """

        names = dict()
        descriptions = dict()

        for qid in df.iloc[:, 0]:
            names[qid] = list(df[df.iloc[:, 0] == qid].iloc[:, 1])[0]
            descriptions[qid] = list(df[df.iloc[:, 0] == qid].iloc[:, 2])[0]

        return names, descriptions

    def create_kb(
        self,
        nlp: spacy.language.Language,
        kb_save_path: str,
        model_save_path: str,
        df: pd.DataFrame = None,
        entities: Union[str, list] = list,
        elinker_label: Union[str, list] = list,
        elinker_description: Union[str, list] = list,
    ):
        """

        This function create the Knowledge Base in spaCy from dataframe and writes it to file .


        Parameters
        ----------
        df : pd.DataFrame
            The input dataframe containing entities, ner_label and elinker_description columns, by default None
        entities : Union[str, list]
            Column name of the entities column in the dataframe or list of entities
        elinker_label : Union[str, list]
            Column name of the entity linker label column in the dataframe or list of elinker_label
        elinker_description : Union[str, list]
            Column name of the description of entity linker label column in the dataframe or list of elinker_description
        nlp : spacy.language.Language
            spaCy language model to be used for knowledge base creation. It will be used for nlp.vocab
        kb_save_path : str
            Path to save the knowledge base. Example - 'project_folder/data/knowledge_base/'
        model_save_path : str
            Path  to save the nlp model object after knowledge base creation. Example - 'project_folder/data/nlp_model/'

        Returns
        -------
            The function does not return any value. It saves the knowledge base in the specified kb_save_path and saves the nlp model in the specified model_save_path.

        Raises
        ------

        ValueError:
            If any of the input lists are empty.
        ValueError
            If elinker_label list contain non-unique values.
        Exception
            raises exception if an error occurs during the creation of knowledge base.

        Examples
        --------

        >>> ** To provide dataframe as input **
        >>> import pandas as pd
        >>> from tigernlp.entity_categorizer.entity_linker.api import ELinkerKnowledgeBase
        >>> df = pd.DataFrame({
        >>>                    'entities':["George","George","George"]
        >>>                    'label': ["Jerry George","Roy Stanley George","Ralph George"],
        >>>                    'description' : ["guitarist","author","sports player"]
        >>>                  })
        >>> knowledge_base = ELinkerKnowledgeBase()
        >>> nlp = spacy.load("en_core_web_sm")
        >>> knowledge_base.create_kb(df = df,
        >>>                          nlp = nlp,
        >>>                          kb_save_path = 'project_folder/data/knowledge_base/',
        >>>                          model_save_path = '/project_folder/trained_model/nlp_model',
        >>>                          entities = 'entities'
        >>>                          elinker_label = 'label',
        >>>                          elinker_description = 'description',
        >>>                          )
        >>> ** To provide columns list as input instead of dataframe **
        >>> import pandas as pd
        >>> from tigernlp.entity_categorizer.entity_linker.api import ELinkerKnowledgeBase
        >>> entities = ["George","George","George"]
        >>> label = ["Jerry George","Roy Stanley George","Ralph George"],
        >>> description = ["author","sports player","king"]
        >>> knowledge_base = ELinkerKnowledgeBase()
        >>> nlp = spacy.load("en_core_web_sm")
        >>> knowledge_base.create_kb(df = None,
        >>>                          nlp = nlp,
        >>>                          kb_save_path = 'project_folder/data/knowledge_base/',
        >>>                          model_save_path =  '/project_folder/trained_model/nlp_model'
        >>>                          entities = entities,
        >>>                          elinker_label = label,
        >>>                          elinker_description = description
        >>>                          )

        Note
        ----
        Skip the create_kb step if you already have a knowledge base.
        Update the knowledge base if there is a change in training data.
        """

        try:
            if df is None:

                if not entities or not elinker_label or not elinker_description:
                    raise ValueError("One or more of the input lists are empty")

                if len(set(elinker_label)) != len(elinker_label):
                    raise ValueError("elinker_label list contains non-unique values")

                if len(set([len(entities), len(elinker_label), len(elinker_description)])) != 1:
                    raise ValueError("The length of all three input lists should be same")

                kb_df = pd.DataFrame(
                    {"elinker_id": elinker_label, "elinker_label": elinker_label, "elinker_description": elinker_description}
                )
            else:
                elinker_id = elinker_label
                kb_df = df[[elinker_id, elinker_label, elinker_description]]
                kb_df.reset_index(drop=True, inplace=True)
                entities = df[entities]
                elinker_label = df[elinker_label]

            name_dict, desc_dict = self._load_entities(kb_df)

            kb = KnowledgeBase(vocab=nlp.vocab, entity_vector_length=96)

            for qid, desc in desc_dict.items():
                desc_doc = nlp(desc)
                desc_enc = desc_doc.vector
                kb.add_entity(entity=str(qid), entity_vector=desc_enc, freq=342)

            for qid, name in name_dict.items():
                kb.add_alias(alias=name, entities=[str(qid)], probabilities=[1])

            qids = name_dict.keys()
            df = pd.DataFrame({"entities": entities, "elinker_label": elinker_label})
            group_sizes = df.groupby("entities")["elinker_label"].nunique()
            prob_scores = 1 / group_sizes

            for entity, probs in prob_scores.items():
                kb.add_alias(alias=str(entity), entities=qids, probabilities=[probs] * len(qids))

            kb.to_disk(os.path.join(kb_save_path))
            nlp.to_disk(os.path.join(model_save_path))

        except Exception as e:
            self.logger.error(f"Error {e} occurred while creating knowledge base for entity linker model")
            raise Exception(f"An error occurred while creating knowledge base for entity linker model. The error message is: {e}.")
