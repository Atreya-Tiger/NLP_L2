import ast
import configparser
import os
import pickle
import random
import spacy
from spacy.ml.models import load_kb
from spacy.pipeline.entity_linker import DEFAULT_NEL_MODEL
from spacy.training import Example
from spacy.util import compounding, minibatch

from tigernlp.core.utils import MyLogger
from tigernlp.custom_spacy.api import SpacyTrainer
from tigernlp.entity_categorizer.entity_linker.knowledge_base import ELinkerKnowledgeBase

from .data_prepare import ELinkerSpacyDataPrep


class ELinkerTrainer(SpacyTrainer, ELinkerSpacyDataPrep, ELinkerKnowledgeBase):
    """
    A class for training entity linker model using SpacyTrainer, ELinkerSpacyDataPrep, ELinkerKnowledgeBase classes.
    It inherits all the methods of SpacyTrainer, ELinkerSpacyDataPrep and ELinkerKnowledgeBase classes.

    Parameters
    ----------
    log_file_path : str
        Full path of the log file to save training logs at
    log_level : str, optional
        Logging level to write logs, by default "INFO"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    """

    def __init__(self, log_file_path: str = None, log_level: str = "INFO", verbose: bool = True):
        """ELinkerTrainer class initialization

        Parameters
        ----------
        log_file_path : str
            Full path of the log file to save training logs at
        log_level : str, optional
            Logging level to write logs, by default "WARNING"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True

        Examples
        --------
        >>> from from tigernlp.entity_categorizer.entity_linker.api import ELinkerTrainer
        >>> elinker_trainer = ELinkerTrainer()
        >>> kb_save_path = "project_folder/data/knowledge_base/kb"
        >>> config_path = "/path/model_config.cfg"
        >>> model_save_path = "/project_folder/trained_model/nlp_model"
        >>> train_data_save_path = "/project_folder/data/train/train_data.pkl"
        >>> elinker_trainer.train_el(kb_save_path = kb_save_path, config_path = config_path, nlp = nlp, model_save_path = model_save_path, train_data_save_path = train_data_save_path)

        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def generate_config(
        self,
        config_save_path: str,
        optimize: str = "efficiency",
        gpu: bool = False,
        pretrained_model_config_path: str = None,
    ):
        """Generates a configuration file for the entity linker model training.

        Parameters
        ----------
        config_save_path : str
            Filepath to save the generated configuration file. Example - "project_folder/config/config.cfg"
        optimize : str, optional
            Model optimization strategy to use. Can be "efficiency" or "speed". Defaults "efficiency"
        gpu : bool, optional
            Flag to indicate whether to use GPU for training, Defaults False
        pretrained_model_config_path : str, optional
            The config path for the pretrained_model. Should be provided for retraining model. When provided, it will read the config file and fill/update the given parameter and save it in config_save_path. Example - "project_folder/config/config_version_old.cfg". Default None.

        Raises
        ------
        Exception
            raises exception if an error occurs while generating the configuration file.

        Examples
        --------
        >>> from tigernlp.entity_categorizer.entity_linker.api import ELinkerTrainer
        >>> elinker_trainer = ELinkerTrainer()
        >>> config_save_path = 'project_folder/config/config_finetuned.cfg'
        >>> pretrained_model_config_path = 'project_folder/config/config.cfg'
        >>> elinker_trainer.generate_config(config_save_path = config_save_path, pretrained_model_config_path = pretrained_model_config_path)
        >>> The generated configuration file will be saved at 'project_folder/config/scat_config.cfg'
        """

        return super().generate_config(config_save_path, "entity_linker", optimize, gpu, pretrained_model_config_path)

    def _parse_config(self, config_path):

        """This function takes the config path and
        returns the config dictionary in the format required for training
        """

        config_dict = {}
        config = configparser.RawConfigParser()
        config.read(config_path)
        temp_dict = dict(config.items("components.entity_linker"))
        config_dict["labels_discard"] = ast.literal_eval(temp_dict["labels_discard"])
        config_dict["incl_prior"] = bool(temp_dict["incl_prior"])
        config_dict["incl_context"] = bool(temp_dict["incl_context"])
        config_dict["entity_vector_length"] = int(temp_dict["entity_vector_length"])
        config_dict["get_candidates"] = ast.literal_eval(temp_dict["get_candidates"])
        config_dict["model"] = DEFAULT_NEL_MODEL

        return config_dict

    def train_el(
        self,
        kb_save_path: str,
        config_path: dict,
        train_data_save_path: str,
        nlp: spacy.language.Language,
        model_save_path: str,
    ):
        """
        Trains an entity linking model using the specified knowledge base, training data and configuration, and saves the trained model to the specified model path.

        Parameters
        ----------
        kb_save_path : str
            Path to load the Knowledge base. This file should contain the saved knowledge base. For example - "project_folder/data/knowledge_base/kb"
        config_path : str
            Path to load the configuration file for the entity linking model. This file should contain hyperparameters and other settings used for training the model. For example - "/path/model_config.cfg"
        train_data_save_path : str
            The file path where the training data is available. For example - "/project_folder/data/train/train_data.pkl"
        nlp : spacy.language.Language
            spaCy language model to be used for training, entity_linker pipeline will be added to the model and will be saved at the mode_save_path. For example - spacy.load("en_core_web_sm")
        model_save_path : str
            The file path where the trained model will be saved. For example - "/project_folder/trained_model/nlp_model"


        Returns
        -------
        This function does not return any value. It saves the trained model in the specified model_save_path.

        Examples
        --------
        >>> from from tigernlp.entity_categorizer.entity_linker.api import ELinkerTrainer
        >>> elinker_trainer = ELinkerTrainer()
        >>> kb_save_path = "project_folder/data/knowledge_base/kb"
        >>> config_path = "/path/model_config.cfg"
        >>> model_save_path = "/project_folder/trained_model/nlp_model"
        >>> train_data_save_path = "/project_folder/data/train/train_data.pkl"
        >>> elinker_trainer.train_el(kb_save_path = kb_save_path, config_path = config_path, nlp = nlp, model_save_path = model_save_path, train_data_save_path = train_data_save_path)

        """

        # nlp = spacy.load(model_save_path)
        config = self._parse_config(config_path)

        try:
            entity_linker = nlp.add_pipe("entity_linker", config=config, last=True)
        except Exception as e:
            entity_linker = nlp.get_pipe("entity_linker")
            self.logger.info(f"Entity Linker pipeline already part of the model: {e}")

        with open(train_data_save_path, "rb") as f:
            dataset = pickle.load(f)

        train_examples = []

        if "sentencizer" not in nlp.pipe_names:
            nlp.add_pipe("sentencizer"),

        sentencizer = nlp.get_pipe("sentencizer")

        for text, annotation in dataset:
            example = Example.from_dict(nlp.make_doc(text), annotation)
            example.reference = sentencizer(example.reference)
            train_examples.append(example)

        entity_linker.initialize(get_examples=lambda: train_examples, kb_loader=load_kb(kb_save_path))

        with nlp.select_pipes(enable=["entity_linker"]):
            optimizer = nlp.resume_training()
            for itn in range(500):
                random.shuffle(train_examples)
                batches = minibatch(train_examples, size=compounding(4.0, 32.0, 1.001))
                losses = {}
                for batch in batches:
                    nlp.update(
                        batch,
                        drop=0.2,
                        losses=losses,
                        sgd=optimizer,
                    )
                if itn % 50 == 0:
                    self.logger.info(f"Iteration : {itn}, Losses : {losses}")

        self.logger.info(f"Iteration : {itn}, Losses : {losses}")

        nlp.to_disk(os.path.join(model_save_path))
