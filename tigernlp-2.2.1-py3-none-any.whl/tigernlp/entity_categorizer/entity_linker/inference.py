import os
import pandas as pd
import spacy
import warnings
from joblib import Parallel, delayed

from tigernlp.core.utils import MyLogger

warnings.filterwarnings("ignore")


class ELinkerInference:
    """ELinkerInference class to generate the predicted values from entity linker model

    Parameters
    ----------
    log_file_path : str, optional
        Full path of the log file to save training logs at, by default None
    log_level : str, optional
        Logging level to write logs, by default "WARNING"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Example
    ---------
    >>> from tigernlp.entity_categorizer.entity_linker.api import ELinkerInference
    >>> infer = ELinkerInference()
    >>> sentence = 'George was a Tennis player who won Wimbledon twice'
    >>> model_path = '/project_folder/trained_model/nlp_model'
    >>> output_df = infer.predict_elinker_labels(sentences = sentence,
    >>>                                             model_save_path = 'model_path',
    >>>                                             parallel_process = False,
    >>>                                             n_jobs = -1,
    >>>                                             json_output = False,
    >>>                                             json_path = None)
    >>> # Output dataframe with below columns (sentence, entity, ner_label, elinker_label) and values associated with these columns
    >>> output_df['sentence']
    >>> ["George was a Tennis player who won Wimbledon twice"]
    >>> output_df['entity']
    >>> ["George","Wimbledon"]
    >>> output_df['ner_label']
    >>> ["PERSON","EVENT"]
    >>> output_df['elinker_label']
    >>> ['Ralph George','Tournament']
    """

    def __init__(self, log_file_path: str = None, log_level: str = "WARNING", verbose: bool = True):
        """ELinkerInference class initialization.

        Parameters
        ----------
        log_file_path : str, optional
            Full path of the log file to save training logs at, by default None
        log_level : str, optional
            Logging level to write logs, by default "WARNING"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True
        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def __predict_el(self, sentence: str, nlp: spacy.language.Language):
        """For a given dataframe, this function returns the entities, ner_label and entity_linker labels associated with them from the text.

        Parameters
        ----------
        sentence : str
            sentence on which nodel will predict the entity, ner_label and entity_linker label. Example - 'George was a Tennis player who won Wimbledon twice'
        spacy_model : spacy.language.Language
            spacy model object

        Returns
        -------
        list
            list[0] contains the sentence
            list[1] contains the identified entities
            list[2] contains the predicted ner_labels
            list[3] contains the predicted entity_linker
        """
        try:
            doc = nlp(sentence)
            entities = list(map(lambda ent: ent.text, doc.ents))
            ner_labels = list(map(lambda ent: ent.label_, doc.ents))
            elinker_labels = list(map(lambda ent: ent.kb_id_, doc.ents))
            return [sentence, entities, ner_labels, elinker_labels]
        except Exception as e:
            self.logger.error(f"Error occurred during predicting NER entities and labels for sentence {e}")
            raise Exception(f"Error occurred during predicting NER entities and labels for sentence {e}")

    def predict_elinker_labels(
        self,
        sentences,
        model_save_path: str,
        parallel_process: bool = False,
        n_jobs: int = -1,
        json_output: bool = False,
        json_path: bool = None,
    ):
        """The function predict_elinker_labels is used to predict entities, ner_labels and entity linker labels from a given sentence or list of sentences.

        Parameters
        ----------
        sentences : Union[str, list[str]]
            sentence string or list of sentences against which entities and labels are fetched. If list, then it should be unique. Example - 'The Indian Space Research Organisation is the national space agency of India, headquartered in Bengaluru.'
        model_save_path : str
            The file path to load the trained entity linker nlp model
        parallel_process : bool
            If True, function will use parallel processing based on n_jobs value to predict entities and labels, by default False
        n_jobs : int
            Using default value parallel processing function will use all cores to train. Otherwise provide value based on number of cores to avail for the function, by default -1
        json_output : bool
            If True, output format will be in json. Default False
        json_path : str
            If json_ouput is True, the output will be saved to json_path, by default None

        Returns
        -------
        dataframe
            Pandas dataframe with columns name sentences, entities, and labels
        dataframe['sentence']
            sentences against in which entities are present
        dataframe['entity']
            Entities which are fetched from text
        dataframe['ner_label']
            Named Entity Labels of the entities which are fetched from text
        dataframe['elinker_label']
            Entity Linker Labels of the entities which are fetched from text

        Raises
        -------
        Exception
            If error occured during predicting entities and labels for the input sentence or list of sentences
        TypeError
            raises type error if the sentence parameter is not in string or list of string type
        OSError
            raises OS error when unable to load model

        Examples
        ---------
        >>> from tigernlp.entity_categorizer.entity_linker.api import ELinkerInference
        >>> infer = ELinkerInference()
        >>> sentence = 'George was a Tennis player who won Wimbledon twice'
        >>> model_path = '/project_folder/trained_model/nlp_model'
        >>> output_df = infer.predict_elinker_labels(sentences = sentence,
        >>>                                             model_save_path = 'model_path',
        >>>                                             parallel_process = False,
        >>>                                             n_jobs = -1,
        >>>                                             json_output = False,
        >>>                                             json_path = None)
        >>> # Output dataframe with below columns (sentence, entity, ner_label, elinker_label) and values associated with these columns
        >>> output_df['sentence']
        >>> ["George was a Tennis player who won Wimbledon twice"]
        >>> output_df['entity']
        >>> ["George","Wimbledon"]
        >>> output_df['ner_label']
        >>> ["PERSON","EVENT"]
        >>> output_df['elinker_label']
        >>> ['Roy Stanley George','Tennis Tournament']
        """
        try:
            if not isinstance(sentences, list):
                if not isinstance(sentences, str):
                    # self.logger.error(f"expected string or list of strings for sentences parameter got {type(sentences)}.")
                    raise TypeError(f"expected string or list of strings for sentences parameter got {type(sentences)}.")

            elif not all(isinstance(item, str) for item in sentences):
                # self.logger.error("list sentences items is of incorrect type.")
                raise TypeError("list sentences items is of incorrect type.")

            elif not (os.path.exists(model_save_path) or spacy.util.is_package(model_save_path)):
                # self.logger.error(
                #     f"Can't find model {model_save_path}. It doesn't seem to be a spacy_model or a valid path to a data directory"
                # )
                raise OSError(
                    f"Can't find model {model_save_path}. It doesn't seem to be a spacy_model or a valid path to a data directory"
                )

            elif not (isinstance(json_output, bool)):
                # self.logger.error(f"expected bool datatype for json_output got {type(json_output)}")
                raise TypeError(f"expected bool datatype for json_output got {type(json_output)}")

            if type(sentences) is str:
                sentences = [sentences]

            nlp = spacy.load(model_save_path)
            test = pd.DataFrame()

            if parallel_process:
                self.logger.info(f"[Parallel(n_jobs={n_jobs})]: Using backend LokyBackend with {n_jobs} concurrent workers.")
                output = Parallel(n_jobs=n_jobs, verbose=50, backend="loky")(
                    delayed(self.__predict_el)(sentence, nlp) for sentence in sentences
                )
            else:
                output = [self.__predict_el(sentence, nlp) for sentence in sentences]

            test["sentence"] = list(zip(*output))[0]
            test["entity"] = list(zip(*output))[1]
            test["ner_label"] = list(zip(*output))[2]
            test["elinker_label"] = list(zip(*output))[3]

            if json_output:
                return test.to_json(json_path, orient="index")
            else:
                return test
        except Exception as e:
            self.logger.error(f"Error occurred during predicting NER entities and labels. The error message is: {e}")
            raise Exception(f"Error occurred during predicting NER entities and labels. The error message is: {e}")
