import pandas as pd
import pickle
import spacy

from tigernlp.core.utils import MyLogger
from tigernlp.custom_spacy.api import generate_index_labels
from tigernlp.entity_categorizer.entity_linker.knowledge_base import ELinkerKnowledgeBase


class ELinkerSpacyDataPrep(ELinkerKnowledgeBase):

    """The ELinkerSpacyDataPrep class is a utility class that provides functionalities for preparing data in the spacy format for Entity Linker. It has the following methods:

    1. get_elinker_index: Adds a column to the dataframe containing a list of tuples, with each tuple containing the start index, end index, and label associated with an entity.

    2. generate_corpus: Generates a corpus in spacy format from a dataframe.

    Parameters
    ----------
    log_file_path : str, optional
        Full path of the log file to save training logs at, by default None
    log_level : str, optional
        Logging level to write logs, by default "WARNING"
    verbose : bool, optional
        If `True` logs will be printed to console, by default True

    Examples
    ---------
    >>> import pandas as pd
    >>> from tigernlp.entity_categorizer.entity_linker.api import ELinkerSpacyDataPrep
    >>> df = pd.DataFrame({
    >>>                   'text': ['This is a sentence about apples.', 'Apples are a type of fruit.'],
    >>>                   'entity': ['apples', 'apples'],
    >>>                   'label': ['FRUIT', 'FRUIT']
    >>>                  })
    >>> data_prep = ELinkerSpacyDataPrep()
    >>> df_with_index = data_prep.get_elinker_index(dataframe = df,
    >>>                                             text = 'text',
    >>>                                             entities = 'entity',
    >>>                                             ner_label = 'label')
    >>> df_with_index['text']
    >>> ['This is a sentence about apples.', 'Apples are a type of fruit.']
    >>> df_with_index['entity']
    >>> ['apples', 'apples']
    >>> df_with_index['label']
    >>> ['FRUIT', 'FRUIT']
    >>> df_with_index['entity_index']
    >>> [[(10, 16, 'FRUIT')], (0, 6, 'FRUIT')]
    >>> nlp = spacy.load("en_core_web_sm")
    >>> kb_save_path = "project_folder/data/knowledge_base/"
    >>> model_save_path = "project_folder/data/nlp_model/"
    >>> data_prep.generate_corpus(data = df_with_index,
    >>>                           text ='text',
    >>>                           elinker_label = 'elinker_label', entities = 'entities',
    >>>                           entity_index = 'entity_index', elinker_description = 'description',
    >>>                           create_kb = True, nlp = nlp, train_data_path = train_data_path,
    >>>                           kb_save_path = kb_save_path, model_save_path = model_save_path)

    """

    def __init__(self, log_file_path: str = None, log_level: str = "WARNING", verbose: bool = True):
        """ELinkerSpacyDataPrep class initialization.

        Parameters
        ----------
        log_file_path : str, optional
            Full path of the log file to save training logs at, by default None
        log_level : str, optional
            Logging level to write logs, by default "WARNING"
        verbose : bool, optional
            If `True` logs will be printed to console, by default True

        """

        self.logger = MyLogger(level=log_level, log_file_path=log_file_path, verbose=verbose).logger

    def get_elinker_index(
        self,
        df: pd.DataFrame,
        text: str,
        entities: str,
        ner_label: str,
        spacy_model: str = "en_core_web_sm",
    ):
        """This function adds a column to the dataframe containing a list of tuples, with each tuple containing the start index, end index, and label associated with an entity.

        Note: Can be computationally heavy for large datasets.

        Parameters
        ----------
        df : pd.DataFrame
            Dataframe containing the text, entity and label column.
        text : str
            Column name of the text column in the dataframe.
        entities : str
            Column name of the entity column in the dataframe.
        ner_label : str
            Column name of the label column in the dataframe.
        spacy_model : str
            The spacy model to be loaded, default is 'en_core_web_sm'.

        Returns
        -------
        dataframe : pd.DataFrame
            Dataframe with additional column 'entity_index' which contains the tuple of start_index,end_index and label of an entity.

        Raises
        ------
        TypeError
            raises type error when dataframe is not of pd.DataFrame type.
        NameError
            raises name error when textcol, labelcol, entitycol not present in dataframe.
        ValueError
            raises value error when dataframe is empty.
        Exception
            raises exception when error occurs while adding the 'entity_index' column to the dataframe.

        Examples
        --------
        >>> import pandas as pd
        >>> from tigernlp.entity_categorizer.entity_linker.api import ELinkerSpacyDataPrep
        >>> df = pd.DataFrame({
        >>>                   'text': ['This is a sentence about apples.', 'Apples are a type of fruit.'],
        >>>                   'entity': ['apples', 'apples'],
        >>>                   'label': ['FRUIT', 'FRUIT']
        >>>                  })
        >>> data_prep = ELinkerSpacyDataPrep()
        >>> df_with_index = data_prep.get_elinker_index(df = df,
        >>>                                             text = 'text',
        >>>                                             entities = 'entity',
        >>>                                             ner_label = 'label')
        >>> df_with_index['text']
        >>> ['This is a sentence about apples.', 'Apples are a type of fruit.']
        >>> df_with_index['entity']
        >>> ['apples', 'apples']
        >>> df_with_index['label']
        >>> ['FRUIT', 'FRUIT']
        >>> df_with_index['entity_index']
        >>> [[(10, 16, 'FRUIT')], (0, 6, 'FRUIT')]
        """
        try:
            if not isinstance(df, pd.DataFrame):
                # self.logger.error("Input dataframe is of incorrect type in get_elinker_index")
                raise TypeError("Input dataframe is of incorrect type in get_elinker_index")
            if not (df.shape[0]) > 0:
                # self.logger.error("Received empty dataframe.")
                raise ValueError("Received empty dataframe.")
            elif text not in df.columns.to_list():
                # self.logger.error(f"Given column is not a valid column in the dataframe - {text}")
                raise NameError(f" {df} is not present in the dataframe.")
            elif entities not in df.columns.to_list():
                # self.logger.error(f"Given column is not a valid column in the dataframe - {entities}")
                raise NameError(f" {entities} is not present in the dataframe.")
            elif ner_label not in df.columns.to_list():
                # self.logger.error(f"Given column is not a valid column in the dataframe - {ner_label}")
                raise NameError(f" {ner_label} is not present in the dataframe.")

            nlp = spacy.load(spacy_model)
            df["entity_index"] = df.apply(
                lambda row: generate_index_labels(row[text], [row[entities]], [row[ner_label]], nlp),
                axis=1,
            )
            return df

        except Exception as e:
            self.logger.error(
                f"An error occurred while adding the 'entity_index' column to the dataframe. The error message is: {e}. Please check the input dataframe and provided column names for errors."
            )
            raise Exception(
                f"An error occurred while adding the 'entity_index' column to the dataframe. The error message is: {e}. Please check the input dataframe and provided column names for errors."
            )

    def generate_corpus(
        self,
        df: pd.DataFrame,
        text: str,
        elinker_label: str,
        entities: str,
        entity_index: str,
        elinker_description: str,
        train_data_save_path: str,
        create_kb: bool,
        **kwargs,
        # nlp: spacy.language.Language,
        # kb_save_path: str,
        # model_save_path: str,
    ):

        """
        Generate a corpus of train dataset from a given dataframe and specified string parameters.

        Parameters
        ----------
        df : pandas.DataFrame
            The input dataframe containing text data, elinker_label, entities, entity_index and elinker_description, by default None
        text : str
            Column name of the text column in the dataframe
        elinker_label : str
            Column name of the entities label column in the dataframe
        entities : str
            Column name of the entities column in the dataframe
        entity_index : str
            Column name of the entity index column in the dataframe
        elinker_description : str
            Column name of the elinker_description column in the dataframe
        train_data_save_path : str
            The file path where the training data will be saved. For example - "/project_folder/data/train/train_data.pkl"
        create_kb : bool
            A boolean parameter used to determine whether user want to create knowledge base. Alternatively, knowledge base can also be created using the `ELinkerKnowledgeBase` class from tigernlp.entity_categorizer.entity_linker.api
        nlp : spacy.language.Language
            if create_kb is True, spaCy language model to be used for knowledge base creation. It will be used for nlp.vocab
        kb_save_path : str
            if create_kb is True, path to save the knowledge base. Example - 'project_folder/data/knowledge_base/'
        model_save_path : str
            if create_kab is True, path to save the nlp model object after knowledge base creation. Example - 'project_folder/data/nlp_model/'


        Returns
        -------
            This function does not return any value. It saves the train dataset corpus at the train_data_path provided by the user in input parameter.

        Raises
        ------
            ValueError: If the input dataframe is empty or does not contain the necessary columns.

        Examples
        --------
        >>> import pandas as pd
        >>> from tigernlp.entity_categorizer.entity_linker.api import ELinkerSpacyDataPrep
        >>> df_with_index = pd.DataFrame({'text': ['George wrote most of his important essays as lectures first and
        >>>                                then revised them for print', 'From 1963 to 1967, George won five consecutive men's singles titles at the Australian Championships.'],
        >>>                    'elinker_label': ['Ralph George','Roy Stanley George']
        >>>                    'entities': ['George', 'George'],
        >>>                    'entity_index': [[(0, 6, 'PERSON')], [(19, 25, 'PERSON')]],
        >>>                    'elinker_description':['author','sports player'],
        >>>                    })
        >>> train_data_save_path = "project_folder/data/train_data.pkl"
        >>> nlp = spacy.load("en_core_web_sm")
        >>> kb_save_path = "project_folder/data/knowledge_base/"
        >>> model_save_path = "project_folder/data/nlp_model/"
        >>> data_prep = ELinkerSpacyDataPrep()
        >>> data_prep.generate_corpus(df = df_with_index,
        >>>                           text ='text',
        >>>                           elinker_label = 'elinker_label', entities = 'entities',
        >>>                           entity_index = 'entity_index', elinker_description = 'description',
        >>>                           train_data_save_path = train_data_save_path,
        >>>                           create_kb = True, nlp = nlp,
        >>>                           kb_save_path = kb_save_path, model_save_path = model_save_path)
        """
        try:
            if not isinstance(df, pd.DataFrame):
                raise TypeError("dataframe must be a pd.DataFrame.")

            if pd.DataFrame(df).empty:
                raise ValueError("DataFrame is empty")

            if not all(len(df[column]) == len(df) for column in df.columns):
                raise ValueError("Columns have different lengths")

            dataset = []

            for i in range(len(df)):
                tupple = (df[entity_index][i][0][0], df[entity_index][i][0][1])
                temp_dict = {"links": {tupple: {df[elinker_label][i]: 1.0}}, "entities": df[entity_index][i]}
                temp_tupple = (df[text][i], temp_dict)
                dataset.append(temp_tupple)

            if create_kb:

                unique_df = df.drop_duplicates(subset=[entities, elinker_label, elinker_description])
                entities = list(unique_df[entities])
                elinker_label = list(unique_df[elinker_label])
                elinker_desc = list(unique_df[elinker_description])

                for key, value in kwargs.items():
                    if key == "nlp":
                        nlp = value

                    if key == "kb_save_path":
                        kb_save_path = value

                    if key == "model_save_path":
                        model_save_path = value

                super().create_kb(
                    nlp=nlp,
                    kb_save_path=kb_save_path,
                    model_save_path=model_save_path,
                    entities=entities,
                    elinker_label=elinker_label,
                    elinker_description=elinker_desc,
                )

            with open(train_data_save_path, "wb") as f:
                pickle.dump(dataset, f)

        except Exception as e:
            self.logger.error(f"Error {e} occurred while generating corpus for entity linker model")
            raise Exception(f"An error occurred while generating corpus for entity linker model. The error message is: {e}.")
