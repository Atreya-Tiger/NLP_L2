"""
This module provides functionality for Entity linker including knowledge base creation, data preparation, training, and inferencing.
"""
