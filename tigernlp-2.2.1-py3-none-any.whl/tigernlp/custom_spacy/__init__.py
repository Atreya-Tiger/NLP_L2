"""
This module offers functionality that is common across all spacy modules, including training spacy models, evaluating spacy models, and providing utility functions.
"""
