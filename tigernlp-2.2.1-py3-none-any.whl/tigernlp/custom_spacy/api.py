"""Utiltiies around ``custom_spacy``.

This module provides custom_spacy algorithms.
"""
from .evaluate import SpacyEvaluate
from .train import SpacyTrainer
from .utils import generate_index_labels, run_cli